function antimena(selector, canvas, lazyLoadInstance) {
    "use strict";

    selector.find('#modal-ai-image > .palleon-tabs > ul.palleon-tabs-menu > li:first-child').trigger('click');

    // Download image button
    selector.find('.antimena-grid').on('click','.antimena-img-download',function(){
        var seed = $(this).data('seed'),
        a = document.createElement("a");
        a.href = selector.find('#' + seed).attr('src');
        a.download = seed + ".png";
        a.click();   
    });

    // Save image button
    selector.find('.antimena-grid').on('click','.antimena-img-save',function(){
        var btn = $(this),
        seed = $(this).data('seed'),
        imgData = selector.find('#' + seed).attr('src'),
        form_data = new FormData();
        form_data.append('id', '');
        form_data.append('mode', 'image');
        form_data.append('name', seed);
        form_data.append('filename', seed);
        form_data.append('format', 'base64');
        form_data.append('type', 'image/png');
        form_data.append('url', imgData);
        form_data.append('action', 'saveImage');
        form_data.append('nonce', palleonParams.nonce);
        $.ajax({
            url: palleonParams.ajaxurl,
            type: 'POST',
            contentType: false,
            processData: false,
            cache: false,
            data: form_data,
            beforeSend: function ( xhr ) {
                btn.html('<span class="material-icons arrow">save</span>' + antimenaParams.saving);
                btn.prop('disabled', true);
            },
            success: function () {
                toastr.success(palleonParams.imgsaved, palleonParams.success);
                btn.html('<span class="material-icons arrow">done</span>' + palleonParams.saved);
                btn.prop('disabled', true);
            },
            error: function(jqXHR,error, errorThrown) {
                if (jqXHR.status&&jqXHR.status==400) {
                    toastr.error(jqXHR.responseText, palleonParams.error);
                } else {
                    toastr.error(palleonParams.wrong, palleonParams.error);
                }
                btn.prop('disabled', false);
            }
        });  
    });

    // Select image button
    selector.find('.antimena-grid').on('click','.antimena-img-select',function(){
        if (!selector.hasClass('agama')) {
            var seed = $(this).data('seed'),
            src = selector.find('#' + seed).attr('src');
            $(document).trigger( "loadBase64Img", [src, seed] );
            selector.find('#modal-add-new').hide();
        }
    });

    // User balance update
    function user_balance_update(credits) {
        var credit_form = new FormData();
        credit_form.append('credits', credits);
        credit_form.append('action', 'updateCredits');
        credit_form.append('nonce', palleonParams.nonce);
        $.ajax({
            url: palleonParams.ajaxurl,
            type: 'POST',
            contentType: false,
            processData: false,
            cache: false,
            data: credit_form,
            success: function (data) {
                selector.find('#sai-balance-check').trigger('click');
                selector.find('#antimena-user-credits').html(data);
                toastr.success(data + ' ' + antimenaParams.creditsLeft, palleonParams.success);
            },
            error: function(jqXHR,error, errorThrown) {
                if (jqXHR.status&&jqXHR.status==400) {
                    toastr.error(jqXHR.responseText, palleonParams.error);
                } else {
                    toastr.error(palleonParams.wrong, palleonParams.error);
                }
            }
        });   
    }

    ///////////////* OPENAI *///////////////

    // Get API key
    var oaiApiKey = '';
    function oai_api_key() {
        var data = {
            'action': 'oaiApiKey',
            'nonce': palleonParams.nonce
        };
        $.ajax({
            url : palleonParams.ajaxurl,
            data : data,
            type : 'POST',
            success: function(data){
                if(data) {
                    oaiApiKey = data;
                }
            },
            error: function(jqXHR,error, errorThrown) {
                if(jqXHR.status&&jqXHR.status==400){
                    console.log(jqXHR.responseText);
                }else{
                    console.log(palleonParams.wrong);
                }
           },
        });
    };
    oai_api_key();

    // Enable & disable generate buttons
    selector.find('#oai-prompt').on("input paste", function () {
        var val = $(this).val();
        if (val.length >= 1) {
            selector.find('#oai-image-generate').prop('disabled', false);
        } else {
            selector.find('#oai-image-generate').prop('disabled', true);
        }
    });

    selector.find('#oai-edit-prompt').on("input paste", function () {
        var val = $(this).val();
        if (val.length >= 1) {
            selector.find('#oai-edit').prop('disabled', false);
        } else {
            selector.find('#oai-edit').prop('disabled', true);
        }
    });

    /* GENERATE NEW IMAGE */
    selector.find('#oai-image-generate').on("click", function () {
        if (oaiApiKey != '') {
            var prompt = selector.find('#oai-prompt').val();
            var quality = selector.find('#oai-quality').find(":selected").val();
            var style = selector.find('#oai-style').find(":selected").val();
            if (prompt.length >= 1) {
                if (antimenaParams.allowedUser === 'no') {
                    var cost = parseInt(antimenaParams.oaiCost);
                    var userCredits = parseInt(selector.find('#antimena-user-credits').html());
                    if (cost > userCredits) {
                        toastr.error(antimenaParams.creditsError, palleonParams.error);
                        return;
                    }
                }
                var answer = window.confirm(antimenaParams.answer2);
                if (answer) {
                    var size = selector.find('#oai-size').find(":selected").val();
                    var data = {
                        'action': 'oaiTextToImage',
                        'nonce': palleonParams.nonce,
                        'prompt': prompt,
                        'size': size,
                        'quality': quality,
                        'style': style
                    };

                    $.ajax({
                        url : palleonParams.ajaxurl,
                        data : data,
                        type : 'POST',
                        beforeSend: function ( xhr ) {
                            selector.find('#modal-ai-image').css('pointer-events', 'none');
                            selector.find('#antimena-loader-4').css('display', 'flex');
                        },
                        success: function(data){
                            if(data) {
                                console.log(data);
                                if (data.charAt(0) == '{') {
                                    data = $.parseJSON(data);
                                    console.log(data);
                                    if (data.error !== undefined) {
                                        toastr.error(data.error.message, palleonParams.error);
                                    } else {
                                        toastr.error(palleonParams.wrong, palleonParams.error);
                                    }
                                } else {
                                    selector.find('#oai-images').html('');
                                    selector.find('#oai-images').removeClass('antimena-grid-placeholder');
                                    selector.find('#oai-images').html(data);
                                    if (antimenaParams.allowedUser === 'no') {
                                        var credits = antimenaParams.oaiCost;
                                        user_balance_update(credits);
                                    }
                                }
                            }
                        },
                        error: function(jqXHR,error, errorThrown) {
                            if(jqXHR.status&&jqXHR.status==400){
                                toastr.error(jqXHR.responseText, palleonParams.error);
                            }else{
                                toastr.error(palleonParams.wrong, palleonParams.error);
                            }
                            selector.find('#modal-ai-image').css('pointer-events', 'auto');
                            selector.find('#antimena-loader-4').css('display', 'none');
                    }
                    }).done(function( response ) {
                        selector.find('#modal-ai-image').css('pointer-events', 'auto');
                        selector.find('#antimena-loader-4').css('display', 'none');
                    });
                }
            } else {
                toastr.error(antimenaParams.promptRequired, palleonParams.error);
            }
        } else {
            toastr.error(antimenaParams.apiKeyRequired, palleonParams.error);
        }
    });

    /* IMAGE EDIT */
    selector.find('#oai-edit').on("click", function () {
        if (oaiApiKey != '') {
            var prompt = selector.find('#oai-edit-prompt').val();
            if (prompt.length >= 1) {
                if (antimenaParams.allowedUser === 'no') {
                    var cost = parseInt(antimenaParams.oaiCost);
                    var userCredits = parseInt(selector.find('#antimena-user-credits').html());
                    if (cost > userCredits) {
                        toastr.error(antimenaParams.creditsError, palleonParams.error);
                        return;
                    }
                }
                if (canvas.width != canvas.height) {
                    toastr.error(antimenaParams.square, palleonParams.error);
                    return;
                }
                var answer = window.confirm(antimenaParams.answer3);
                if (answer) {
                    selector.find('#palleon-canvas-loader').css('display', 'flex');
                    canvas.clone(function(canvas) {
                        canvas.setZoom(1);
                        selector.find('#palleon-resize-width').trigger('sizeChanged');
                        selector.find('#palleon-resize-height').trigger('sizeChanged');
                        canvas.setWidth(selector.find('#palleon-resize-width').data('size'));
                        canvas.setHeight(selector.find('#palleon-resize-height').data('size'));
                        var size = selector.find('#oai-edit-size').val();
                        var image = canvas.toDataURL({ format: 'png', enableRetinaScaling: false});
                        var blob = aiDataURLtoBlob(image);
                        var file = new File([blob], "image.png");
                        var form = new FormData();
                        form.append('image', file);
                        form.append('prompt', prompt);
                        form.append('size', size); 
                        form.append('response_format', 'b64_json');
                        form.append('n', 1);

                        fetch('https://api.openai.com/v1/images/edits', {
                            method: 'POST',
                            headers: {
                                'Authorization': 'Bearer ' + oaiApiKey,
                            },
                            body: form,
                            redirect: 'follow',
                        }).then(oaiHandleErrors).then(response => response.json()).then(data => {
                            $(document).trigger( "loadBase64Img", ["data:image/png;base64," + data.data[0].b64_json, ""] );
                            if (antimenaParams.allowedUser === 'no') {
                                var credits = antimenaParams.oaiCost;
                                user_balance_update(credits);
                            }
                        }).catch(err => {
                            toastr.error(err, palleonParams.error);
                            selector.find('#palleon-canvas-loader').css('display', 'none');
                        });
                        canvas.dispose();
                    });
                }
            } else {
                toastr.error(antimenaParams.promptRequired, palleonParams.error);
            }
        } else {
            toastr.error(antimenaParams.apiKeyRequired, palleonParams.error);
        }
    });

    /* IMAGE VARIATION */
    selector.find('#oai-variation').on("click", function () {
        if (oaiApiKey != '') {
            if (antimenaParams.allowedUser === 'no') {
                var cost = parseInt(antimenaParams.oaiCost);
                var userCredits = parseInt(selector.find('#antimena-user-credits').html());
                if (cost > userCredits) {
                    toastr.error(antimenaParams.creditsError, palleonParams.error);
                    return;
                }
            }
            if (canvas.width != canvas.height) {
                toastr.error(antimenaParams.square, palleonParams.error);
                return;
            }
            var canvasWidth = selector.find('#palleon-resize-width').val();    
            if (canvasWidth != 1024 && canvasWidth != 512 && canvasWidth != 256) {
                toastr.error(antimenaParams.square256, palleonParams.error);
                return;
            }
            var answer = window.confirm(antimenaParams.answer7);
            if (answer) {
                selector.find('#palleon-canvas-loader').css('display', 'flex');
                canvas.clone(function(tempCanvas) {
                    var tempObjects = tempCanvas.getObjects();
                    tempObjects.filter(element => element.objectType != 'BG').forEach(element => tempCanvas.remove(element));
                    tempCanvas.setZoom(1);
                    selector.find('#palleon-resize-width').trigger('sizeChanged');
                    selector.find('#palleon-resize-height').trigger('sizeChanged');
                    tempCanvas.setWidth(selector.find('#palleon-resize-width').data('size'));
                    tempCanvas.setHeight(selector.find('#palleon-resize-height').data('size'));

                    var size = tempCanvas.width + 'x' + tempCanvas.width;
                    var image = tempCanvas.toDataURL({ format: 'png', enableRetinaScaling: false});
                    var blob = aiDataURLtoBlob(image);
                    var file = new File([blob], "image.png");
                    var form = new FormData();
                    form.append('image', file);
                    form.append('size', size); 
                    form.append('response_format', 'b64_json');
                    form.append('n', 1);

                    fetch('https://api.openai.com/v1/images/variations', {
                        method: 'POST',
                        headers: {
                            'Authorization': 'Bearer ' + oaiApiKey,
                        },
                        body: form,
                        redirect: 'follow',
                    }).then(oaiHandleErrors).then(response => response.json()).then(data => {
                        selector.find('#palleon-canvas-img').attr("src","data:image/png;base64," + data.data[0].b64_json);

                        // Wait for the placeholder image fully load
                        selector.find('#palleon-canvas-img-wrap').imagesLoaded( function() {
                            var imgurl = selector.find('#palleon-canvas-img').attr("src");
                            fabric.Image.fromURL(imgurl, function(img) {
                                canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas), {
                                    objectType: 'BG',
                                    mode: 'image',
                                    top: canvas.backgroundImage['top'], 
                                    left: canvas.backgroundImage['left'],
                                    scaleX: canvas.backgroundImage['scaleX'],
                                    scaleY: canvas.backgroundImage['scaleY'],
                                    selectable: false,
                                    angle: canvas.backgroundImage['angle'], 
                                    originX: canvas.backgroundImage['originX'], 
                                    originY: canvas.backgroundImage['originY'],
                                    lockMovementX: true,
                                    lockMovementY: true,
                                    lockRotation: true,
                                    erasable: true
                                }, { crossOrigin: 'anonymous' });
                                setTimeout(function(){ 
                                    selector.find('#palleon-canvas-loader').hide();
                                }, 500);
                            }); 
                        });

                        if (antimenaParams.allowedUser === 'no') {
                            var credits = antimenaParams.oaiCost;
                            user_balance_update(credits);
                        }
                    }).catch(err => {
                        toastr.error(err, palleonParams.error);
                        selector.find('#palleon-canvas-loader').css('display', 'none');
                    });
                    tempCanvas.dispose();
                });
            }
        } else {
            toastr.error(antimenaParams.apiKeyRequired, palleonParams.error);
        }
    });

    ///////////////* STABILITY.AI *///////////////

    // Get API key
    var stabilityaiApiKey = '';
    function stabilityai_api_key() {
        var data = {
            'action': 'stabilityaiApiKey',
            'nonce': palleonParams.nonce
        };
        $.ajax({
            url : palleonParams.ajaxurl,
            data : data,
            type : 'POST',
            success: function(data){
                if(data) {
                    stabilityaiApiKey = data;
                }
            },
            error: function(jqXHR,error, errorThrown) {
                if(jqXHR.status&&jqXHR.status==400){
                    console.log(jqXHR.responseText);
                }else{
                    console.log(palleonParams.wrong);
                }
           },
        });
    };
    stabilityai_api_key();

    // Check account balance button
    selector.find('#sai-balance-check').on("click", function () {
        var button = $(this),
        data = {
            'action': 'saiBalance',
            'nonce': palleonParams.nonce
        };
        $.ajax({
            url : palleonParams.ajaxurl,
            data : data,
            type : 'POST',
            beforeSend: function ( xhr ) {
                button.addClass('loading');
            },
            success: function(data){
                if(data) {
                    data = $.parseJSON(data);
                    if (data.message !== undefined) {
                        toastr.error(data.message, palleonParams.error);
                    } else if (data.balance !== undefined){
                        selector.find('#sai-balance').html(data.balance);
                    } else {
                        toastr.error(palleonParams.wrong, palleonParams.error);
                    }
                }
            },
            error: function(jqXHR,error, errorThrown) {
                if(jqXHR.status&&jqXHR.status==400){
                    toastr.error(jqXHR.responseText, palleonParams.error);
                }else{
                    toastr.error(palleonParams.wrong, palleonParams.error);
                }
                button.removeClass('loading');
           }
        }).done(function( response ) {
            button.removeClass('loading');
        });
    });

    // Enable & disable generate buttons
    selector.find('#sai-prompt').on("input paste", function () {
        var val = $(this).val();
        if (val.length >= 1) {
            selector.find('#sai-image-generate').prop('disabled', false);
        } else {
            selector.find('#sai-image-generate').prop('disabled', true);
        }
    });

    selector.find('#sai-imgtoimg-prompt').on("input paste", function () {
        var val = $(this).val();
        if (val.length >= 1) {
            selector.find('#sai-imgtoimg-generate').prop('disabled', false);
        } else {
            selector.find('#sai-imgtoimg-generate').prop('disabled', true);
        }
    });

    /* GENERATE NEW IMAGE */
    selector.find('#sai-image-generate').on("click", function () {
        if (stabilityaiApiKey != '') {
            var prompt = selector.find('#sai-prompt').val();
            if (prompt.length >= 1) {
                if (antimenaParams.allowedUser === 'no') {
                    var cost = parseInt(antimenaParams.saiCost);
                    var userCredits = parseInt(selector.find('#antimena-user-credits').html());
                    if (cost > userCredits) {
                        toastr.error(antimenaParams.creditsError, palleonParams.error);
                        return;
                    }
                }
                var answer = window.confirm(antimenaParams.answer2);
                if (answer) {
                    var negativePrompt = selector.find('#sai-negative-prompt').val(),
                    ratio = selector.find('#sai-ratio').find(":selected").val(),
                    seed = selector.find('#sai-seed').val(),
                    presets = selector.find('#sai-style-presets').find(":selected").val();

                    var form = new FormData();
                    form.append('prompt', prompt);
                    if (negativePrompt != '') {
                        form.append('negative_prompt', negativePrompt);
                    }
                    form.append('aspect_ratio', ratio);
                    if (seed != '') {
                        form.append('seed', seed);
                    }
                    if (presets != '') {
                        form.append('style_preset', presets);
                    }

                    $.ajax({
                        url : 'https://api.stability.ai/v2beta/stable-image/generate/core',
                        data : form,
                        contentType: false,
                        processData: false,
                        crossDomain: true,
                        type : 'POST',
                        headers: {
                            "Accept": "application/json",
                            "Authorization": "Bearer " + stabilityaiApiKey,
                            "Stability-Client-ID": "Antimena", // Optional
                            "Stability-Client-Version": "1.0" // Optional
                        },
                        beforeSend: function ( xhr ) {
                            selector.find('#modal-ai-image').css('pointer-events', 'none');
                            selector.find('#antimena-loader-1').css('display', 'flex');
                        },
                        success: function(data){
                            if(data) {
                                var output = '<div class="palleon-masonry-item"> <div class="palleon-masonry-item-inner"> <div class="palleon-img-wrap"> <img id="' + data.seed + '" src="data:image/png;base64,' + data.image + '" /> </div> <div class="antimena-img-card"> <div class="antimena-img-card-inner"> <div class="antimena-img-seed-wrap"> <span>Seed:</span> <input id="antimena-img-seed" class="palleon-form-field" type="text" value="' + data.seed + '" autocomplete="off" readonly> </div> <div class="antimena-img-btns"> <button type="button" class="palleon-btn btn-full antimena-img-download" autocomplete="off" data-seed="' + data.seed + '"><span class="material-icons arrow">download</span>' + antimenaParams.download + '</button> <button type="button" class="palleon-btn btn-full antimena-img-save" autocomplete="off" data-seed="' + data.seed + '"><span class="material-icons arrow">save</span>' + antimenaParams.save + '</button> <button type="button" class="palleon-btn btn-full primary antimena-img-select" autocomplete="off" data-seed="' + data.seed + '"><span class="material-icons arrow">done</span>' + antimenaParams.select + '</button> </div> </div> </div> </div> </div>';
                                selector.find('#sai-images').html('');
                                selector.find('#sai-images').removeClass('antimena-grid-placeholder');
                                selector.find('#sai-images').html(output);
                                if (antimenaParams.allowedUser === 'no') {
                                    var credits = antimenaParams.saiCost;
                                    user_balance_update(credits);
                                }
                            }
                        },
                        error: function(jqXHR,error, errorThrown) {
                            if (jqXHR.status && jqXHR.responseText){
                                var parsejson = JSON.parse(jqXHR.responseText);
                                toastr.error(parsejson.errors, jqXHR.status + ' ' + palleonParams.error);
                            } else if (jqXHR.status) {
                                toastr.error(palleonParams.wrong, jqXHR.status);
                            } else {
                                toastr.error(palleonParams.wrong, palleonParams.error);
                            }
                            selector.find('#modal-ai-image').css('pointer-events', 'auto');
                            selector.find('#antimena-loader-1').css('display', 'none');
                    }
                    }).done(function( response ) {
                        selector.find('#modal-ai-image').css('pointer-events', 'auto');
                        selector.find('#antimena-loader-1').css('display', 'none');
                    });
                }
            } else {
                toastr.error(antimenaParams.promptRequired, palleonParams.error);
            }
        } else {
            toastr.error(antimenaParams.apiKeyRequired, palleonParams.error);
        }
    });

    /* REGENERATOR */
    selector.find('#sai-imgtoimg-generate').on("click", function () {
        if (stabilityaiApiKey != '') {
            var prompt = selector.find('#sai-imgtoimg-prompt').val();
            if (prompt.length >= 1) {
                if (antimenaParams.allowedUser === 'no') {
                    var cost = parseInt(antimenaParams.saiCost);
                    var userCredits = parseInt(selector.find('#antimena-user-credits').html());
                    if (cost > userCredits) {
                        toastr.error(antimenaParams.creditsError, palleonParams.error);
                        return;
                    }
                }
                var answer = window.confirm(antimenaParams.answer3);
                if (answer) {
                    selector.find('#palleon-canvas-loader').css('display', 'flex');
                    var negativePrompt = selector.find('#sai-imgtoimg-negative-prompt').val(),
                    seed = selector.find('#sai-imgtoimg-seed').val(),
                    mask = '',
                    image = '';
                    canvas.clone(function(tempCanvas) {
                        tempCanvas.setZoom(1);
                        selector.find('#palleon-resize-width').trigger('sizeChanged');
                        selector.find('#palleon-resize-height').trigger('sizeChanged');
                        tempCanvas.setWidth(selector.find('#palleon-resize-width').data('size'));
                        tempCanvas.setHeight(selector.find('#palleon-resize-height').data('size'));
                        image = tempCanvas.toDataURL({ format: 'png', enableRetinaScaling: false});
                        var form = new FormData();
                        var blob = aiDataURLtoBlob(image);
                        var file = new File([blob], "image.png");
                        form.append('image', file);
                        form.append('prompt', prompt);
                        if (negativePrompt != '') {
                            form.append('negative_prompt', negativePrompt);
                        }
                        if (seed != '') {
                            form.append('seed', seed);
                        }
                        if (!selector.find('#sai-imgtoimg-mask').is(':checked')) {
                            tempCanvas.getObjects().filter(element => element.type != 'path').forEach(element => tempCanvas.remove(element));
                            tempCanvas.backgroundColor = 'rgb(255,255,255)';
                            tempCanvas.setBackgroundImage(null);
                            tempCanvas.requestRenderAll();
                            mask = tempCanvas.toDataURL({ format: 'png', enableRetinaScaling: false});
                            var maskblob = aiDataURLtoBlob(mask);
                            var maskfile = new File([maskblob], "mask.png");
                            form.append('mask', maskfile);
                        }          
                        $.ajax({
                            url : 'https://api.stability.ai/v2beta/stable-image/edit/inpaint',
                            data : form,
                            contentType: false,
                            processData: false,
                            crossDomain: true,
                            type : 'POST',
                            headers: {
                                "Accept": "application/json",
                                "Authorization": "Bearer " + stabilityaiApiKey,
                                "Stability-Client-ID": "Antimena", // Optional
                                "Stability-Client-Version": "1.0" // Optional
                            },
                            success: function(data){
                                if(data) {
                                    selector.find('#sai-imgtoimg-seed').val(data.seed);
                                    $(document).trigger( "loadBase64Img", ["data:image/png;base64," + data.image, data.seed] );
                                    if (antimenaParams.allowedUser === 'no') {
                                        var credits = antimenaParams.saiCost;
                                        user_balance_update(credits);
                                    }
                                }
                            },
                            error: function(jqXHR,error, errorThrown) {
                                if (jqXHR.status && jqXHR.responseText){
                                    var parsejson = JSON.parse(jqXHR.responseText);
                                    toastr.error(parsejson.errors, jqXHR.status + ' ' + palleonParams.error);
                                } else if (jqXHR.status) {
                                    toastr.error(palleonParams.wrong, jqXHR.status);
                                } else {
                                    toastr.error(palleonParams.wrong, palleonParams.error);
                                }
                                selector.find('#palleon-canvas-loader').css('display', 'none');
                        }
                        });
                        tempCanvas.dispose();
                    });
                }
            } else {
                toastr.error(antimenaParams.promptRequired, palleonParams.error);
            }
        } else {
            toastr.error(antimenaParams.apiKeyRequired, palleonParams.error);
        }
    });

    /* UPSCALER */
    selector.find('#sai-upscale').on("click", function () {
        if (stabilityaiApiKey != '') {
            var width = parseInt(selector.find('#palleon-resize-width').val());
            var height = parseInt(selector.find('#palleon-resize-height').val());
            if (width > 1536 || height > 1536) {
                toastr.error(antimenaParams.tooBigInfo4, antimenaParams.tooBig);
                return;
            }
            if (antimenaParams.allowedUser === 'no') {
                var cost = parseInt(antimenaParams.saiCost);
                var userCredits = parseInt(selector.find('#antimena-user-credits').html());
                if (cost > userCredits) {
                    toastr.error(antimenaParams.creditsError, palleonParams.error);
                    return;
                }
            }
            var answer = window.confirm(antimenaParams.answer1);
            if (answer) {
                selector.find('#palleon-canvas-loader').css('display', 'flex');
                canvas.clone(function(tempCanvas) {
                    tempCanvas.setZoom(1);
                    selector.find('#palleon-resize-width').trigger('sizeChanged');
                    selector.find('#palleon-resize-height').trigger('sizeChanged');
                    tempCanvas.setWidth(selector.find('#palleon-resize-width').data('size'));
                    tempCanvas.setHeight(selector.find('#palleon-resize-height').data('size'));
                    var image = tempCanvas.toDataURL({ format: 'png', enableRetinaScaling: false});
                    var form = new FormData();
                    var blob = aiDataURLtoBlob(image);
                    var file = new File([blob], "image.png");
                    form.append('image', file);
                    
                    $.ajax({
                        url : 'https://api.stability.ai/v2beta/stable-image/upscale/fast',
                        data : form,
                        contentType: false,
                        processData: false,
                        crossDomain: true,
                        type : 'POST',
                        headers: {
                            "Accept": "application/json",
                            "Authorization": "Bearer " + stabilityaiApiKey,
                            "Stability-Client-ID": "Antimena", // Optional
                            "Stability-Client-Version": "1.0" // Optional
                        },
                        success: function(data){
                            if(data) {
                                selector.find('#sai-imgtoimg-seed').val(data.seed);
                                $(document).trigger( "loadBase64Img", ["data:image/png;base64," + data.image, data.seed] );
                                if (antimenaParams.allowedUser === 'no') {
                                    var credits = antimenaParams.saiCost;
                                    user_balance_update(credits);
                                }
                            }
                        },
                        error: function(jqXHR,error, errorThrown) {
                            if (jqXHR.status && jqXHR.responseText){
                                var parsejson = JSON.parse(jqXHR.responseText);
                                toastr.error(parsejson.errors, jqXHR.status + ' ' + palleonParams.error);
                            } else if (jqXHR.status) {
                                toastr.error(palleonParams.wrong, jqXHR.status);
                            } else {
                                toastr.error(palleonParams.wrong, palleonParams.error);
                            }
                            selector.find('#palleon-canvas-loader').css('display', 'none');
                        }
                    });
                    tempCanvas.dispose();
                });
            }
        } else {
            toastr.error(antimenaParams.apiKeyRequired, palleonParams.error);
        }
    });

    /* REMOVE BG */
    selector.find('#sai-remove-background').on("click", function () {
        if (stabilityaiApiKey != '') {
            if (antimenaParams.allowedUser === 'no') {
                var cost = parseInt(antimenaParams.saiCost);
                var userCredits = parseInt(selector.find('#antimena-user-credits').html());
                if (cost > userCredits) {
                    toastr.error(antimenaParams.creditsError, palleonParams.error);
                    return;
                }
            }
            var answer = window.confirm(antimenaParams.answer4);
            if (answer) {
                selector.find('#palleon-canvas-loader').css('display', 'flex');
                canvas.clone(function(tempCanvas) {
                    var tempObjects = tempCanvas.getObjects();
                    tempObjects.filter(element => element.objectType != 'BG').forEach(element => tempCanvas.remove(element));
                    tempCanvas.setZoom(1);
                    selector.find('#palleon-resize-width').trigger('sizeChanged');
                    selector.find('#palleon-resize-height').trigger('sizeChanged');
                    tempCanvas.setWidth(selector.find('#palleon-resize-width').data('size'));
                    tempCanvas.setHeight(selector.find('#palleon-resize-height').data('size'));
                    var image = tempCanvas.toDataURL({ format: 'png', enableRetinaScaling: false});
                    var form = new FormData();
                    var blob = aiDataURLtoBlob(image);
                    var file = new File([blob], "image.png");
                    form.append('image', file);
                    
                    $.ajax({
                        url : 'https://api.stability.ai/v2beta/stable-image/edit/remove-background',
                        data : form,
                        contentType: false,
                        processData: false,
                        crossDomain: true,
                        type : 'POST',
                        headers: {
                            "Accept": "application/json",
                            "Authorization": "Bearer " + stabilityaiApiKey,
                            "Stability-Client-ID": "Antimena", // Optional
                            "Stability-Client-Version": "1.0" // Optional
                        },
                        success: function(data){
                            if(data) {
                                selector.find('#sai-imgtoimg-seed').val(data.seed);
                                $(document).trigger( "loadBase64Img", ["data:image/png;base64," + data.image, data.seed] );
                                if (antimenaParams.allowedUser === 'no') {
                                    var credits = antimenaParams.saiCost;
                                    user_balance_update(credits);
                                }
                            }
                        },
                        error: function(jqXHR,error, errorThrown) {
                            if (jqXHR.status && jqXHR.responseText){
                                var parsejson = JSON.parse(jqXHR.responseText);
                                toastr.error(parsejson.errors, jqXHR.status + ' ' + palleonParams.error);
                            } else if (jqXHR.status) {
                                toastr.error(palleonParams.wrong, jqXHR.status);
                            } else {
                                toastr.error(palleonParams.wrong, palleonParams.error);
                            }
                            selector.find('#palleon-canvas-loader').css('display', 'none');
                        }
                    });
                    tempCanvas.dispose();
                });
            }
        } else {
            toastr.error(antimenaParams.apiKeyRequired, palleonParams.error);
        }
    });

    // Erase
    selector.find('#sai-erase').on("click", function () {
        if (stabilityaiApiKey != '') {
            var drawing = canvas.getObjects().filter(element => element.type == 'path')[0];
            if (drawing) {
                if (antimenaParams.allowedUser === 'no') {
                    var cost = parseInt(antimenaParams.saiCost);
                    var userCredits = parseInt(selector.find('#antimena-user-credits').html());
                    if (cost > userCredits) {
                        toastr.error(antimenaParams.creditsError, palleonParams.error);
                        return;
                    }
                }
                var answer = window.confirm(antimenaParams.answer6);
                if (answer) {
                    selector.find('#palleon-canvas-loader').css('display', 'flex');
                    canvas.clone(function(canvas) {
                        canvas.setZoom(1);
                        selector.find('#palleon-resize-width').trigger('sizeChanged');
                        selector.find('#palleon-resize-height').trigger('sizeChanged');
                        canvas.setWidth(selector.find('#palleon-resize-width').data('size'));
                        canvas.setHeight(selector.find('#palleon-resize-height').data('size'));
                        canvas.getObjects().filter(element => element.type != 'path').forEach(element => canvas.remove(element));
                        var form = new FormData();

                        canvas.getObjects().filter(element => element.type == 'path').forEach(element => element.set({stroke: 'transparent', shadow: null}));
                        canvas.requestRenderAll();
                        var image = canvas.toDataURL({ format: 'png', enableRetinaScaling: false}),
                        blob = aiDataURLtoBlob(image),
                        file = new File([blob], "cleanup.png");
                        form.append('image', file);
                        
                        canvas.getObjects().filter(element => element.type == 'path').forEach(element => element.set('stroke', 'rgb(255,255,255)'));
                        canvas.backgroundColor = 'rgb(0,0,0)';
                        canvas.setBackgroundImage(null);
                        canvas.requestRenderAll();
                        var mask = canvas.toDataURL({ format: 'png', enableRetinaScaling: false});
                        var maskBlob = aiDataURLtoBlob(mask),
                        maskFile = new File([maskBlob], "mask.png");
                        form.append('mask', maskFile);


                        $.ajax({
                            url : 'https://api.stability.ai/v2beta/stable-image/edit/erase',
                            data : form,
                            contentType: false,
                            processData: false,
                            crossDomain: true,
                            type : 'POST',
                            headers: {
                                "Accept": "application/json",
                                "Authorization": "Bearer " + stabilityaiApiKey,
                                "Stability-Client-ID": "Antimena", // Optional
                                "Stability-Client-Version": "1.0" // Optional
                            },
                            success: function(data){
                                if(data) {
                                    selector.find('#sai-imgtoimg-seed').val(data.seed);
                                    $(document).trigger( "loadBase64Img", ["data:image/png;base64," + data.image, data.seed] );
                                    if (antimenaParams.allowedUser === 'no') {
                                        var credits = antimenaParams.saiCost;
                                        user_balance_update(credits);
                                    }
                                }
                            },
                            error: function(jqXHR,error, errorThrown) {
                                if (jqXHR.status && jqXHR.responseText){
                                    var parsejson = JSON.parse(jqXHR.responseText);
                                    toastr.error(parsejson.errors, jqXHR.status + ' ' + palleonParams.error);
                                } else if (jqXHR.status) {
                                    toastr.error(palleonParams.wrong, jqXHR.status);
                                } else {
                                    toastr.error(palleonParams.wrong, palleonParams.error);
                                }
                                selector.find('#palleon-canvas-loader').css('display', 'none');
                            }
                        });
                        canvas.dispose();
                    });
                }
            } else {
                toastr.warning(antimenaParams.nodrawing, palleonParams.warning);
            }
        } else {
            toastr.error(antimenaParams.apiKeyRequired, palleonParams.error);
        }
    });

    // Outpaint
    selector.find('#sai-outpaint').on("click", function () {
        if (stabilityaiApiKey != '') {
            var extend_top = selector.find('#sai-extend-top').val();
            var extend_bottom = selector.find('#sai-extend-bottom').val();
            var extend_left = selector.find('#sai-extend-left').val();
            var extend_right = selector.find('#sai-extend-right').val();
            if (antimenaParams.allowedUser === 'no') {
                var cost = parseInt(antimenaParams.saiCost);
                var userCredits = parseInt(selector.find('#antimena-user-credits').html());
                if (cost > userCredits) {
                    toastr.error(antimenaParams.creditsError, palleonParams.error);
                    return;
                }
            }
            var answer = window.confirm(antimenaParams.answer8);
            if (answer) {
                selector.find('#palleon-canvas-loader').css('display', 'flex');
                canvas.clone(function(canvas) {
                    canvas.setZoom(1);
                    selector.find('#palleon-resize-width').trigger('sizeChanged');
                    selector.find('#palleon-resize-height').trigger('sizeChanged');
                    canvas.setWidth(selector.find('#palleon-resize-width').data('size'));
                    canvas.setHeight(selector.find('#palleon-resize-height').data('size'));
                    var image = canvas.toDataURL({ format: 'png', enableRetinaScaling: false}),
                    blob = aiDataURLtoBlob(image),
                    file = new File([blob], "uncrop.png"),
                    form = new FormData();
                    form.append('image', file);
                    form.append('up', extend_top);
                    form.append('down', extend_bottom);
                    form.append('left', extend_left);
                    form.append('right', extend_right);

                    $.ajax({
                        url : 'https://api.stability.ai/v2beta/stable-image/edit/outpaint',
                        data : form,
                        contentType: false,
                        processData: false,
                        crossDomain: true,
                        type : 'POST',
                        headers: {
                            "Accept": "application/json",
                            "Authorization": "Bearer " + stabilityaiApiKey,
                            "Stability-Client-ID": "Antimena", // Optional
                            "Stability-Client-Version": "1.0" // Optional
                        },
                        success: function(data){
                            if(data) {
                                selector.find('#sai-imgtoimg-seed').val(data.seed);
                                $(document).trigger( "loadBase64Img", ["data:image/png;base64," + data.image, data.seed] );
                                if (antimenaParams.allowedUser === 'no') {
                                    var credits = antimenaParams.saiCost;
                                    user_balance_update(credits);
                                }
                            }
                        },
                        error: function(jqXHR,error, errorThrown) {
                            if (jqXHR.status && jqXHR.responseText){
                                var parsejson = JSON.parse(jqXHR.responseText);
                                toastr.error(parsejson.errors, jqXHR.status + ' ' + palleonParams.error);
                            } else if (jqXHR.status) {
                                toastr.error(palleonParams.wrong, jqXHR.status);
                            } else {
                                toastr.error(palleonParams.wrong, palleonParams.error);
                            }
                            selector.find('#palleon-canvas-loader').css('display', 'none');
                        }
                    });
                    canvas.dispose();         
                });
            }
        } else {
            toastr.error(antimenaParams.apiKeyRequired, palleonParams.error);
        }
    });

    /* SEARCH & REPLACE */
    selector.find('#sai-replace').on("click", function () {
        if (stabilityaiApiKey != '') {
            var prompt = selector.find('#sai-replace-prompt').val();
            var searchPrompt = selector.find('#sai-replace-search-prompt').val();
            if (prompt.length >= 1 && searchPrompt.length >= 1) {
                if (antimenaParams.allowedUser === 'no') {
                    var cost = parseInt(antimenaParams.saiCost);
                    var userCredits = parseInt(selector.find('#antimena-user-credits').html());
                    if (cost > userCredits) {
                        toastr.error(antimenaParams.creditsError, palleonParams.error);
                        return;
                    }
                }
                var answer = window.confirm(antimenaParams.answer3);
                if (answer) {
                    selector.find('#palleon-canvas-loader').css('display', 'flex');
                    canvas.clone(function(tempCanvas) {
                        var tempObjects = tempCanvas.getObjects();
                        tempObjects.filter(element => element.objectType != 'BG').forEach(element => tempCanvas.remove(element));
                        tempCanvas.setZoom(1);
                        selector.find('#palleon-resize-width').trigger('sizeChanged');
                        selector.find('#palleon-resize-height').trigger('sizeChanged');
                        tempCanvas.setWidth(selector.find('#palleon-resize-width').data('size'));
                        tempCanvas.setHeight(selector.find('#palleon-resize-height').data('size'));
                        var image = tempCanvas.toDataURL({ format: 'png', enableRetinaScaling: false});
                        var form = new FormData();
                        var blob = aiDataURLtoBlob(image);
                        var file = new File([blob], "image.png");
                        form.append('image', file);
                        form.append('prompt', prompt);
                        form.append('search_prompt', searchPrompt);
                        
                        $.ajax({
                            url : 'https://api.stability.ai/v2beta/stable-image/edit/search-and-replace',
                            data : form,
                            contentType: false,
                            processData: false,
                            crossDomain: true,
                            type : 'POST',
                            headers: {
                                "Accept": "application/json",
                                "Authorization": "Bearer " + stabilityaiApiKey,
                                "Stability-Client-ID": "Antimena", // Optional
                                "Stability-Client-Version": "1.0" // Optional
                            },
                            success: function(data){
                                if(data) {
                                    selector.find('#sai-imgtoimg-seed').val(data.seed);
                                    $(document).trigger( "loadBase64Img", ["data:image/png;base64," + data.image, data.seed] );
                                    if (antimenaParams.allowedUser === 'no') {
                                        var credits = antimenaParams.saiCost;
                                        user_balance_update(credits);
                                    }
                                }
                            },
                            error: function(jqXHR,error, errorThrown) {
                                if (jqXHR.status && jqXHR.responseText){
                                    var parsejson = JSON.parse(jqXHR.responseText);
                                    toastr.error(parsejson.errors, jqXHR.status + ' ' + palleonParams.error);
                                } else if (jqXHR.status) {
                                    toastr.error(palleonParams.wrong, jqXHR.status);
                                } else {
                                    toastr.error(palleonParams.wrong, palleonParams.error);
                                }
                                selector.find('#palleon-canvas-loader').css('display', 'none');
                            }
                        });
                        tempCanvas.dispose();
                    });
                }
            } else {
                toastr.error(antimenaParams.promptRequired, palleonParams.error);
            }
        } else {
            toastr.error(antimenaParams.apiKeyRequired, palleonParams.error);
        }
    });

    /* SEARCH & RECOLOR */
    selector.find('#sai-recolor').on("click", function () {
        if (stabilityaiApiKey != '') {
            var prompt = selector.find('#sai-recolor-prompt').val();
            var selectPrompt = selector.find('#sai-recolor-select-prompt').val();
            if (prompt.length >= 1 && selectPrompt.length >= 1) {
                if (antimenaParams.allowedUser === 'no') {
                    var cost = parseInt(antimenaParams.saiCost);
                    var userCredits = parseInt(selector.find('#antimena-user-credits').html());
                    if (cost > userCredits) {
                        toastr.error(antimenaParams.creditsError, palleonParams.error);
                        return;
                    }
                }
                var answer = window.confirm(antimenaParams.answer3);
                if (answer) {
                    selector.find('#palleon-canvas-loader').css('display', 'flex');
                    canvas.clone(function(tempCanvas) {
                        var tempObjects = tempCanvas.getObjects();
                        tempObjects.filter(element => element.objectType != 'BG').forEach(element => tempCanvas.remove(element));
                        tempCanvas.setZoom(1);
                        selector.find('#palleon-resize-width').trigger('sizeChanged');
                        selector.find('#palleon-resize-height').trigger('sizeChanged');
                        tempCanvas.setWidth(selector.find('#palleon-resize-width').data('size'));
                        tempCanvas.setHeight(selector.find('#palleon-resize-height').data('size'));
                        var image = tempCanvas.toDataURL({ format: 'png', enableRetinaScaling: false});
                        var form = new FormData();
                        var blob = aiDataURLtoBlob(image);
                        var file = new File([blob], "image.png");
                        form.append('image', file);
                        form.append('prompt', prompt);
                        form.append('select_prompt', selectPrompt);
                        $.ajax({
                            url : 'https://api.stability.ai/v2beta/stable-image/edit/search-and-recolor',
                            data : form,
                            contentType: false,
                            processData: false,
                            crossDomain: true,
                            type : 'POST',
                            headers: {
                                "Accept": "application/json",
                                "Authorization": "Bearer " + stabilityaiApiKey,
                                "Stability-Client-ID": "Antimena", // Optional
                                "Stability-Client-Version": "1.0" // Optional
                            },
                            success: function(data){
                                if(data) {
                                    selector.find('#sai-imgtoimg-seed').val(data.seed);
                                    $(document).trigger( "loadBase64Img", ["data:image/png;base64," + data.image, data.seed] );
                                    if (antimenaParams.allowedUser === 'no') {
                                        var credits = antimenaParams.saiCost;
                                        user_balance_update(credits);
                                    }
                                }
                            },
                            error: function(jqXHR,error, errorThrown) {
                                if (jqXHR.status && jqXHR.responseText){
                                    var parsejson = JSON.parse(jqXHR.responseText);
                                    toastr.error(parsejson.errors, jqXHR.status + ' ' + palleonParams.error);
                                } else if (jqXHR.status) {
                                    toastr.error(palleonParams.wrong, jqXHR.status);
                                } else {
                                    toastr.error(palleonParams.wrong, palleonParams.error);
                                }
                                selector.find('#palleon-canvas-loader').css('display', 'none');
                            }
                        });
                        tempCanvas.dispose();
                    });
                }
            } else {
                toastr.error(antimenaParams.promptRequired, palleonParams.error);
            }
        } else {
            toastr.error(antimenaParams.apiKeyRequired, palleonParams.error);
        }
    });

    ///////////////* CLIPDROP *///////////////

    // Get API key
    var clipdropApiKey = '';
    function clipdrop_api_key() {
        var data = {
            'action': 'clipdropApiKey',
            'nonce': palleonParams.nonce
        };
        $.ajax({
            url : palleonParams.ajaxurl,
            data : data,
            type : 'POST',
            success: function(data){
                if(data) {
                    clipdropApiKey = data;
                }
            },
            error: function(jqXHR,error, errorThrown) {
                if(jqXHR.status&&jqXHR.status==400){
                    console.log(jqXHR.responseText);
                }else{
                    console.log(palleonParams.wrong);
                }
           },
        });
    };
    clipdrop_api_key();

    // Text to image
    selector.find('#clipdrop-image-generate').on("click", function () {
        if (clipdropApiKey != '') {
            var prompt = selector.find('#clipdrop-prompt').val();
            if (prompt.length >= 1) {
                if (antimenaParams.allowedUser === 'no') {
                    var cost = parseInt(antimenaParams.clipdropTextCost);
                    var userCredits = parseInt(selector.find('#antimena-user-credits').html());
                    if (cost > userCredits) {
                        toastr.error(antimenaParams.creditsError, palleonParams.error);
                        return;
                    }
                }
                var answer = window.confirm(antimenaParams.answer2);
                if (answer) {
                    selector.find('#modal-ai-image').css('pointer-events', 'none');
                    selector.find('#antimena-loader-2').css('display', 'flex');
                    var form = new FormData();
                    form.append('prompt', prompt);
                    fetch('https://clipdrop-api.co/text-to-image/v1', {
                        method: 'POST',
                        headers: {
                            'x-api-key': clipdropApiKey,
                        },
                        body: form,
                        redirect: 'follow',
                    }).then(clipdropHandleErrors).then(response => response.arrayBuffer()).then(buffer => {
                        var id = new Date().getTime();
                        var data = '<div class="palleon-masonry-item"><div class="palleon-masonry-item-inner"><div class="palleon-img-wrap"><img id="' + id + '" src="data:image/png;base64,' + arrayBufferToBase64(buffer) + '" /></div><div class="antimena-img-card"><div class="antimena-img-card-inner"><div class="antimena-img-btns"><button type="button" class="palleon-btn btn-full antimena-img-download" autocomplete="off" data-seed="' + id + '"><span class="material-icons arrow">download</span>' + antimenaParams.download + '</button><button type="button" class="palleon-btn btn-full antimena-img-save" autocomplete="off" data-seed="' + id + '"><span class="material-icons arrow">save</span>' + antimenaParams.save + '</button><button type="button" class="palleon-btn btn-full primary antimena-img-select" autocomplete="off" data-seed="' + id + '"><span class="material-icons arrow">done</span>' + antimenaParams.select + '</button></div></div></div></div></div>';    
                        selector.find('#clipdrop-images').html('');
                        selector.find('#clipdrop-images').removeClass('antimena-grid-placeholder');
                        selector.find('#clipdrop-images').html(data);
                        selector.find('#modal-ai-image').css('pointer-events', 'auto');
                        selector.find('#antimena-loader-2').hide();
                        if (antimenaParams.allowedUser === 'no') {
                            var credits = antimenaParams.clipdropTextCost;
                            user_balance_update(credits);
                        }
                    }).catch(err => {
                        toastr.error(err, palleonParams.error);
                        selector.find('#antimena-loader-2').hide();
                    }); 
                }
            }
        } else {
            toastr.error(antimenaParams.apiKeyRequired, palleonParams.error);
        }
    });

    // Enable & disable generate button
    selector.find('#clipdrop-prompt').on("input paste", function () {
        var val = $(this).val();
        if (val.length >= 1) {
            selector.find('#clipdrop-image-generate').prop('disabled', false);
        } else {
            selector.find('#clipdrop-image-generate').prop('disabled', true);
        }
    });

    // Remove background
    selector.find('#clipdrop-remove-background').on("click", function () {
        if (clipdropApiKey != '') {
            if (antimenaParams.allowedUser === 'no') {
                var cost = parseInt(antimenaParams.clipdropOthersCost);
                var userCredits = parseInt(selector.find('#antimena-user-credits').html());
                if (cost > userCredits) {
                    toastr.error(antimenaParams.creditsError, palleonParams.error);
                    return;
                }
            }
            var answer = window.confirm(antimenaParams.answer4);
            if (answer) {
                selector.find('#palleon-canvas-loader').css('display', 'flex');
                canvas.clone(function(tempCanvas) {
                    var tempObjects = tempCanvas.getObjects();
                    tempObjects.filter(element => element.objectType != 'BG').forEach(element => tempCanvas.remove(element));
                    tempCanvas.setZoom(1);
                    selector.find('#palleon-resize-width').trigger('sizeChanged');
                    selector.find('#palleon-resize-height').trigger('sizeChanged');
                    tempCanvas.setWidth(selector.find('#palleon-resize-width').data('size'));
                    tempCanvas.setHeight(selector.find('#palleon-resize-height').data('size'));
                    var image = tempCanvas.toDataURL({ format: 'png', enableRetinaScaling: false}),
                    blob = aiDataURLtoBlob(image),
                    file = new File([blob], "removebg.png"),
                    form = new FormData();
                    form.append('image_file', file);
                    fetch('https://clipdrop-api.co/remove-background/v1', {
                        method: 'POST',
                        headers: {
                            'x-api-key': clipdropApiKey,
                        },
                        body: form,
                        redirect: 'follow',
                    }).then(clipdropHandleErrors).then(response => response.arrayBuffer()).then(buffer => {
                        selector.find('#palleon-canvas-img').attr("src","data:image/png;base64," + arrayBufferToBase64(buffer));

                        // Wait for the placeholder image fully load
                        selector.find('#palleon-canvas-img-wrap').imagesLoaded( function() {
                            var imgurl = selector.find('#palleon-canvas-img').attr("src");
                            fabric.Image.fromURL(imgurl, function(img) {
                                canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas), {
                                    objectType: 'BG',
                                    mode: 'image',
                                    top: canvas.backgroundImage['top'], 
                                    left: canvas.backgroundImage['left'],
                                    scaleX: canvas.backgroundImage['scaleX'],
                                    scaleY: canvas.backgroundImage['scaleY'],
                                    selectable: false,
                                    angle: canvas.backgroundImage['angle'], 
                                    originX: canvas.backgroundImage['originX'], 
                                    originY: canvas.backgroundImage['originY'],
                                    lockMovementX: true,
                                    lockMovementY: true,
                                    lockRotation: true,
                                    erasable: true
                                }, { crossOrigin: 'anonymous' });
                                setTimeout(function(){ 
                                    selector.find('#palleon-canvas-loader').hide();
                                }, 500);
                            }); 
                        });

                        if (antimenaParams.allowedUser === 'no') {
                            var credits = antimenaParams.clipdropOthersCost;
                            user_balance_update(credits);
                        }
                    }).catch(err => {
                        toastr.error(err, palleonParams.error);
                        selector.find('#palleon-canvas-loader').css('display', 'none');
                    });
                    tempCanvas.dispose();         
                });
            }
        } else {
            toastr.error(antimenaParams.apiKeyRequired, palleonParams.error);
        }
    });

    // Enable & disable remove background button
    selector.find('#clipdrop-replace-bg-prompt').on("input paste", function () {
        var val = $(this).val();
        if (val.length >= 1) {
            selector.find('#clipdrop-replace-background').prop('disabled', false);
        } else {
            selector.find('#clipdrop-replace-background').prop('disabled', true);
        }
    });

    // Replace background
    selector.find('#clipdrop-replace-background').on("click", function () {
        if (clipdropApiKey != '') {
            var prompt = selector.find('#clipdrop-replace-bg-prompt').val();
            if (prompt.length >= 1) {
                if (antimenaParams.allowedUser === 'no') {
                    var cost = parseInt(antimenaParams.clipdropReplaceCost);
                    var userCredits = parseInt(selector.find('#antimena-user-credits').html());
                    if (cost > userCredits) {
                        toastr.error(antimenaParams.creditsError, palleonParams.error);
                        return;
                    }
                }
                var answer = window.confirm(antimenaParams.answer4);
                if (answer) {
                    selector.find('#palleon-canvas-loader').css('display', 'flex');
                    canvas.clone(function(tempCanvas) {
                        var tempObjects = tempCanvas.getObjects();
                        tempObjects.filter(element => element.objectType != 'BG').forEach(element => tempCanvas.remove(element));
                        tempCanvas.setZoom(1);
                        selector.find('#palleon-resize-width').trigger('sizeChanged');
                        selector.find('#palleon-resize-height').trigger('sizeChanged');
                        tempCanvas.setWidth(selector.find('#palleon-resize-width').data('size'));
                        tempCanvas.setHeight(selector.find('#palleon-resize-height').data('size'));
                        var image = tempCanvas.toDataURL({ format: 'png', enableRetinaScaling: false}),
                        blob = aiDataURLtoBlob(image),
                        file = new File([blob], "replacebg.png"),
                        form = new FormData();
                        form.append('image_file', file);
                        form.append('prompt', prompt);
                        fetch('https://clipdrop-api.co/replace-background/v1', {
                            method: 'POST',
                            headers: {
                                'x-api-key': clipdropApiKey,
                            },
                            body: form,
                            redirect: 'follow',
                        }).then(clipdropHandleErrors).then(response => response.arrayBuffer()).then(buffer => {
                            selector.find('#palleon-canvas-img').attr("src","data:image/png;base64," + arrayBufferToBase64(buffer));

                            // Wait for the placeholder image fully load
                            selector.find('#palleon-canvas-img-wrap').imagesLoaded( function() {
                                var imgurl = selector.find('#palleon-canvas-img').attr("src");
                                fabric.Image.fromURL(imgurl, function(img) {
                                    canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas), {
                                        objectType: 'BG',
                                        mode: 'image',
                                        top: canvas.backgroundImage['top'], 
                                        left: canvas.backgroundImage['left'],
                                        scaleX: canvas.backgroundImage['scaleX'],
                                        scaleY: canvas.backgroundImage['scaleY'],
                                        selectable: false,
                                        angle: canvas.backgroundImage['angle'], 
                                        originX: canvas.backgroundImage['originX'], 
                                        originY: canvas.backgroundImage['originY'],
                                        lockMovementX: true,
                                        lockMovementY: true,
                                        lockRotation: true,
                                        erasable: true
                                    }, { crossOrigin: 'anonymous' });
                                    setTimeout(function(){ 
                                        selector.find('#palleon-canvas-loader').hide();
                                    }, 500);
                                }); 
                            });

                            if (antimenaParams.allowedUser === 'no') {
                                var credits = antimenaParams.clipdropReplaceCost;
                                user_balance_update(credits);
                            }
                        }).catch(err => {
                            toastr.error(err, palleonParams.error);
                            selector.find('#palleon-canvas-loader').css('display', 'none');
                        });
                        tempCanvas.dispose();         
                    });
                }
            }
        } else {
            toastr.error(antimenaParams.apiKeyRequired, palleonParams.error);
        }
    });

    // Remove text
    selector.find('#clipdrop-remove-text').on("click", function () {
        if (clipdropApiKey != '') {
            if (antimenaParams.allowedUser === 'no') {
                var cost = parseInt(antimenaParams.clipdropOthersCost);
                var userCredits = parseInt(selector.find('#antimena-user-credits').html());
                if (cost > userCredits) {
                    toastr.error(antimenaParams.creditsError, palleonParams.error);
                    return;
                }
            }
            var answer = window.confirm(antimenaParams.answer5);
            if (answer) {
                selector.find('#palleon-canvas-loader').css('display', 'flex');
                canvas.clone(function(tempCanvas) {
                    var tempObjects = tempCanvas.getObjects();
                    tempObjects.filter(element => element.objectType != 'BG').forEach(element => tempCanvas.remove(element));
                    tempCanvas.setZoom(1);
                    selector.find('#palleon-resize-width').trigger('sizeChanged');
                    selector.find('#palleon-resize-height').trigger('sizeChanged');
                    tempCanvas.setWidth(selector.find('#palleon-resize-width').data('size'));
                    tempCanvas.setHeight(selector.find('#palleon-resize-height').data('size'));
                    var image = tempCanvas.toDataURL({ format: 'png', enableRetinaScaling: false}),
                    blob = aiDataURLtoBlob(image),
                    file = new File([blob], "removetext.png"),
                    form = new FormData();
                    form.append('image_file', file);
                    fetch('https://clipdrop-api.co/remove-text/v1', {
                        method: 'POST',
                        headers: {
                            'x-api-key': clipdropApiKey,
                        },
                        body: form,
                        redirect: 'follow',
                    }).then(clipdropHandleErrors).then(response => response.arrayBuffer()).then(buffer => {
                        selector.find('#palleon-canvas-img').attr("src","data:image/png;base64," + arrayBufferToBase64(buffer));

                        // Wait for the placeholder image fully load
                        selector.find('#palleon-canvas-img-wrap').imagesLoaded( function() {
                            var imgurl = selector.find('#palleon-canvas-img').attr("src");
                            fabric.Image.fromURL(imgurl, function(img) {
                                canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas), {
                                    objectType: 'BG',
                                    mode: 'image',
                                    top: canvas.backgroundImage['top'], 
                                    left: canvas.backgroundImage['left'],
                                    scaleX: canvas.backgroundImage['scaleX'],
                                    scaleY: canvas.backgroundImage['scaleY'],
                                    selectable: false,
                                    angle: canvas.backgroundImage['angle'], 
                                    originX: canvas.backgroundImage['originX'], 
                                    originY: canvas.backgroundImage['originY'],
                                    lockMovementX: true,
                                    lockMovementY: true,
                                    lockRotation: true,
                                    erasable: true
                                }, { crossOrigin: 'anonymous' });
                                setTimeout(function(){ 
                                    selector.find('#palleon-canvas-loader').hide();
                                }, 500);
                            }); 
                        });
                        if (antimenaParams.allowedUser === 'no') {
                            var credits = antimenaParams.clipdropOthersCost;
                            user_balance_update(credits);
                        }
                    }).catch(err => {
                        toastr.error(err, palleonParams.error);
                        selector.find('#palleon-canvas-loader').css('display', 'none');
                    });
                    tempCanvas.dispose();         
                });
            }
        } else {
            toastr.error(antimenaParams.apiKeyRequired, palleonParams.error);
        }
    });

    // Upscaler
    selector.find('#palleon-resize-width').on("sizeChanged", function () {
        selector.find('#clipdrop-upscale-width').val($(this).val());
        selector.find('#clipdrop-upscale-width').data('size', $(this).val());
        selector.find('#clipdrop-upscale').prop('disabled', true);
    });

    selector.find('#palleon-resize-height').on("sizeChanged", function () {
        selector.find('#clipdrop-upscale-height').val($(this).val());
        selector.find('#clipdrop-upscale-height').data('size', $(this).val());
        selector.find('#clipdrop-upscale').prop('disabled', true);
    });

    selector.find('#clipdrop-upscale-width').on("input paste", function () {
        var val = $(this).val(),
        valHeight = selector.find('#clipdrop-upscale-height').val(),
        height = selector.find('#clipdrop-upscale-height').data('size'),
        width = $(this).data('size'),
        ratio = width / height;
        selector.find('#clipdrop-upscale-height').val(Math.round(this.value / ratio));
        if (val.length >= 1 && valHeight.length >= 1) {
            selector.find('#clipdrop-upscale').prop('disabled', false);
        } else {
            selector.find('#clipdrop-upscale').prop('disabled', true);
        }
    });

    selector.find('#clipdrop-upscale-height').on("input paste", function () {
        var val = $(this).val(),
        valWidth = selector.find('#clipdrop-upscale-width').val(),
        height = $(this).data('size'),
        width = selector.find('#clipdrop-upscale-width').data('size'),
        ratio = height / width;
        selector.find('#clipdrop-upscale-width').val(Math.round(this.value / ratio));
        if (val.length >= 1 && valWidth.length >= 1) {
            selector.find('#clipdrop-upscale').prop('disabled', false);
        } else {
            selector.find('#clipdrop-upscale').prop('disabled', true);
        }
    });

    selector.find('#clipdrop-upscale').on("click", function () {
        if (clipdropApiKey != '') {
            var width = parseInt(selector.find('#clipdrop-upscale-width').val());
            var height = parseInt(selector.find('#clipdrop-upscale-height').val());
            if (antimenaParams.allowedUser === 'no') {
                var cost = parseInt(antimenaParams.clipdropUpscalerCost);
                var userCredits = parseInt(selector.find('#antimena-user-credits').html());
                if (cost > userCredits) {
                    toastr.error(antimenaParams.creditsError, palleonParams.error);
                    return;
                }
            }
            if (width > 4096 || height > 4096) {
                toastr.error(antimenaParams.tooBigInfo2, antimenaParams.tooBig);
                return;
            } else if (1 > width || 1 > height) {
                toastr.error(antimenaParams.tooSmallInfo2, antimenaParams.tooSmall);
                return;
            }
            var answer = window.confirm(antimenaParams.answer1);
            if (answer) {
                selector.find('#palleon-canvas-loader').css('display', 'flex');
                canvas.clone(function(canvas) {
                    canvas.setZoom(1);
                    selector.find('#palleon-resize-width').trigger('sizeChanged');
                    selector.find('#palleon-resize-height').trigger('sizeChanged');
                    canvas.setWidth(selector.find('#palleon-resize-width').data('size'));
                    canvas.setHeight(selector.find('#palleon-resize-height').data('size'));
                    var image = canvas.toDataURL({ format: 'png', enableRetinaScaling: false}),
                    target_width = width,
                    target_height = height,
                    blob = aiDataURLtoBlob(image),
                    file = new File([blob], "upscale.png"),
                    form = new FormData();
                    form.append('image_file', file);
                    form.append('target_width', target_width);
                    form.append('target_height', target_height);
                    fetch('https://clipdrop-api.co/image-upscaling/v1/upscale', {
                        method: 'POST',
                        headers: {
                            'x-api-key': clipdropApiKey,
                        },
                        body: form,
                        redirect: 'follow',
                    }).then(clipdropHandleErrors).then(response => response.arrayBuffer()).then(buffer => {
                        $(document).trigger( "loadBase64Img", ["data:image/png;base64," + arrayBufferToBase64(buffer), ''] );
                        if (antimenaParams.allowedUser === 'no') {
                            var credits = antimenaParams.clipdropUpscalerCost;
                            user_balance_update(credits);
                        }
                    }).catch(err => {
                        toastr.error(err, palleonParams.error);
                        selector.find('#palleon-canvas-loader').css('display', 'none');
                    });
                    canvas.dispose();         
                });
            }
        } else {
            toastr.error(antimenaParams.apiKeyRequired, palleonParams.error);
        }
    });

    // Inpainting
    selector.find('#clipdrop-inpainting').on("click", function () {
        if (clipdropApiKey != '') {
            var drawing = canvas.getObjects().filter(element => element.type == 'path')[0];
            if (drawing) {
                if (antimenaParams.allowedUser === 'no') {
                    var cost = parseInt(antimenaParams.clipdropOthersCost);
                    var userCredits = parseInt(selector.find('#antimena-user-credits').html());
                    if (cost > userCredits) {
                        toastr.error(antimenaParams.creditsError, palleonParams.error);
                        return;
                    }
                }
                var answer = window.confirm(antimenaParams.answer6);
                if (answer) {
                    selector.find('#palleon-canvas-loader').css('display', 'flex');
                    canvas.clone(function(canvas) {
                        canvas.setZoom(1);
                        selector.find('#palleon-resize-width').trigger('sizeChanged');
                        selector.find('#palleon-resize-height').trigger('sizeChanged');
                        canvas.setWidth(selector.find('#palleon-resize-width').data('size'));
                        canvas.setHeight(selector.find('#palleon-resize-height').data('size'));
                        canvas.getObjects().filter(element => element.type != 'path').forEach(element => canvas.remove(element));
                        var form = new FormData();

                        canvas.getObjects().filter(element => element.type == 'path').forEach(element => element.set({stroke: 'transparent', shadow: null}));
                        canvas.requestRenderAll();
                        var image = canvas.toDataURL({ format: 'png', enableRetinaScaling: false}),
                        blob = aiDataURLtoBlob(image),
                        file = new File([blob], "cleanup.png");
                        form.append('image_file', file);
                        
                        canvas.getObjects().filter(element => element.type == 'path').forEach(element => element.set('stroke', 'rgb(255,255,255)'));
                        canvas.backgroundColor = 'rgb(0,0,0)';
                        canvas.setBackgroundImage(null);
                        canvas.requestRenderAll();
                        var mask = canvas.toDataURL({ format: 'png', enableRetinaScaling: false});
                        var maskBlob = aiDataURLtoBlob(mask),
                        maskFile = new File([maskBlob], "mask.png");
                        form.append('mask_file', maskFile);

                        fetch('https://clipdrop-api.co/cleanup/v1', {
                            method: 'POST',
                            headers: {
                                'x-api-key': clipdropApiKey,
                            },
                            body: form,
                            redirect: 'follow',
                        }).then(clipdropHandleErrors).then(response => response.arrayBuffer()).then(buffer => {
                            $(document).trigger( "loadBase64Img", ["data:image/png;base64," + arrayBufferToBase64(buffer), ''] );
                            if (antimenaParams.allowedUser === 'no') {
                                var credits = antimenaParams.clipdropOthersCost;
                                user_balance_update(credits);
                            }
                        }).catch(err => {
                            toastr.error(err, palleonParams.error);
                            selector.find('#palleon-canvas-loader').css('display', 'none');
                        });
                        canvas.dispose();
                    });
                }
            } else {
                toastr.warning(antimenaParams.nodrawing, palleonParams.warning);
            }
        } else {
            toastr.error(antimenaParams.apiKeyRequired, palleonParams.error);
        }
    });

    // Reimagine
    selector.find('#clipdrop-clipdrop-reimagine').on("click", function () {
        if (clipdropApiKey != '') {
            var width = parseInt(selector.find('#clipdrop-upscale-width').val());
            var height = parseInt(selector.find('#clipdrop-upscale-height').val());
            if (antimenaParams.allowedUser === 'no') {
                var cost = parseInt(antimenaParams.clipdropOthersCost);
                var userCredits = parseInt(selector.find('#antimena-user-credits').html());
                if (cost > userCredits) {
                    toastr.error(antimenaParams.creditsError, palleonParams.error);
                    return;
                }
            }
            if (width > 1024 || height > 1024) {
                toastr.error(antimenaParams.tooBigInfo3, palleonParams.tooBig);
                return;
            }
            var answer = window.confirm(antimenaParams.answer7);
            if (answer) {
                selector.find('#palleon-canvas-loader').css('display', 'flex');
                canvas.clone(function(canvas) {
                    canvas.setZoom(1);
                    selector.find('#palleon-resize-width').trigger('sizeChanged');
                    selector.find('#palleon-resize-height').trigger('sizeChanged');
                    canvas.setWidth(selector.find('#palleon-resize-width').data('size'));
                    canvas.setHeight(selector.find('#palleon-resize-height').data('size'));
                    var image = canvas.toDataURL({ format: 'png', enableRetinaScaling: false}),
                    blob = aiDataURLtoBlob(image),
                    file = new File([blob], "reimagination.png"),
                    form = new FormData();
                    form.append('image_file', file);
                    fetch('https://clipdrop-api.co/reimagine/v1/reimagine', {
                        method: 'POST',
                        headers: {
                            'x-api-key': clipdropApiKey,
                        },
                        body: form,
                        redirect: 'follow',
                    }).then(clipdropHandleErrors).then(response => response.arrayBuffer()).then(buffer => {
                        $(document).trigger( "loadBase64Img", ["data:image/png;base64," + arrayBufferToBase64(buffer), ''] );
                        if (antimenaParams.allowedUser === 'no') {
                            var credits = antimenaParams.clipdropOthersCost;
                            user_balance_update(credits);
                        }
                    }).catch(err => {
                        toastr.error(err, palleonParams.error);
                        selector.find('#palleon-canvas-loader').css('display', 'none');
                    });
                    canvas.dispose();         
                });
            }
        } else {
            toastr.error(antimenaParams.apiKeyRequired, palleonParams.error);
        }
    });

    // Uncrop
    selector.find('#clipdrop-uncrop').on("click", function () {
        if (clipdropApiKey != '') {
            var extend_top = selector.find('#clipdrop-extend-top').val();
            var extend_bottom = selector.find('#clipdrop-extend-bottom').val();
            var extend_left = selector.find('#clipdrop-extend-left').val();
            var extend_right = selector.find('#clipdrop-extend-right').val();
            if (antimenaParams.allowedUser === 'no') {
                var cost = parseInt(antimenaParams.clipdropOthersCost);
                var userCredits = parseInt(selector.find('#antimena-user-credits').html());
                if (cost > userCredits) {
                    toastr.error(antimenaParams.creditsError, palleonParams.error);
                    return;
                }
            }
            var answer = window.confirm(antimenaParams.answer8);
            if (answer) {
                selector.find('#palleon-canvas-loader').css('display', 'flex');
                canvas.clone(function(canvas) {
                    canvas.setZoom(1);
                    selector.find('#palleon-resize-width').trigger('sizeChanged');
                    selector.find('#palleon-resize-height').trigger('sizeChanged');
                    canvas.setWidth(selector.find('#palleon-resize-width').data('size'));
                    canvas.setHeight(selector.find('#palleon-resize-height').data('size'));
                    var image = canvas.toDataURL({ format: 'png', enableRetinaScaling: false}),
                    blob = aiDataURLtoBlob(image),
                    file = new File([blob], "uncrop.png"),
                    form = new FormData();
                    form.append('image_file', file);
                    form.append('extend_up', extend_top);
                    form.append('extend_down', extend_bottom);
                    form.append('extend_left', extend_left);
                    form.append('extend_right', extend_right);
                    fetch('https://clipdrop-api.co/uncrop/v1', {
                        method: 'POST',
                        headers: {
                            'x-api-key': clipdropApiKey,
                        },
                        body: form,
                        redirect: 'follow',
                    }).then(clipdropHandleErrors).then(response => response.arrayBuffer()).then(buffer => {
                        $(document).trigger( "loadBase64Img", ["data:image/png;base64," + arrayBufferToBase64(buffer), ''] );
                        if (antimenaParams.allowedUser === 'no') {
                            var credits = antimenaParams.clipdropOthersCost;
                            user_balance_update(credits);
                        }
                    }).catch(err => {
                        toastr.error(err, palleonParams.error);
                        selector.find('#palleon-canvas-loader').css('display', 'none');
                    });
                    canvas.dispose();         
                });
            }
        } else {
            toastr.error(antimenaParams.apiKeyRequired, palleonParams.error);
        }
    });

    // Sketch to Image 
    var sketch = selector.find('#sketch-to-image-canvas')[0];
    var sketchSize = 640;
    var sketchCanvas = '';

    function sketchAdjustZoom() {
        if (sketchCanvas != '') {
            var outerCanvasContainer = $('#sketch-to-image-wrap')[0];
            var ratio = sketchCanvas.getWidth() / sketchCanvas.getHeight();
            var containerWidth   = outerCanvasContainer.clientWidth;
            var scale = containerWidth / sketchCanvas.getWidth();
            var zoom  = sketchCanvas.getZoom() * scale;
            sketchCanvas.setDimensions({width: containerWidth, height: containerWidth / ratio});
            sketchCanvas.setViewportTransform([zoom, 0, 0, zoom, 0, 0]);
        }
    }
    
    selector.find('#sketch-to-image-link').one('click', function(e) {
        setTimeout(function(){
            sketchCanvas = new fabric.Canvas(sketch);
            sketchCanvas.isDrawingMode = true;
            var pencilBrush = new fabric.PencilBrush(sketchCanvas);
            sketchCanvas.freeDrawingBrush = pencilBrush;
            sketchCanvas.freeDrawingBrush.color = selector.find('#sketch-to-image-brush-color').val();
            sketchCanvas.freeDrawingBrush.width = parseInt(selector.find('#sketch-to-image-brush-width').val());
            sketchCanvas.setWidth(sketchSize);
            sketchCanvas.setHeight(sketchSize);
            sketchAdjustZoom();
            $('#sketch-to-image-wrap').css('opacity', 1);
        }, 500);
    });

    $(window).on('resize', function(){
        sketchAdjustZoom();
    });

    selector.find('#sketch-to-image-brush-color').bind('change', function() {
        sketchCanvas.freeDrawingBrush.color = $(this).val();
    });

    selector.find('#sketch-to-image-brush-width').bind('input paste keyup keydown', function() {
        sketchCanvas.freeDrawingBrush.width = parseInt($(this).val());
    });

    selector.find("#sketch-to-image-undo").on("click", function () {
        var objects = sketchCanvas.getObjects();
        var lastElement = objects.slice(-1)[0];
        sketchCanvas.remove(lastElement);
        sketchCanvas.requestRenderAll();
    });

    selector.find("#sketch-to-image-clear").on("click", function () {
        var objects = sketchCanvas.getObjects();
        objects.forEach(element => sketchCanvas.remove(element));
        sketchCanvas.requestRenderAll();
    });

    selector.find('#sketch-to-image-prompt').on("input paste", function () {
        var val = $(this).val();
        if (val.length >= 1) {
            selector.find('#sketch-to-image-generate').prop('disabled', false);
        } else {
            selector.find('#sketch-to-image-generate').prop('disabled', true);
        }
    });
    
    selector.find("#sketch-to-image-generate").on("click", function () {
        if (clipdropApiKey != '') {
            var prompt = selector.find('#sketch-to-image-prompt').val();
            if (prompt.length >= 1) {
                if (antimenaParams.allowedUser === 'no') {
                    var cost = parseInt(antimenaParams.clipdropOthersCost);
                    var userCredits = parseInt(selector.find('#antimena-user-credits').html());
                    if (cost > userCredits) {
                        toastr.error(antimenaParams.creditsError, palleonParams.error);
                        return;
                    }
                }
                var answer = window.confirm(antimenaParams.answer2);
                if (answer) {
                    selector.find('#modal-ai-image').css('pointer-events', 'none');
                    selector.find('#antimena-loader-3').css('display', 'flex');
                    sketchCanvas.clone(function(tempCanvas) {
                        var objects = tempCanvas.getObjects();
                        var scaleRatio = Math.min(1024 / tempCanvas.getWidth(), 1024 / tempCanvas.getHeight());
                        var width = Math.ceil(tempCanvas.getWidth() * scaleRatio);
                        var height = Math.ceil(tempCanvas.getHeight() * scaleRatio);
                        tempCanvas.setDimensions({ width: width, height: height });
                        tempCanvas.setZoom(scaleRatio);
                        tempCanvas.backgroundColor = 'rgb(255,255,255)';
                        objects.forEach(element => element.set({stroke: 'rgb(0,0,0)'}));
                        var image = tempCanvas.toDataURL({ format: 'png', enableRetinaScaling: false}),
                        blob = aiDataURLtoBlob(image),
                        file = new File([blob], "sketch.png"),
                        form = new FormData();
                        form.append('sketch_file', file);
                        form.append('prompt', prompt);

                        fetch('https://clipdrop-api.co/sketch-to-image/v1/sketch-to-image', {
                            method: 'POST',
                            headers: {
                                'x-api-key': clipdropApiKey,
                            },
                            body: form,
                            redirect: 'follow',
                        }).then(clipdropHandleErrors).then(response => response.arrayBuffer()).then(buffer => {
                            var id = new Date().getTime();
                            var data = '<div class="palleon-masonry-item"><div class="palleon-masonry-item-inner"><div class="palleon-img-wrap"><img id="' + id + '" src="data:image/jpeg;base64,' + arrayBufferToBase64(buffer) + '" /></div><div class="antimena-img-card"><div class="antimena-img-card-inner"><div class="antimena-img-btns"><button type="button" class="palleon-btn btn-full antimena-img-download" autocomplete="off" data-seed="' + id + '"><span class="material-icons arrow">download</span>' + antimenaParams.download + '</button><button type="button" class="palleon-btn btn-full antimena-img-save" autocomplete="off" data-seed="' + id + '"><span class="material-icons arrow">save</span>' + antimenaParams.save + '</button><button type="button" class="palleon-btn btn-full primary antimena-img-select" autocomplete="off" data-seed="' + id + '"><span class="material-icons arrow">done</span>' + antimenaParams.select + '</button></div></div></div></div></div>';    
                            selector.find('#clipdrop-sketch-images').html('');
                            selector.find('#clipdrop-sketch-images').removeClass('antimena-grid-placeholder');
                            selector.find('#clipdrop-sketch-images').html(data);
                            selector.find('#modal-ai-image').css('pointer-events', 'auto');
                            selector.find('#antimena-loader-3').hide();
                            if (antimenaParams.allowedUser === 'no') {
                                var credits = antimenaParams.clipdropOthersCost;
                                user_balance_update(credits);
                            }
                        }).catch(err => {
                            toastr.error(err, palleonParams.error);
                            selector.find('#antimena-loader-3').hide();
                        });
                        tempCanvas.dispose();
                    });
                }
            }
        } else {
            toastr.error(antimenaParams.apiKeyRequired, palleonParams.error);
        }
    });

    // Save API Keys
    selector.find('#antimena-api-keys-save').on('click', function() {
        var button = $(this);
        var sai = selector.find('#sai_api_key').val();
        var oai = selector.find('#oai_api_key').val();
        var clipdrop = selector.find('#clipdrop_api_key').val();

        var data = {
            'action': 'saveAntimenaApiKeys',
            'nonce': palleonParams.nonce,
            'sai':  sai,
            'oai':  oai,
            'clipdrop':  clipdrop,
        };

        $.ajax({
            url : palleonParams.ajaxurl,
            data : data,
            type : 'POST',
            beforeSend: function () {
                button.prop('disabled', true);
            },
            success: function () {
                oai_api_key();
                stabilityai_api_key();
                clipdrop_api_key();
                toastr.success(palleonParams.settingsaved, palleonParams.success);
            },
            complete: function () {
                button.prop('disabled', false);
            },
            error: function(jqXHR,error, errorThrown) {
                if(jqXHR.status&&jqXHR.status==400){
                    toastr.error(jqXHR.responseText, palleonParams.error);
                }else{
                    toastr.error(palleonParams.wrong, palleonParams.error);
                }
        }
        });
    });
}

/* HELPERS */

// Arraybuffer to base64
function arrayBufferToBase64( buffer ) {
    var binary = '';
    var bytes = new Uint8Array( buffer );
    var len = bytes.byteLength;
    for (var i = 0; i < len; i++) {
        binary += String.fromCharCode( bytes[ i ] );
    }
    return window.btoa( binary );
}

// Dataurl to blob
function aiDataURLtoBlob(dataurl) {
    var arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
    while(n--){
        u8arr[n] = bstr.charCodeAt(n);
    }
    return new Blob([u8arr], {type:mime});
}

function urlToBase64(url, callback) {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', url);
    xhr.responseType = 'blob';

    xhr.onload = function() {
        const reader = new FileReader();
        reader.onloadend = function() {
        callback(reader.result);
        };
        reader.readAsDataURL(xhr.response);
    };

    xhr.onerror = function() {
        console.error('Error fetching image:', xhr.status, xhr.statusText);
    };

    xhr.send();
}

// Clipdrop error handling
function clipdropHandleErrors(response) {
    if (!response.ok) {
        if (response.status == 400) {
            throw Error(antimenaParams.cp400);
        } else if (response.status == 401) {
            throw Error(antimenaParams.cp401);
        } else if (response.status == 402) {
            throw Error(antimenaParams.cp402);
        } else if (response.status == 403) {
            throw Error(antimenaParams.cp403);
        } else if (response.status == 406) {
            throw Error(antimenaParams.cp406);
        } else if (response.status == 429) {
            throw Error(antimenaParams.cp429);
        } else if (response.status == 500) {
            throw Error(antimenaParams.cp500);
        }
    } else {
        if (antimenaParams.allowedUser === 'yes') {
            toastr.success(parseFloat(response.headers.get('x-remaining-credits')).toFixed(2) + ' ' + antimenaParams.creditsLeft, palleonParams.success);
        }
    }
    return response;
}

// OpenAI error handling
function oaiHandleErrors(response) {
    if (!response.ok) {
        if (response.status == 400) {
            throw Error(antimenaParams.cp400);
        } else if (response.status == 401) {
            throw Error(antimenaParams.cp401);
        } else if (response.status == 402) {
            throw Error(antimenaParams.cp402);
        } else if (response.status == 403) {
            throw Error(antimenaParams.cp403);
        } else if (response.status == 406) {
            throw Error(antimenaParams.cp406);
        } else if (response.status == 429) {
            throw Error(antimenaParams.cp429);
        } else if (response.status == 500) {
            throw Error(antimenaParams.cp500);
        }
    } else {
        if (antimenaParams.allowedUser === 'yes') {
            toastr.success(antimenaParams.imgEdited, palleonParams.success);
        }
    }
    return response;
}