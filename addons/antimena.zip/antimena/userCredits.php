<?php 
defined( 'ABSPATH' ) || exit;

class AntimenaCredits {
 
    /**
     * User Meta Key
     *
     * @var int
     */
    public $creditsKey = 'antimena_user_credits';
     
    /**
     * Current User
     *
     * @var int
     */
    public $user = null;    
    /**
     * Easy Active User
     *
     * @var int
     */
    public $activeUser = false; 
    /**
     * Active User Credits Count
     *
     * @var int
     */
    public $activeUserCredits = 0;          
    /**
     *
     * The single instance of the class.
     *
     * Credits
     *
     */
    protected static $_instance = null;
    /**
     * The Instance
     */
    public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}
    /**
     * Constructor
     */
    public function __construct() {
        $this->set_user_data();
        add_action('cmb2_admin_init', array($this, 'register_metabox'));
        add_action('woocommerce_order_status_completed', array($this, 'after_order_complete'));
        add_filter('woocommerce_checkout_registration_required', array($this, 'filter_woocommerce_checkout_registration_required'), 10, 1 );
        add_action('wp_ajax_updateCredits', array($this, 'update_user_credits'));
        add_action('user_register', array($this, 'free_credits'), 10, 1);
        add_filter('manage_users_columns', array($this, 'modify_user_table'));
        add_filter('manage_users_custom_column', array($this, 'modify_user_table_row'), 10, 3 );
    }
   
    /**
     * Set Init User Data.
     */
    public function set_user_data() {
        $user = wp_get_current_user();
        if($user->exists()){
            $this->user = $user;
            $this->activeUser = true;
            $this->activeUserCredits = get_user_meta($this->user->ID,$this->creditsKey, true);
            if(empty($this->activeUserCredits)){
                $this->activeUserCredits = 0;
            }    
        }
    }
    /**
     * Get The Current Users Credit Count
     */
    public function get_total() {
        return $this->activeUserCredits;
    } 
    
    /**
     * Updates User Credits Count  
     */
    public function update_total($difference,$operator = '-') {
        if(!$this->activeUser){
            return false;
        }
        if($operator == '-'){
            $this->activeUserCredits = $this->activeUserCredits - $difference;
        }
        if($operator == '+'){
            $this->activeUserCredits = $this->activeUserCredits + $difference;
        }
        $status = update_user_meta( $this->user->ID, $this->creditsKey, $this->activeUserCredits);
        return $status;
    }

    public function update_user_credits() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'antimena'));
        }
        if(isset($_POST['credits'])) {
            $this->update_total($_POST['credits'],'-');
        }
        echo $this->activeUserCredits;
        wp_die();
    }

    /**
    * Register User Metaboxes
    */
    public function register_metabox() {
        $user_credits = new_cmb2_box( array(
            'id'      => 'antimena_credits_metabox',
            'title'   => esc_html__( 'AI Credits', 'antimena' ),
            'object_types'  => array( 'user' ),
            'cmb_styles' => true,
            'show_names' => true,
            'show_on_cb' => array($this, 'capability')
        ));
        
        $user_credits->add_field( array(
            'id'      => $this->creditsKey,
            'name'   => esc_html__( 'AI Credits', 'antimena' ),
            'type' => 'text',
            'attributes' => array(
                'type' => 'number',
                'pattern' => '\d*',
                'autocomplete' => 'off'
            ),
            'default' => ''
        ) );

        $product_credits = new_cmb2_box( array(
            'id'      => 'antimena_product_credits_metabox',
            'title'   => esc_html__( 'AI Credits', 'antimena' ),
            'object_types'  => array( 'product' ),
            'context'  => 'side',
            'cmb_styles' => true,
            'show_names' => false
        ));
        
        $product_credits->add_field( array(
            'id'      => $this->creditsKey,
            'name'   => esc_html__( 'AI Credits', 'antimena' ),
            'description'   => esc_html__( 'Enter the amount of credits you want to sell.', 'antimena' ),
            'type' => 'text',
            'attributes' => array(
                'type' => 'number',
                'pattern' => '\d*',
                'autocomplete' => 'off'
            ),
            'default' => ''
        ) );
    }

    public function capability( $cmb ) {
        return current_user_can( 'manage_options' );
    }

    /**
    * Custom user column
    */
    public function modify_user_table( $column ) {
        $column[$this->creditsKey] = esc_html__( 'AI Credits', 'antimena' );
        return $column;
    }
    public function modify_user_table_row( $val, $column_name, $user_id ) {
        switch ($column_name) {
            case $this->creditsKey :
                $credits = get_user_meta($user_id, $this->creditsKey, true);
                if (empty($credits)) {
                    return '0';
                } else {
                    return $credits;
                }
            default:
        }
        return $val;
    }

    /*
    * Print user credits
    */
    public function user_credits(){
        $total = $this->activeUserCredits;
        ?>
        <div class="antimena-user-credits">
        <?php
        if($total == 1){
            echo esc_html__( 'You have', 'antimena' ) . ' ' . $total . ' ' . esc_html__( 'credit left.', 'antimena' );
        } else {
            echo esc_html__( 'You have', 'antimena' ) . ' ' . $total . ' ' . esc_html__( 'credits left.', 'antimena' );
        }
        ?>
        </div>
    <?php
    }
    /*
    * Free credits
    */
    public function free_credits($user_id) {
        $freeCredits = PalleonSettings::get_option('antimena_free_credits', '0');
        if (empty($freeCredits)) {
            $freeCredits = '0';
        }
        update_user_meta( $user_id, $this->creditsKey, $freeCredits);
    }
    /*
    * WooCommerce
    */
    public function after_order_complete( $order_id ) {
        $order = wc_get_order( $order_id );
        $customer_id = $order->get_customer_id(); 
        foreach ( $order->get_items() as $item_id => $item ) {
            $product_id = $item->get_product_id();
            $quantity = $item->get_quantity();
            $ai_credits = intval(get_post_meta($product_id, 'antimena_user_credits', true )) * intval($quantity);
            if (!empty($ai_credits)) {
                $user_credits = intval(get_user_meta( $customer_id, $this->creditsKey, true)) + $ai_credits;
                update_user_meta( $customer_id, $this->creditsKey, $user_credits);
            }
        }
    }
    public function filter_woocommerce_checkout_registration_required( $bool_value ) {   
        if ( WC()->cart ) {
            if ( ! WC()->cart->is_empty() ) {  
                foreach ( WC()->cart->get_cart() as $cart_item ) {
                    $product_id = $cart_item['product_id'];
                    $credits = get_post_meta($product_id, 'antimena_user_credits', true );
                    if (!empty($credits)) {
                        $bool_value = true;
                        break;
                    }
                }
            }
        }
        return $bool_value;
    }
}

/**
 * Returns the main instance of the class
 */
function AntimenaCredits() {  
	return AntimenaCredits::instance();
}
// Global for backwards compatibility
$GLOBALS['AntimenaCredits'] = AntimenaCredits();    