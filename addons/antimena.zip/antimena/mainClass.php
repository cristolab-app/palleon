<?php
defined( 'ABSPATH' ) || exit;

class Antimena extends Palleon {
    /**
	 * The single instance of the class
	 */
	protected static $_instance = null;

    /**
	 * Main Instance
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

    /**
	 * Antimena Constructor
	 */
    public function __construct() {
        add_action('init', array($this, 'antimena_init'), 1);
        if (is_user_logged_in()) {
            add_filter('palleonStylesheets', array($this, 'antimena_styles'), 20);
            add_filter('palleonScripts', array($this, 'antimena_scripts'), 20);
            add_action('palleon_body_end', array($this, 'antimena_localization'), 10);
            add_action('palleon_add_new_menu', array($this, 'antimena_tab_title'));
            add_action('palleon_add_new_tab', array($this, 'antimena_tab'));
            add_action('agama_antimena_modal', array($this, 'antimena_tab'));
            add_action('palleon_before_filters', array($this, 'antimena_adjust'));
            add_action('palleon_user_settings_end', array($this, 'antimena_user_settings'));
            add_action('wp_ajax_oaiTextToImage', array($this, 'oai_text_to_img'));
            add_action('wp_ajax_saiTextToImage', array($this, 'sai_text_to_img'));
            add_action('wp_ajax_saiBalance', array($this, 'sai_check_balance'));
            add_action('wp_ajax_clipdropApiKey', array($this, 'get_clipdrop_api_key'));
            add_action('wp_ajax_oaiApiKey', array($this, 'get_oai_api_key'));
            add_action('wp_ajax_stabilityaiApiKey', array($this, 'get_sai_api_key'));
            add_action('wp_ajax_saveAntimenaApiKeys', array($this, 'antimena_save_api_keys'));
        }
        add_filter('plugin_row_meta', array($this, 'antimena_plugin_links'), 10, 4);
        add_action('palleon_add_setting_tab', array($this, 'antimena_setting_tab'));
		add_action('palleon_add_settings', array($this, 'antimena_settings'));
        add_action('admin_enqueue_scripts', array($this, 'antimena_admin_scripts') );
    }

    /**
	 * Init
	 */
    public function antimena_init() {
        // Load text domain
        load_plugin_textdomain( 'antimena', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
    }

    /**
	 * Add plugin links to plugins page on the admin dashboard
	 */
    public function antimena_plugin_links($links_array, $plugin_file_name, $plugin_data, $status) {
        if ( strpos( $plugin_file_name, 'antimena.php' ) !== false ) {
            $links_array[] = '<a href="'. esc_url( get_admin_url(null, 'admin.php?page=palleon_options&tab=cmb2-id-antimena-title') ) .'">' . esc_html__( 'Settings', 'antimena' ) . '</a>';
            $links_array[] = '<a href="https://palleon.website/antimena/documentation/" target="_blank">' . esc_html__( 'Documentation', 'antimena' ) . '</a>';
        }
        return $links_array;
    }

    /**
	 * Palleon styles
	 */
    public function antimena_styles($styles) {
        $styles['antimena-css'] = array(ANTIMENA_PLUGIN_URL . 'css/style.css', ANTIMENA_VERSION);
        return $styles;
    }
    
	/**
	 * Palleon scripts
	 */
    public function antimena_scripts($scripts) {
        $scripts['antimena-js'] = array(ANTIMENA_PLUGIN_URL . 'js/custom.js', ANTIMENA_VERSION);
        return $scripts;
    }

    /* Admin Scripts */
    public function antimena_admin_scripts($hook){
        wp_enqueue_style('antimena-admin', ANTIMENA_PLUGIN_URL . 'css/admin.css', false, ANTIMENA_VERSION);
    }

    /* User Settings */
    public function antimena_user_settings() {
        $personal =  PalleonSettings::get_option('personal_api_keys', 'disable');
        if ($personal == 'enable') {
            $user_id = get_current_user_id();
            $sai_api_key = get_user_meta($user_id, 'sai_api_key',true);
            $oai_api_key = get_user_meta($user_id, 'oai_api_key',true);
            $clipdrop_api_key = get_user_meta($user_id, 'clipdrop_api_key',true);
        ?>
        <hr>
        <h5><?php echo esc_html__( 'API Keys', 'antimena' ); ?></h5>
        <div id="antimena-api-keys">
            <div class="palleon-control-wrap label-block"> 
                <label class="palleon-control-label"><?php echo esc_html__( 'Stability.ai', 'antimena' ); ?></label> 
                <div class="palleon-control"> 
                    <input type="text" id="sai_api_key" class="palleon-form-field" autocomplete="off" value="<?php echo esc_attr($sai_api_key); ?>"> 
                </div> 
            </div>
            <div class="palleon-control-wrap label-block"> 
                <label class="palleon-control-label"><?php echo esc_html__( 'OpenAI', 'antimena' ); ?></label> 
                <div class="palleon-control"> 
                    <input type="text" id="oai_api_key" class="palleon-form-field" autocomplete="off" value="<?php echo esc_attr($oai_api_key); ?>"> 
                </div> 
            </div>
            <div class="palleon-control-wrap label-block"> 
                <label class="palleon-control-label"><?php echo esc_html__( 'Clipdrop', 'antimena' ); ?></label> 
                <div class="palleon-control"> 
                    <input type="text" id="clipdrop_api_key" class="palleon-form-field" autocomplete="off" value="<?php echo esc_attr($clipdrop_api_key); ?>"> 
                </div> 
            </div>
            <div class="palleon-control-wrap label-block">
                <div class="palleon-control">
                    <button id="antimena-api-keys-save" type="button" class="palleon-btn palleon-lg-btn btn-full primary"><?php echo esc_html__('Save API Keys', 'antimena'); ?></button>
                </div>
            </div>
        </div>
    <?php }
    }

    /**
	 * Localization
	 */
    public function antimena_localization() { 
        $user = wp_get_current_user();
        $allowed_roles = PalleonSettings::get_option('antimena_roles', array());
        $allowed_user = 'no';
        array_push($allowed_roles, 'administrator'); 
        if ( array_intersect( $allowed_roles, $user->roles )) {
            $allowed_user = 'yes';
        }
        $personal =  PalleonSettings::get_option('personal_api_keys', 'disable');
        if ($personal == 'enable') {
            $allowed_user = 'yes';
        }
        $sai_credit_cost = PalleonSettings::get_option('sai_credit_cost', 1);
        $oai_credit_cost = PalleonSettings::get_option('oai_credit_cost', 1);
        $clipdrop_text_credit_cost = PalleonSettings::get_option('clipdrop_text_credit_cost', 1);
        $clipdrop_replace_credit_cost = PalleonSettings::get_option('clipdrop_replace_credit_cost', 3);
        $clipdrop_upscaler_credit_cost = PalleonSettings::get_option('clipdrop_upscaler_credit_cost', 2);
        $clipdrop_others_credit_cost = PalleonSettings::get_option('clipdrop_others_credit_cost', 2);
        ?>
        <script>
        /* <![CDATA[ */
        var antimenaParams = {
            "allowedUser": "<?php echo esc_html($allowed_user); ?>",
            "saiCost": "<?php echo esc_html($sai_credit_cost); ?>",
            "oaiCost": "<?php echo esc_html($oai_credit_cost); ?>",
            "clipdropTextCost": "<?php echo esc_html($clipdrop_text_credit_cost); ?>",
            "clipdropReplaceCost": "<?php echo esc_html($clipdrop_replace_credit_cost); ?>",
            "clipdropUpscalerCost": "<?php echo esc_html($clipdrop_upscaler_credit_cost); ?>",
            "clipdropOthersCost": "<?php echo esc_html($clipdrop_others_credit_cost); ?>",
            "creditsLeft": "<?php echo esc_html__('credits left.', 'antimena'); ?>",
            "creditsError": "<?php echo esc_html__("You don't have enough credits!", 'antimena'); ?>",
            "tooBig": "<?php echo esc_html__('Too big!', 'antimena'); ?>",
            "tooSmall": "<?php echo esc_html__('Too small!', 'antimena'); ?>",
            "tooBigInfo": "<?php echo esc_html__('This operation outputs an image with a maximum pixel count of 4,194,304. This is equivalent to dimensions such as 2048x2048 and 4096x1024.', 'antimena'); ?>",
            "tooBigInfo2": "<?php echo esc_html__('Maximum allowed width or height value is 4096px.', 'antimena'); ?>",
            "tooBigInfo3": "<?php echo esc_html__('Maximum allowed width or height value is 1024px.', 'antimena'); ?>",
            "tooBigInfo4": "<?php echo esc_html__('Maximum allowed width or height value is 1536px.', 'antimena'); ?>",
            "tooSmallInfo": "<?php echo esc_html__('Width and height must be bigger than 512px.', 'antimena'); ?>",
            "tooSmallInfo2": "<?php echo esc_html__('Width and height must be bigger than 1px.', 'antimena'); ?>",
            "mustBeBigger": "<?php echo esc_html__('Requested image dimensions must be bigger than original image dimensions.', 'antimena'); ?>",
            "promptRequired": "<?php echo esc_html__('Prompt field cannot be empty.', 'antimena'); ?>",
            "nodrawing": "<?php echo esc_html__('You must mark unwanted objects or defects using the "pencil brush".', 'antimena'); ?>",
            "answer1": "<?php echo esc_html__('Are you sure you want to upscale the image?', 'antimena'); ?>",
            "answer2": "<?php echo esc_html__('Are you sure you want to send the request?', 'antimena'); ?>",
            "answer3": "<?php echo esc_html__('Are you sure you want to regenerate the image?', 'antimena'); ?>",
            "answer4": "<?php echo esc_html__('Are you sure you want to remove the background?', 'antimena'); ?>",
            "answer5": "<?php echo esc_html__('Are you sure you want to remove the text that appears on your image?', 'antimena'); ?>",
            "answer6": "<?php echo esc_html__('Are you sure you want to remove the objects from your image?', 'antimena'); ?>",
            "answer7": "<?php echo esc_html__('Are you sure you want to reimagine your image?', 'antimena'); ?>",
            "answer8": "<?php echo esc_html__('Are you sure you want to uncrop the image?', 'antimena'); ?>",
            "cp400": "<?php echo esc_html__('Request is malformed or incomplete, non exhaustive causes can be: Missing image_file in request, input image format is not valid, image resolution is too big.', 'antimena'); ?>",
            "cp401": "<?php echo esc_html__('Missing api key.', 'antimena'); ?>",
            "cp402": "<?php echo esc_html__('Your account has no remaining credits, you can buy more in your account page.', 'antimena'); ?>",
            "cp403": "<?php echo esc_html__('Invalid or revocated api key.', 'antimena'); ?>",
            "cp406": "<?php echo esc_html__('Accept header not acceptable.', 'antimena'); ?>",
            "cp429": "<?php echo esc_html__('Too many requests, blocked by the rate limiter.', 'antimena'); ?>",
            "cp500": "<?php echo esc_html__('An unexpected server error occurred.', 'antimena'); ?>",
            "download": "<?php echo esc_html__('Download', 'antimena'); ?>",
            "save": "<?php echo esc_html__('Save', 'antimena'); ?>",
            "saving": "<?php echo esc_html__('Saving', 'antimena'); ?>",
            "select": "<?php echo esc_html__('Select', 'antimena'); ?>",
            "square": "<?php echo esc_html__('Image must be square.', 'antimena'); ?>",
            "square256": "<?php echo esc_html__('Valid image dimentions are 1024x1024px, 512x512px or 256x256px.', 'antimena'); ?>",
            "imgEdited": "<?php echo esc_html__('Image is edited by AI.', 'antimena'); ?>",
            "apiKeyRequired": "<?php echo esc_html__('API key is required.', 'antimena'); ?>",
        };
        /* ]]> */
        </script>
        <?php
    }

    /**
	 * Add Setting Tab
	 */
    public function antimena_setting_tab($options) {
        $options->add_field( array(
            'name' => '<span class="dashicons dashicons-admin-plugins"></span>' . esc_html__( 'Antimena', 'antimena' ),
            'id'   => 'antimena_title',
            'type' => 'title'
        ) );
    }

    /**
	 * Add Settings
	 */
    public function antimena_settings($options) {
        global $wp_roles;
        $roles = array();
        $all_roles = $wp_roles->roles;
        $editable_roles = apply_filters('editable_roles', $all_roles);
        foreach ($editable_roles as $role_name => $role_info) {
            if ($role_name !== 'administrator') {
                $roles[$role_name] = $role_info['name'];
            }
        }
        $options->add_field( array(
            'name' => esc_html__( 'Personal API Keys', 'antimena' ),
            'description' => esc_html__( 'When enabled, users will use their own API keys instead of yours and the credit system will be disabled.', 'antimena' ),
            'id'   => 'personal_api_keys',
            'type' => 'radio_inline',
            'options' => array(
                'enable' => esc_html__( 'Enable', 'antimena' ),
                'disable'   => esc_html__( 'Disable', 'antimena' )
            ),
            'attributes' => array(
                'autocomplete' => 'off'
            ),
            'default' => 'disable',
            'before_row' => '<div class="palleon-tab-content" data-id="antimena-title">',
        ) );
        $options->add_field( array(
            'name'    => esc_html__( 'User Roles', 'antimena' ),
            'desc'    => esc_html__( 'Select which user roles are allowed to use the ai tools without credits. Admins are always allowed.', 'antimena' ),
            'id'      => 'antimena_roles',
            'type'    => 'multicheck_inline',
            'options' => $roles,
        ) );  
        $options->add_field( array(
            'id'      => 'antimena_free_credits',
            'name'   => esc_html__( 'Free Credits', 'antimena' ),
            'type' => 'text',
            'description' => esc_html__( 'Give free credits to new users after they complete the registration.', 'antimena' ),
            'attributes' => array(
                'type' => 'number',
                'pattern' => '\d*',
                'autocomplete' => 'off'
            ),
            'default' => 0,
        ) );
        $options->add_field( array(
            'name'    => esc_html__( 'Stability.ai API Key', 'antimena' ),
            'description' => esc_html__( 'You must get a free API key from stability.ai to use the API. For more information, please read the documentation.', 'antimena' ),
            'id'      => 'sai_api_key',
            'type'    => 'text',
            'attributes' => array(
                'autocomplete' => 'off'
            ),
            'default' => '',
            'before_row' => '<h3 class="palleon-subtitle">' . esc_html__( 'Stability.ai', 'antimena' ) . '</h3>',
        ) );
        $options->add_field( array(
            'name' => esc_html__( 'Disable Stability.ai Modules', 'antimena' ),
            'id'   => 'sai_modules',
            'type' => 'multicheck_inline',
            'description' => esc_html__( 'Select which modules to disable.', 'antimena' ),
            'select_all_button' => false,
            'options' => array(
                'new' => esc_html__( 'New Image', 'antimena' ),
                'regenerator' => esc_html__( 'Regenerator', 'antimena' ),
                'upscaler'   => esc_html__( 'Upscaler', 'antimena' ),
                'remove_bg'   => esc_html__( 'Remove BG', 'antimena' ),
                'erase'   => esc_html__( 'Erase', 'antimena' ),
                'outpaint'   => esc_html__( 'Outpaint', 'antimena' ),
                'replace'   => esc_html__( 'Replace', 'antimena' ),
                'recolor'   => esc_html__( 'Recolor', 'antimena' ),
            ),
            'attributes' => array(
                'autocomplete' => 'off'
            )
        ) );
        $options->add_field( array(
            'id'      => 'sai_credit_cost',
            'name'   => esc_html__( 'Stability.ai credit cost', 'antimena' ),
            'type' => 'text',
            'description' => esc_html__( 'The credit cost per image.', 'antimena' ),
            'attributes' => array(
                'type' => 'number',
                'pattern' => '\d*',
                'autocomplete' => 'off'
            ),
            'default' => 1
        ) );
        $options->add_field( array(
            'name'    => esc_html__( 'OpenAI API Key', 'antimena' ),
            'description' => esc_html__( 'You must get a free API key from openai.com to use the API. For more information, please read the documentation.', 'antimena' ),
            'id'      => 'oai_api_key',
            'type'    => 'text',
            'attributes' => array(
                'autocomplete' => 'off'
            ),
            'default' => '',
            'before_row' => '<h3 class="palleon-subtitle">' . esc_html__( 'OpenAI', 'antimena' ) . '</h3>',
        ) );
        $options->add_field( array(
            'name' => esc_html__( 'OpenAI Model', 'antimena' ),
            'id'   => 'oai_model',
            'type' => 'select',
            'options' => array(
                'dall-e-2' => esc_html__( 'DALL-E 2', 'antimena' ),
                'dall-e-3' => esc_html__( 'DALL-E 3', 'antimena' ),
            ),
            'attributes' => array(
                'autocomplete' => 'off'
            ),
            'default' => 'dall-e-2'
        ) );
        $options->add_field( array(
            'name' => esc_html__( 'Disable OpenAI Modules', 'antimena' ),
            'id'   => 'oai_modules',
            'type' => 'multicheck_inline',
            'description' => esc_html__( 'Select which modules to disable.', 'antimena' ),
            'select_all_button' => false,
            'options' => array(
                'new' => esc_html__( 'New Image', 'antimena' ),
                'edit' => esc_html__( 'Image Edit', 'antimena' ),
                'variation'   => esc_html__( 'Image Variation', 'antimena' ),
            ),
            'attributes' => array(
                'autocomplete' => 'off'
            )
        ) );
        $options->add_field( array(
            'id'      => 'oai_credit_cost',
            'name'   => esc_html__( 'OpenAI credit cost', 'antimena' ),
            'type' => 'text',
            'description' => esc_html__( 'The credit cost per image.', 'antimena' ),
            'attributes' => array(
                'type' => 'number',
                'pattern' => '\d*',
                'autocomplete' => 'off'
            ),
            'default' => 1
        ) );
        $options->add_field( array(
            'name'    => esc_html__( 'Clipdrop API Key', 'antimena' ),
            'description' => esc_html__( 'You must get a free API key from clipdrop.co to use the API. For more information, please read the documentation.', 'antimena' ),
            'id'      => 'clipdrop_api_key',
            'type'    => 'text',
            'attributes' => array(
                'autocomplete' => 'off'
            ),
            'before_row' => '<h3 class="palleon-subtitle">' . esc_html__( 'Clipdrop', 'antimena' ) . '</h3>',
            'default' => ''
        ) );
        $options->add_field( array(
            'name' => esc_html__( 'Disable Clipdrop Modules', 'antimena' ),
            'id'   => 'clipdrop_modules',
            'type' => 'multicheck_inline',
            'description' => esc_html__( 'Select which modules to disable.', 'antimena' ),
            'select_all_button' => false,
            'options' => array(
                'new' => esc_html__( 'New Image', 'antimena' ),
                'remove_bg' => esc_html__( 'Remove BG', 'antimena' ),
                'replace_bg'   => esc_html__( 'Replace BG', 'antimena' ),
                'cleanup'   => esc_html__( 'Cleanup', 'antimena' ),
                'remove_text'   => esc_html__( 'Remove Text', 'antimena' ),
                'upscaler'   => esc_html__( 'Upscaler', 'antimena' ),
                'reimagine'   => esc_html__( 'Reimagine', 'antimena' ),
                'uncrop'   => esc_html__( 'Uncrop', 'antimena' ),
                'sketch'   => esc_html__( 'Sketch To Image', 'antimena' ),
            ),
            'attributes' => array(
                'autocomplete' => 'off'
            )
        ) );
        $options->add_field( array(
            'id'      => 'clipdrop_text_credit_cost',
            'name'   => esc_html__( 'Clipdrop Text-To-Image', 'antimena' ),
            'type' => 'text',
            'description' => esc_html__( 'The credit cost per image.', 'antimena' ),
            'attributes' => array(
                'type' => 'number',
                'pattern' => '\d*',
                'autocomplete' => 'off'
            ),
            'default' => 2
        ) );
        $options->add_field( array(
            'id'      => 'clipdrop_replace_credit_cost',
            'name'   => esc_html__( 'Clipdrop Replace Background', 'antimena' ),
            'type' => 'text',
            'description' => esc_html__( 'The credit cost per image.', 'antimena' ),
            'attributes' => array(
                'type' => 'number',
                'pattern' => '\d*',
                'autocomplete' => 'off'
            ),
            'default' => 3,
        ) );
        $options->add_field( array(
            'id'      => 'clipdrop_upscaler_credit_cost',
            'name'   => esc_html__( 'Clipdrop Upscaler', 'antimena' ),
            'type' => 'text',
            'description' => esc_html__( 'The credit cost per image.', 'antimena' ),
            'attributes' => array(
                'type' => 'number',
                'pattern' => '\d*',
                'autocomplete' => 'off'
            ),
            'default' => 2,
        ) );
        $options->add_field( array(
            'id'      => 'clipdrop_others_credit_cost',
            'name'   => esc_html__( 'Other Clipdrop Tools', 'antimena' ),
            'type' => 'text',
            'description' => esc_html__( 'The credit cost per image.', 'antimena' ),
            'attributes' => array(
                'type' => 'number',
                'pattern' => '\d*',
                'autocomplete' => 'off'
            ),
            'default' => 2,
            'after_row' => '</div>'
        ) );
    }

    /**
	 * Add tab titles
	 */
    public function antimena_tab_title() {
        $personal =  PalleonSettings::get_option('personal_api_keys', 'disable');
        $saiApiKey =  PalleonSettings::get_option('sai_api_key', '');
        $clipdropApiKey =  PalleonSettings::get_option('clipdrop_api_key', '');
        $oaiApiKey =  PalleonSettings::get_option('oai_api_key', '');
        if ($personal == 'enable') {
            echo '<li data-target="#modal-ai-image"><span class="material-icons">landscape</span>' . esc_html__('AI Image', 'antimena') . '</li>';
        } else if (!empty($saiApiKey) || !empty($clipdropApiKey) || !empty($oaiApiKey)) {
            echo '<li data-target="#modal-ai-image"><span class="material-icons">landscape</span>' . esc_html__('AI Image', 'antimena') . '</li>';
        }
    }

    /**
	 * Include tab contents
	 */
    public function antimena_tab() {
        $personal =  PalleonSettings::get_option('personal_api_keys', 'disable');
        $saiApiKey =  PalleonSettings::get_option('sai_api_key', '');
        $oaiApiKey =  PalleonSettings::get_option('oai_api_key', '');
        $clipdropApiKey =  PalleonSettings::get_option('clipdrop_api_key', '');
        $clipdropModules =  PalleonSettings::get_option('clipdrop_modules', array());
        $saiModules =  PalleonSettings::get_option('sai_modules', array());
        $oaiModules =  PalleonSettings::get_option('oai_modules', array());

        if ($personal == 'enable') {
            echo '<div id="modal-ai-image" class="palleon-tab">';
            echo '<div class="palleon-tabs">';
            echo '<ul class="palleon-tabs-menu">';
            if (!in_array('new', $saiModules)) { 
                echo '<li data-target="#sai-text-to-text-tab">' . esc_html__('Stability.ai', 'antimena') . '</li>';
            }
            if (!in_array('new', $oaiModules)) { 
                echo '<li data-target="#oai-text-to-text-tab">' . esc_html__('OpenAI', 'antimena') . '</li>';
            }
            if (!in_array('new', $clipdropModules)) {
                echo '<li data-target="#clipdrop-text-to-text-tab">' . esc_html__('Clipdrop', 'antimena') . '</li>';
                if (!in_array('sketch', $clipdropModules)) { 
                echo '<li id="sketch-to-image-link" data-target="#clipdrop-sketch-to-image-tab">' . esc_html__('Sketch To Image', 'antimena') . '</li>';
                }
            }
            echo '</ul>';
            if (!in_array('new', $saiModules)) { 
                include_once('includes/sai_new.php');
            }
            if (!in_array('new', $oaiModules)) { 
                include_once('includes/oai_new.php');
            }
            if (!in_array('new', $clipdropModules)) {
                include_once('includes/clipdrop_new.php');
                if (!in_array('sketch', $clipdropModules)) { 
                    include_once('includes/clipdrop_sketch.php');
                }
            }
            echo '</div>';
            echo '</div>';
        } else if (!empty($saiApiKey) || !empty($oaiApiKey) || !empty($clipdropApiKey)) {
            echo '<div id="modal-ai-image" class="palleon-tab">';
            echo '<div class="palleon-tabs">';
            echo '<ul class="palleon-tabs-menu">';
            if (!empty($saiApiKey) && !in_array('new', $saiModules)) { 
                echo '<li data-target="#sai-text-to-text-tab">' . esc_html__('Stability.ai', 'antimena') . '</li>';
            }
            if (!empty($oaiApiKey) && !in_array('new', $oaiModules)) { 
                echo '<li data-target="#oai-text-to-text-tab">' . esc_html__('OpenAI', 'antimena') . '</li>';
            }
            if (!empty($clipdropApiKey) && !in_array('new', $clipdropModules)) {
                echo '<li data-target="#clipdrop-text-to-text-tab">' . esc_html__('Clipdrop', 'antimena') . '</li>';
                if (!in_array('sketch', $clipdropModules)) { 
                    echo '<li id="sketch-to-image-link" data-target="#clipdrop-sketch-to-image-tab">' . esc_html__('Sketch To Image', 'antimena') . '</li>';
                }
            }
            echo '</ul>';

            $user = wp_get_current_user();
            $allowed_roles = PalleonSettings::get_option('antimena_roles', array());
            $allowed_user = 'no';
            array_push($allowed_roles, 'administrator'); 
            if ( array_intersect( $allowed_roles, $user->roles )) {
                $allowed_user = 'yes';
            }
            if ($allowed_user == 'no') {
                $creditsClass = new AntimenaCredits;
                $credits = $creditsClass->get_total();
                echo '<div class="antimena-user-credits"><span class="material-icons">monetization_on</span><span id="antimena-user-credits">' . $credits . '</span></div>'; 
            }
            if (!empty($saiApiKey) && !in_array('new', $saiModules)) { 
                include_once('includes/sai_new.php');
            }
            if (!empty($oaiApiKey) && !in_array('new', $oaiModules)) { 
                include_once('includes/oai_new.php');
            }
            if (!empty($clipdropApiKey) && !in_array('new', $clipdropModules)) {
                include_once('includes/clipdrop_new.php');
                if (!in_array('sketch', $clipdropModules)) { 
                    include_once('includes/clipdrop_sketch.php');
                }
            }
            echo '</div>';
            echo '</div>';
        }
    }

    /**
	 * Include custom adjust settings
	 */
    public function antimena_adjust() {
        $personal =  PalleonSettings::get_option('personal_api_keys', 'disable');
        $saiApiKey =  PalleonSettings::get_option('sai_api_key', '');
        $oaiApiKey =  PalleonSettings::get_option('oai_api_key', '');
        $clipdropApiKey =  PalleonSettings::get_option('clipdrop_api_key', '');

        if ($personal == 'enable') {
            echo '<hr><ul class="palleon-accordion antimena-adjust-accordion">';
            include_once('includes/sai_adjust.php');
            include_once('includes/oai_adjust.php');
            include_once('includes/clipdrop_adjust.php');
            echo '</ul>';
        } else if (!empty($saiApiKey) || !empty($oaiApiKey) || !empty($clipdropApiKey)) {
            echo '<hr><ul class="palleon-accordion antimena-adjust-accordion">';
            if (!empty($saiApiKey)) {
                include_once('includes/sai_adjust.php');
            }
            if (!empty($oaiApiKey)) {
                include_once('includes/oai_adjust.php');
            }
            if (!empty($clipdropApiKey)) {
                include_once('includes/clipdrop_adjust.php');
            }
            echo '</ul>';
        }
    }

    /**
	 * OpenAI text-to-image
	 */
    public function oai_text_to_img() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'antimena'));
        }
        $personal =  PalleonSettings::get_option('personal_api_keys', 'disable');
        $oaiApiKey =  PalleonSettings::get_option('oai_api_key', '');
        if ($personal == 'enable') {
            $oaiApiKey = get_user_meta(get_current_user_id(), 'oai_api_key',true);
        }
        if (!empty($oaiApiKey)) {
            $apiKey = trim($oaiApiKey);
            $curlURL = 'https://api.openai.com/v1/images/generations';
            $error = '';
            $model = PalleonSettings::get_option('oai_model', 'dall-e-2');
            $prompt = $_POST['prompt'];
            $size = $_POST['size'];
            $postdata = array();

            if ($model == 'dall-e-3') {
                $quality = $_POST['quality'];
                $style = $_POST['style'];
                $postdata = array(
                    "model" => $model,
                    "prompt" => $prompt,
                    "size" => $size,
                    "quality" => $quality,
                    "style" => $style,
                    "response_format" => "b64_json",
                    "n" => 1
                );

            } else {
                $postdata = array(
                    "prompt" => $prompt,
                    "size" => $size,
                    "response_format" => "b64_json",
                    "n" => 1
                );
            }

            $postdata = json_encode($postdata);

            $ch = curl_init();
            curl_setopt_array($ch, array(
                CURLOPT_URL => $curlURL,
                CURLOPT_POST => true,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 40,
                CURLOPT_HTTPHEADER => array(
                    "Content-Type: application/json",
                    "Authorization: Bearer {$apiKey}"
                ),
                CURLOPT_POSTFIELDS => $postdata
            ));
            $response = curl_exec($ch);

            if (curl_errno($ch) > 0) { 
                echo '{"error":{"message": "' . esc_html__( 'Error connecting to API. ', 'antimena' ) . curl_error($ch) . '"}}';
            } else {
                $responseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $data = json_decode($response);
                if ($responseCode !== 200) {
                    $error = json_encode($data);
                }    
                if ($data === false && json_last_error() !== JSON_ERROR_NONE) {
                    $error = '{"error":{"message": "' . esc_html__( 'Error parsing response.', 'antimena' ) . '"}}';
                }
                if (!empty($error)) {
                    echo $error;
                } else {
                    $images = $data->data;
                    foreach ( $images as $image ) {
                        $rand = rand();
                        $base64 = $image->b64_json;
                        echo '<div class="palleon-masonry-item">
                            <div class="palleon-masonry-item-inner">
                                <div class="palleon-img-wrap">
                                    <img id="oai-' . $rand . '" src="data:image/png;base64,' . $base64 . '" />
                                </div>
                                <div class="antimena-img-card">
                                    <div class="antimena-img-card-inner">
                                        <div class="antimena-img-btns">
                                            <button type="button" class="palleon-btn btn-full antimena-img-download" autocomplete="off" data-seed="oai-' . $rand . '"><span class="material-icons arrow">download</span>' . esc_html__('Download', 'antimena') . '</button>
                                            <button type="button" class="palleon-btn btn-full antimena-img-save" autocomplete="off" data-seed="oai-' . $rand . '"><span class="material-icons arrow">save</span>' . esc_html__('Save', 'antimena') . '</button>
                                            <button type="button" class="palleon-btn btn-full primary antimena-img-select" autocomplete="off" data-seed="oai-' . $rand . '"><span class="material-icons arrow">done</span>' . esc_html__('Select', 'antimena') . '</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>';   
                    }
                }    
            }
        } else {
            $error = '{"error":{"message": "' . esc_html__( 'API key is required.', 'antimena' ) . '"}}';
            echo $error;
        }
        wp_die();
    }

    /**
	 * Stability.ai text-to-image
	 */
    public function sai_text_to_img() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'antimena'));
        }
        $personal =  PalleonSettings::get_option('personal_api_keys', 'disable');
        $saiApiKey =  PalleonSettings::get_option('sai_api_key', '');
        if ($personal == 'enable') {
            $saiApiKey = get_user_meta(get_current_user_id(), 'sai_api_key',true);
        }
        if (!empty($saiApiKey)) {
            $apiKey = trim($saiApiKey);
            $curlURL = 'https://api.stability.ai/v2beta/stable-image/generate/core';
            $error = '';
            $prompt = sanitize_text_field($_POST['prompt']);
            $negativePrompt = sanitize_text_field($_POST['negativePrompt']);
            $ratio = sanitize_text_field($_POST['ratio']);
            $seed = sanitize_text_field($_POST['seed']);
            $presets = sanitize_text_field($_POST['presets']);
            if (empty($seed)) {
                $seed = 0;
            }
            $postdata = array(
                "prompt" => $prompt,
                "negative_prompt" => $negativePrompt,
                "aspect_ratio" => $ratio,
                "seed" => $seed,
            );
            if (!empty($presets)) {
                $postdata["style_preset"] = $presets;
            }
            $ch = curl_init();
            curl_setopt_array($ch, array(
                CURLOPT_URL => $curlURL,
                CURLOPT_POST => true,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 40,
                CURLOPT_HTTPHEADER => array(
                    "Content-Type: multipart/form-data",
                    "accept: application/json",
                    "Authorization: Bearer {$apiKey}",
                    "Stability-Client-ID: Antimena",
                    "Stability-Client-Version: " . ANTIMENA_VERSION
                ),
                CURLOPT_POSTFIELDS => $postdata
            ));
            $response = curl_exec($ch);
            if (curl_errno($ch) > 0) { 
                echo '{"message": "' . esc_html__( 'Error connecting to API. ', 'antimena' ) . curl_error($ch) . '"}';
            } else {
                $responseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $data = json_decode($response);
                if ($responseCode !== 200) {
                    $error = json_encode($data);
                }    
                if ($data === false && json_last_error() !== JSON_ERROR_NONE) {
                    $error = '{"message": "' . esc_html__( 'Error parsing response.', 'antimena' ) . '"}';
                }
                if (!empty($error)) {
                    echo $error;
                } else {
                    $base64 = $data->image;
                    $status = $data->finish_reason;
                    $seed = $data->seed;

                    if ($status != 'SUCCESS') {
                        echo '<div class="palleon-masonry-item">
                        <div class="palleon-masonry-item-inner">
                            <div class="palleon-img-wrap error">
                                <img src="' . esc_url(ANTIMENA_PLUGIN_URL) . 'assets/placeholder.png" />
                            </div>
                        </div>
                    </div>';
                    } else {
                        echo '<div class="palleon-masonry-item">
                                <div class="palleon-masonry-item-inner">
                                    <div class="palleon-img-wrap">
                                        <img id="' . $seed . '" src="data:image/png;base64,' . $base64 . '" />
                                    </div>
                                    <div class="antimena-img-card">
                                        <div class="antimena-img-card-inner">
                                            <div class="antimena-img-seed-wrap">
                                                <span>' . esc_html__('Seed:', 'antimena') . '</span>
                                                <input id="antimena-img-seed" class="palleon-form-field" type="text" value="' . $seed . '" autocomplete="off" readonly>
                                            </div>
                                            <div class="antimena-img-btns">
                                                <button type="button" class="palleon-btn btn-full antimena-img-download" autocomplete="off" data-seed="' . $seed . '"><span class="material-icons arrow">download</span>' . esc_html__('Download', 'antimena') . '</button>
                                                <button type="button" class="palleon-btn btn-full antimena-img-save" autocomplete="off" data-seed="' . $seed . '"><span class="material-icons arrow">save</span>' . esc_html__('Save', 'antimena') . '</button>
                                                <button type="button" class="palleon-btn btn-full primary antimena-img-select" autocomplete="off" data-seed="' . $seed . '"><span class="material-icons arrow">done</span>' . esc_html__('Select', 'antimena') . '</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>';
                    }
                }    
            }
        } else {
            $error = '{"message": "' . esc_html__( 'API key is required.', 'antimena' ) . '"}';
            echo $error;
        }
        wp_die();
    }

    /**
	 * Get ClipDrop API key
	 */
    public function get_clipdrop_api_key() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'antimena'));
        }
        $clipdropApiKey =  PalleonSettings::get_option('clipdrop_api_key', '');
        $personal =  PalleonSettings::get_option('personal_api_keys', 'disable');
        if ($personal == 'enable') {
            $clipdropApiKey = get_user_meta(get_current_user_id(), 'clipdrop_api_key',true);
        }
        if (!empty($clipdropApiKey)) {
            $apiKey = trim($clipdropApiKey);
            echo $apiKey;
        }
        wp_die();
    }

    /**
	 * Get OpenAI API key
	 */
    public function get_oai_api_key() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'antimena'));
        }
        $oaiApiKey =  PalleonSettings::get_option('oai_api_key', '');
        $personal =  PalleonSettings::get_option('personal_api_keys', 'disable');
        if ($personal == 'enable') {
            $oaiApiKey = get_user_meta(get_current_user_id(), 'oai_api_key',true);
        }
        if (!empty($oaiApiKey)) {
            $apiKey = trim($oaiApiKey);
            echo $apiKey;
        }
        wp_die();
    }

    /**
	 * Get Stability.ai API key
	 */
    public function get_sai_api_key() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'antimena'));
        }
        $saiApiKey =  PalleonSettings::get_option('sai_api_key', '');
        $personal =  PalleonSettings::get_option('personal_api_keys', 'disable');
        if ($personal == 'enable') {
            $saiApiKey = get_user_meta(get_current_user_id(), 'sai_api_key',true);
        }
        if (!empty($saiApiKey)) {
            $apiKey = trim($saiApiKey);
            echo $apiKey;
        }
        wp_die();
    }

    /**
	 * Get stability.ai check account balance
	 */
    static function sai_check_balance() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'antimena'));
        }
        $saiApiKey =  PalleonSettings::get_option('sai_api_key', '');
        $personal =  PalleonSettings::get_option('personal_api_keys', 'disable');
        if ($personal == 'enable') {
            $saiApiKey = get_user_meta(get_current_user_id(), 'sai_api_key',true);
        }
        if (!empty($saiApiKey)) {
            $user = wp_get_current_user();
            $allowed_roles = PalleonSettings::get_option('antimena_roles', array());
            $allowed_user = 'no';
            array_push($allowed_roles, 'administrator'); 
            if ( array_intersect( $allowed_roles, $user->roles )) {
                $allowed_user = 'yes';
            }
            $personal =  PalleonSettings::get_option('personal_api_keys', 'disable');
            if ($personal == 'enable') {
                $allowed_user = 'yes';
            }

            if ($allowed_user == 'yes') {
                $apiKey = trim($saiApiKey);
                $curlURL = "https://api.stability.ai/v1/user/balance";
                $ch = curl_init();
                curl_setopt_array($ch, array(
                    CURLOPT_URL => $curlURL,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_TIMEOUT => 20,
                    CURLOPT_HTTPHEADER => array(
                        "Content-Type: application/json",
                        "Authorization: Bearer {$apiKey}",
                        "Stability-Client-ID: Antimena",
                        "Stability-Client-Version: " . ANTIMENA_VERSION
                    )
                ));
                $response = curl_exec($ch);
                if (curl_errno($ch) > 0) { 
                    echo '{"message": "' . esc_html__( 'Error connecting to API. ', 'antimena' ) . curl_error($ch) . '"}';
                } else {
                    $responseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    $data = json_decode($response);
                    if ($responseCode !== 200) {
                        $error = json_encode($data);
                    }     
                    if ($data === false && json_last_error() !== JSON_ERROR_NONE) {
                        $error = '{"message": "' . esc_html__( 'Error parsing response.', 'antimena' ) . '"}';
                    }
                    if (!empty($error)) {
                        echo $error;
                    } else {
                        $balance = round($data->credits, 2);
                        echo '{"balance": "' . esc_html__( 'You have', 'antimena' ) . ' ' . $balance . ' ' . esc_html__( 'credits left.', 'antimena' ) . '"}';
                    }
                }
            } else {
                $credits = get_user_meta( $user->ID, 'antimena_user_credits', true);
                if (empty($credits)) {
                    $credits = '0';
                }
                echo '{"balance": "' . esc_html__( 'You have', 'antimena' ) . ' ' . $credits . ' ' . esc_html__( 'credits left.', 'antimena' ) . '"}';
            }
        } else {
            $error = '{"message": "' . esc_html__( 'API key is required.', 'antimena' ) . '"}';
            echo $error;
        }
        wp_die();
    }

    /**
	 * Get stability.ai get account balance
	 */
    static function sai_get_balance() {
        $saiApiKey =  PalleonSettings::get_option('sai_api_key', '');
        $personal =  PalleonSettings::get_option('personal_api_keys', 'disable');
        if ($personal == 'enable') {
            $saiApiKey = get_user_meta(get_current_user_id(), 'sai_api_key',true);
        }
        if (!empty($saiApiKey)) {
            $user = wp_get_current_user();
            $allowed_roles = PalleonSettings::get_option('antimena_roles', array());
            $allowed_user = 'no';
            array_push($allowed_roles, 'administrator'); 
            if ( array_intersect( $allowed_roles, $user->roles )) {
                $allowed_user = 'yes';
            }
            $personal =  PalleonSettings::get_option('personal_api_keys', 'disable');
            if ($personal == 'enable') {
                $allowed_user = 'yes';
            }

            if ($allowed_user == 'yes') {
                $apiKey = trim($saiApiKey);
                $curlURL = "https://api.stability.ai/v1/user/balance";
                $ch = curl_init();
                curl_setopt_array($ch, array(
                    CURLOPT_URL => $curlURL,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_TIMEOUT => 20,
                    CURLOPT_HTTPHEADER => array(
                        "Content-Type: application/json",
                        "Authorization: Bearer {$apiKey}",
                        "Stability-Client-ID: Antimena",
                        "Stability-Client-Version: " . ANTIMENA_VERSION
                    )
                ));
                $response = curl_exec($ch);
                if (curl_errno($ch) > 0) { 
                    return esc_html__( 'Error connecting to API. ', 'antimena' ) . curl_error($ch) . '.';
                } else {
                    $responseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    if ($responseCode === 401) {
                        return esc_html__( 'Missing authorization header.', 'antimena' );
                    } else if ($responseCode === 500) {
                        return esc_html__( 'An unexpected server error occurred, please try again later.', 'antimena' );
                    } else if ($responseCode !== 200) {
                        return "HTTP {$responseCode}";
                    }
                    $data = json_decode($response);
                    if ($data === false && json_last_error() !== JSON_ERROR_NONE) {
                        return esc_html__( 'Error parsing response.', 'antimena' );
                    }
                    $balance = round($data->credits, 2);
                    return esc_html__( 'You have', 'antimena' ) . ' ' . $balance . ' ' . esc_html__( 'credits left.', 'antimena' );
                }
            } else {
                $credits = get_user_meta( $user->ID, 'antimena_user_credits', true);
                if (empty($credits)) {
                    $credits = '0';
                }
                return esc_html__( 'You have', 'antimena' ) . ' ' . $credits . ' ' . esc_html__( 'credits left.', 'antimena' );
            }
        } else {
            return esc_html__( 'API key is required.', 'antimena' );
        }
    }

    /**
	 * Save Preferences
	 */
    public function antimena_save_api_keys(){
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'palleon'));
        }
        $user_id = get_current_user_id();
        if (isset($_POST['sai'])) {
            $sai_api_key = get_user_meta($user_id, 'sai_api_key',true);
            if (empty($sai_api_key)) {
                add_user_meta($user_id, 'sai_api_key', sanitize_text_field($_POST['sai']), true);
            } else {
                update_user_meta($user_id, 'sai_api_key', sanitize_text_field($_POST['sai']), false);
            }
        }
        if (isset($_POST['oai'])) {
            $oai_api_key = get_user_meta($user_id, 'oai_api_key',true);
            if (empty($oai_api_key)) {
                add_user_meta($user_id, 'oai_api_key', sanitize_text_field($_POST['oai']), true);
            } else {
                update_user_meta($user_id, 'oai_api_key', sanitize_text_field($_POST['oai']), false);
            }
        }
        if (isset($_POST['clipdrop'])) {
            $clipdrop_api_key = get_user_meta($user_id, 'clipdrop_api_key',true);
            if (empty($clipdrop_api_key)) {
                add_user_meta($user_id, 'clipdrop_api_key', sanitize_text_field($_POST['clipdrop']), true);
            } else {
                update_user_meta($user_id, 'clipdrop_api_key', sanitize_text_field($_POST['clipdrop']), false);
            }
        }
        wp_die();
    }
}

/**
 * Returns the main instance of the class
 */
function Antimena() {  
	return Antimena::instance();
}
// Global for backwards compatibility
$GLOBALS['Antimena'] = Antimena();    