=== Antimena - AI Image Generator ===
Contributors: Palleon Team
Donate link: http://palleon.website/antimena/
Requires PHP: 7.0