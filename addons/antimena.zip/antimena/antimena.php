<?php
/**
 * Plugin Name: Antimena
 * Plugin URI: https://palleon.website/antimena.php
 * Description: AI Image Generator Add-on For Palleon WordPress Image Editor
 * Version: 4.4.1
 * Requires PHP: 7.0
 * Author: Palleon Team
 * Author URI: https://palleon.website/
 * Text Domain: antimena
 * Domain Path: /languages
 *
 */

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'ANTIMENA_PLUGIN_URL' ) ) {
	define( 'ANTIMENA_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

if ( ! defined( 'ANTIMENA_PLUGIN_PATH' ) ) {
	define( 'ANTIMENA_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'ANTIMENA_VERSION' ) ) {
	define( 'ANTIMENA_VERSION', '4.4.1');
}

if ( ! defined( 'ANTIMENA_PALLEON_VERSION' ) ) {
	define( 'ANTIMENA_PALLEON_VERSION', '4.1.5');
}

/* Admin notices */
function antimena_requires_palleon(){
    echo '<div class="notice notice-error"><p>' . esc_html__( 'Antimena requires Palleon to be installed.', 'antimena' ) . ' <a href="https://palleon.website" target="_blank">' . esc_html__( 'Buy now!', 'antimena' ) . '</a></p></div>';
}

function antimena_requires_palleon_version(){
    echo '<div class="notice notice-warning"><p>' . esc_html__( 'Antimena requires Palleon version', 'antimena' ) . ' ' . ANTIMENA_PALLEON_VERSION . ' ' . esc_html__( 'or greater. You can download the latest version from your Codecanyon account.', 'antimena' ) . '</p></div>';
}

function antimena_pro_only(){
    echo '<div class="notice notice-error"><p>' . esc_html__( 'Antimena requires Pro Plan to be purchased.', 'antimena' ) . ' <a href="https://palleon.website" target="_blank">' . esc_html__( 'Buy now!', 'antimena' ) . '</a></p></div>';
}

/* Init */
function antimena_plugins_loaded() {
    if ( !defined( 'PALLEON_PLUGIN_URL' ) || !function_exists( 'palleon_fs' )  ) {
        add_action('admin_notices', 'antimena_requires_palleon');
        return;
    } 
    if ( !defined( 'PALLEON_VERSION' )  ) {
        add_action('admin_notices', 'antimena_requires_palleon_version');
        return;
    } else {
        if ( !version_compare( PALLEON_VERSION, ANTIMENA_PALLEON_VERSION, '>=' ) ) {
            add_action('admin_notices', 'antimena_requires_palleon_version');
            return;
        }
    }
    if ( palleon_fs()->is_plan('pro', true) ) {
        include_once('mainClass.php');
        include_once('userCredits.php');
    } else {
        add_action('admin_notices', 'antimena_pro_only');
        return;
    }
}
add_action('plugins_loaded', 'antimena_plugins_loaded', 11);