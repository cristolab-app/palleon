<div id="clipdrop-text-to-text-tab" class="palleon-tab">
    <div class="modal-ai-image-wrap">
        <div class="modal-ai-image-column-left">
            <div id="antimena-loader-2" class="palleon-loader-wrap antimena-loader"><div class="palleon-loader"></div></div>
            <div id="clipdrop-images" class="palleon-grid antimena-grid antimena-grid-placeholder">
                <div class="palleon-masonry-item">
                    <div class="palleon-masonry-item-inner">
                        <div class="palleon-img-wrap">
                            <img src="<?php echo esc_url(ANTIMENA_PLUGIN_URL . 'assets/placeholder.png'); ?>" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-ai-image-column-right">
            <ul class="palleon-accordion">
                <li class="opened">
                    <a href="#"><span class="material-icons accordion-icon text-success">check_circle</span><?php echo esc_html__('Prompt (required)', 'antimena'); ?><span class="material-icons arrow">keyboard_arrow_down</span></a>
                    <div>
                        <textarea id="clipdrop-prompt" class="palleon-form-field" rows="2" autocomplete="off" placeholder="<?php echo esc_attr__('Post-apocalyptic wasteland with rusted and abandoned vehicles, dust storms and towering dust clouds, gritty, dark, dramatic, apocalyptic, stylized', 'antimena'); ?>" maxlength="2000"></textarea>
                    </div>
                </li>
            </ul>
            <button id="clipdrop-image-generate" type="button" class="palleon-btn primary palleon-lg-btn btn-full" autocomplete="off" disabled><span class="material-icons arrow">landscape</span><?php echo esc_html__('Generate', 'antimena'); ?></button>
        </div>
    </div>
</div>