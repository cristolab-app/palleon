<?php $clipdropModules =  PalleonSettings::get_option('clipdrop_modules', array()); ?>
<?php if (!in_array('remove_bg', $clipdropModules)) { ?>
<li id="antimena-clipdrop-remove-background" class="hide-on-canvas-mode">
    <a href="#"><span class="material-icons accordion-icon">landscape</span><?php echo esc_html__('Remove BG', 'antimena'); ?><span class="data-count"><?php echo esc_html__( 'clipdrop', 'antimena' ); ?></span><span class="material-icons arrow">keyboard_arrow_down</span></a>
    <div>
        <div class="palleon-control-desc">
            <?php echo esc_html__('Layers will not be pushed to the API. Only the background image will be affected.', 'antimena'); ?>
        </div>
        <button id="clipdrop-remove-background" type="button" class="palleon-btn primary palleon-lg-btn btn-full" autocomplete="off"><span class="material-icons arrow">landscape</span><?php echo esc_html__('Remove Background', 'antimena'); ?></button>
    </div>
</li>
<?php } ?>
<?php if (!in_array('replace_bg', $clipdropModules)) { ?>
<li id="antimena-clipdrop-replace-background" class="hide-on-canvas-mode">
    <a href="#"><span class="material-icons accordion-icon">landscape</span><?php echo esc_html__('Replace BG', 'antimena'); ?><span class="data-count"><?php echo esc_html__( 'clipdrop', 'antimena' ); ?></span><span class="material-icons arrow">keyboard_arrow_down</span></a>
    <div>
        <div class="palleon-control-desc">
            <?php echo esc_html__('Layers will not be pushed to the API. Only the background image will be affected.', 'antimena'); ?>
        </div>
        <div class="palleon-control-wrap label-block">
            <label class="palleon-control-label"><?php echo esc_html__('Prompt (Required)', 'antimena'); ?></label>
            <div class="palleon-control">
                <textarea id="clipdrop-replace-bg-prompt" class="palleon-form-field" rows="2" autocomplete="off" maxlength="2000"></textarea>
            </div>
        </div>
        <div class="palleon-control-desc antimena-desc">
            <?php echo esc_html__('Describe the scene you want to teleport your item to.', 'antimena'); ?>
        </div>
        <button id="clipdrop-replace-background" type="button" class="palleon-btn primary palleon-lg-btn btn-full" autocomplete="off" disabled><span class="material-icons arrow">landscape</span><?php echo esc_html__('Replace Background', 'antimena'); ?></button>
    </div>
</li>
<?php } ?>
<?php if (!in_array('cleanup', $clipdropModules)) { ?>
<li id="antimena-clipdrop-inpainting" class="hide-on-canvas-mode">
    <a href="#"><span class="material-icons accordion-icon">landscape</span><?php echo esc_html__('Cleanup', 'antimena'); ?><span class="data-count"><?php echo esc_html__( 'clipdrop', 'antimena' ); ?></span><span class="material-icons arrow">keyboard_arrow_down</span></a>
    <div>
        <div class="palleon-control-desc">
            <?php echo esc_html__('Mark unwanted objects or defects using the "pencil brush" and click the button to remove them from the image. You can use any brush color.', 'antimena'); ?>
        </div>
        <button id="clipdrop-inpainting" type="button" class="palleon-btn primary palleon-lg-btn btn-full" autocomplete="off"><span class="material-icons arrow">landscape</span><?php echo esc_html__('Cleanup', 'antimena'); ?></button>
    </div>
</li>
<?php } ?>
<?php if (!in_array('remove_text', $clipdropModules)) { ?>
<li id="antimena-clipdrop-remove-text" class="hide-on-canvas-mode">
    <a href="#"><span class="material-icons accordion-icon">landscape</span><?php echo esc_html__('Remove Text', 'antimena'); ?><span class="data-count"><?php echo esc_html__( 'clipdrop', 'antimena' ); ?></span><span class="material-icons arrow">keyboard_arrow_down</span></a>
    <div>
        <div class="palleon-control-desc">
            <?php echo esc_html__('Layers will not be pushed to the API. Only the background image will be affected.', 'antimena'); ?>
        </div>
        <button id="clipdrop-remove-text" type="button" class="palleon-btn primary palleon-lg-btn btn-full" autocomplete="off"><span class="material-icons arrow">landscape</span><?php echo esc_html__('Remove Text', 'antimena'); ?></button>
    </div>
</li>
<?php } ?>
<?php if (!in_array('upscaler', $clipdropModules)) { ?>
<li id="antimena-clipdrop-upscaler">
    <a href="#"><span class="material-icons accordion-icon">landscape</span><?php echo esc_html__('Upscaler', 'antimena'); ?><span class="data-count"><?php echo esc_html__( 'clipdrop', 'antimena' ); ?></span><span class="material-icons arrow">keyboard_arrow_down</span></a>
    <div>
    <div class="palleon-control-wrap">
            <label class="palleon-control-label"><?php echo esc_html__('Width', 'antimena'); ?></label>
            <div class="palleon-control">
                <input id="clipdrop-upscale-width" class="palleon-form-field" type="number" value="" autocomplete="off" data-size="">
            </div>
        </div>
        <div class="palleon-control-wrap">
            <label class="palleon-control-label"><?php echo esc_html__('Height', 'antimena'); ?></label>
            <div class="palleon-control">
                <input id="clipdrop-upscale-height" class="palleon-form-field" type="number" value="" autocomplete="off" data-size="">
            </div>
        </div>
    <button id="clipdrop-upscale" type="button" class="palleon-btn primary palleon-lg-btn btn-full" autocomplete="off"><span class="material-icons arrow">landscape</span><?php echo esc_html__('Upscale Image', 'antimena'); ?></button>
    </div>
</li>
<?php } ?>
<?php if (!in_array('reimagine', $clipdropModules)) { ?>
<li id="antimena-clipdrop-reimagine">
    <a href="#"><span class="material-icons accordion-icon">landscape</span><?php echo esc_html__('Reimagine', 'antimena'); ?><span class="data-count"><?php echo esc_html__( 'clipdrop', 'antimena' ); ?></span><span class="material-icons arrow">keyboard_arrow_down</span></a>
    <div>
    <button id="clipdrop-clipdrop-reimagine" type="button" class="palleon-btn primary palleon-lg-btn btn-full" autocomplete="off"><span class="material-icons arrow">landscape</span><?php echo esc_html__('Reimagine', 'antimena'); ?></button>
    </div>
</li>
<?php } ?>
<?php if (!in_array('uncrop', $clipdropModules)) { ?>
<li id="antimena-clipdrop-uncrop">
    <a href="#"><span class="material-icons accordion-icon">landscape</span><?php echo esc_html__('Uncrop', 'antimena'); ?><span class="data-count"><?php echo esc_html__( 'clipdrop', 'antimena' ); ?></span><span class="material-icons arrow">keyboard_arrow_down</span></a>
    <div>
    <div class="palleon-control-wrap label-block">
        <label class="palleon-control-label slider-label"><?php echo esc_html__('Extend Top (px)', 'antimena'); ?><span>400</span></label>
        <div class="palleon-control">
            <input id="clipdrop-extend-top" type="range" min="0" max="2000" value="400" step="10" class="palleon-slider" autocomplete="off">
        </div>
    </div>
    <div class="palleon-control-wrap label-block">
        <label class="palleon-control-label slider-label"><?php echo esc_html__('Extend Bottom (px)', 'antimena'); ?><span>400</span></label>
        <div class="palleon-control">
            <input id="clipdrop-extend-bottom" type="range" min="0" max="2000" value="400" step="10" class="palleon-slider" autocomplete="off">
        </div>
    </div>
    <div class="palleon-control-wrap label-block">
        <label class="palleon-control-label slider-label"><?php echo esc_html__('Extend Left (px)', 'antimena'); ?><span>400</span></label>
        <div class="palleon-control">
            <input id="clipdrop-extend-left" type="range" min="0" max="2000" value="400" step="10" class="palleon-slider" autocomplete="off">
        </div>
    </div>
    <div class="palleon-control-wrap label-block">
        <label class="palleon-control-label slider-label"><?php echo esc_html__('Extend Right (px)', 'antimena'); ?><span>400</span></label>
        <div class="palleon-control">
            <input id="clipdrop-extend-right" type="range" min="0" max="2000" value="400" step="10" class="palleon-slider" autocomplete="off">
        </div>
    </div>
    <button id="clipdrop-uncrop" type="button" class="palleon-btn primary palleon-lg-btn btn-full" autocomplete="off"><span class="material-icons arrow">landscape</span><?php echo esc_html__('Uncrop', 'antimena'); ?></button>
    </div>
</li>
<?php } ?>