<div id="clipdrop-sketch-to-image-tab" class="palleon-tab">
    <div class="modal-ai-image-wrap">
        <div class="modal-ai-image-column-left">
            <div id="antimena-loader-3" class="palleon-loader-wrap antimena-loader"><div class="palleon-loader"></div></div>
            <div id="sketch-to-image-wrap">
                <canvas id="sketch-to-image-canvas"></canvas>
            </div>
        </div>
        <div class="modal-ai-image-column-right">
            <div id="clipdrop-sketch-images" class="palleon-grid antimena-grid antimena-grid-placeholder">
            </div>
            <ul class="palleon-accordion">
                <li class="opened">
                    <a href="#"><span class="material-icons accordion-icon text-success">check_circle</span><?php echo esc_html__('Prompt (required)', 'antimena'); ?><span class="material-icons arrow">keyboard_arrow_down</span></a>
                    <div>
                        <textarea id="sketch-to-image-prompt" class="palleon-form-field" rows="2" autocomplete="off" maxlength="2000"></textarea>
                        <div class="palleon-control-desc"><?php echo esc_html__('Generate an image corresponding to the sketch and the prompt describing what you expect.', 'antimena'); ?></div>
                    </div>
                </li>
                <li>
                    <a href="#"><span class="material-icons accordion-icon">settings</span><?php echo esc_html__('Brush Settings', 'antimena'); ?><span class="material-icons arrow">keyboard_arrow_down</span></a>
                    <div>
                        <?php $brush_width = PalleonSettings::get_option('antimena_brush_width', 8); ?>
                        <div class="palleon-control-wrap label-block">
                            <label class="palleon-control-label"><?php echo esc_html__('Brush Width', 'antimena'); ?></label>
                            <div class="palleon-control">
                                <input id="sketch-to-image-brush-width" class="palleon-form-field numeric-field" type="number" value="<?php echo esc_attr($brush_width); ?>" autocomplete="off" data-min="1" data-max="1000" data-step="1">
                            </div>
                        </div>
                        <?php $brush_color = PalleonSettings::get_option('antimena_brush_color', '#6658ea'); ?>
                        <div class="palleon-control-wrap control-text-color label-block">
                            <label class="palleon-control-label"><?php echo esc_html__('Brush Color', 'antimena'); ?></label>
                            <div class="palleon-control">
                                <input id="sketch-to-image-brush-color" type="text" class="palleon-colorpicker disallow-empty" autocomplete="off" value="<?php echo esc_attr($brush_color); ?>" />
                            </div>
                        </div>
                        <div class="palleon-control-wrap palleon-submit-btns sketch-to-image-buttons"> 
                            <button id="sketch-to-image-undo" type="button" class="palleon-btn tooltip" data-title="<?php echo esc_attr__('Undo', 'antimena'); ?>"><span class="material-icons">undo</span></button>
                            <button id="sketch-to-image-clear" type="button" class="palleon-btn tooltip" data-title="<?php echo esc_attr__('Clear', 'antimena'); ?>"><span class="material-icons">delete</span></button> 
                        </div>
                    </div>
                </li>
            </ul>
            <button id="sketch-to-image-generate" type="button" class="palleon-btn primary palleon-lg-btn btn-full" autocomplete="off" disabled><span class="material-icons arrow">landscape</span><?php echo esc_html__('Generate', 'antimena'); ?></button>
        </div>
    </div>
</div>