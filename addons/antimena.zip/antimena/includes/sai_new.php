<div id="sai-text-to-text-tab" class="palleon-tab">
<div class="modal-ai-image-wrap">
    <div class="modal-ai-image-column-left">
        <div id="antimena-loader-1" class="palleon-loader-wrap antimena-loader"><div class="palleon-loader"></div></div>
        <div id="sai-images" class="palleon-grid antimena-grid antimena-grid-placeholder">
            <div class="palleon-masonry-item">
                <div class="palleon-masonry-item-inner">
                    <div class="palleon-img-wrap">
                        <img src="<?php echo esc_url(ANTIMENA_PLUGIN_URL . 'assets/placeholder.png'); ?>" />
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal-ai-image-column-right">
        <ul class="palleon-accordion">
            <li class="opened">
                <a href="#"><span class="material-icons accordion-icon text-success">check_circle</span><?php echo esc_html__('Prompt (required)', 'antimena'); ?><span class="material-icons arrow">keyboard_arrow_down</span></a>
                <div>
                    <textarea id="sai-prompt" class="palleon-form-field" rows="2" autocomplete="off" placeholder="<?php echo esc_attr__('Post-apocalyptic wasteland with rusted and abandoned vehicles, dust storms and towering dust clouds, gritty, dark, dramatic, apocalyptic, stylized', 'antimena'); ?>" maxlength="10000"></textarea>
                </div>
            </li>
            <li>
                <a href="#"><span class="material-icons accordion-icon text-danger">cancel</span><?php echo esc_html__('Negative Prompt', 'antimena'); ?><span class="material-icons arrow">keyboard_arrow_down</span></a>
                <div>
                    <textarea id="sai-negative-prompt" class="palleon-form-field" rows="2" autocomplete="off" placeholder="<?php echo esc_attr__('black and white, monochrome', 'antimena'); ?>" maxlength="10000"></textarea>
                </div>
            </li>
            <li>
                <a href="#"><span class="material-icons accordion-icon">image</span><?php echo esc_html__('Source', 'antimena'); ?><span class="material-icons arrow">keyboard_arrow_down</span></a>
                <div>
                    <div class="palleon-control-wrap label-block">
                        <label class="palleon-control-label"><?php echo esc_html__('Aspect Ratio', 'antimena'); ?></label>
                        <div class="palleon-control">
                            <select id="sai-ratio" class="palleon-select" autocomplete="off">
                                <option value="1:1" selected>1:1</option>
                                <option value="16:9">16:9</option>
                                <option value="21:9">21:9</option>
                                <option value="2:3">2:3</option>
                                <option value="3:2">3:2</option>
                                <option value="4:5">4:5</option>
                                <option value="5:4">5:4</option>
                                <option value="9:16">9:16</option>
                                <option value="9:21">9:21</option>
                            </select>
                        </div>
                    </div>
                    <div class="palleon-control-wrap label-block">
                        <label class="palleon-control-label"><?php echo esc_html__('Seed (Optional)', 'antimena'); ?></label>
                        <div class="palleon-control">
                            <input id="sai-seed" class="palleon-form-field" type="number" value="" autocomplete="off">
                        </div>
                    </div>
                </div>
            </li>
            <li>
                <a href="#"><span class="material-icons accordion-icon">brush</span><?php echo esc_html__('Style', 'antimena'); ?><span class="material-icons arrow">keyboard_arrow_down</span></a>
                <div>
                <div class="palleon-control-wrap label-block">
                    <label class="palleon-control-label"><?php echo esc_html__('Style Preset', 'antimena'); ?></label>
                        <div class="palleon-control">
                            <select id="sai-style-presets" class="palleon-select" autocomplete="off">
                                <option value="" selected><?php echo esc_html__('Auto', 'antimena'); ?></option>
                                <option value="3d-model"><?php echo esc_html__('3d Model', 'antimena'); ?></option>
                                <option value="analog-film"><?php echo esc_html__('Analog Film', 'antimena'); ?></option>
                                <option value="anime"><?php echo esc_html__('Anime', 'antimena'); ?></option>
                                <option value="cinematic"><?php echo esc_html__('Cinematic', 'antimena'); ?></option>
                                <option value="comic-book"><?php echo esc_html__('Comic Book', 'antimena'); ?></option>
                                <option value="digital-art"><?php echo esc_html__('Digital Art', 'antimena'); ?></option>
                                <option value="enhance"><?php echo esc_html__('Enhance', 'antimena'); ?></option>
                                <option value="fantasy-art"><?php echo esc_html__('Fantasy Art', 'antimena'); ?></option>
                                <option value="isometric"><?php echo esc_html__('Isometric', 'antimena'); ?></option>
                                <option value="line-art"><?php echo esc_html__('Line Art', 'antimena'); ?></option>
                                <option value="low-poly"><?php echo esc_html__('Low Poly', 'antimena'); ?></option>
                                <option value="modeling-compound"><?php echo esc_html__('Modeling Compound', 'antimena'); ?></option>
                                <option value="neon-punk"><?php echo esc_html__('Neon Punk', 'antimena'); ?></option>
                                <option value="origami"><?php echo esc_html__('Origami', 'antimena'); ?></option>
                                <option value="photographic"><?php echo esc_html__('Photographic', 'antimena'); ?></option>
                                <option value="pixel-art"><?php echo esc_html__('Pixel Art', 'antimena'); ?></option>
                                <option value="tile-texture"><?php echo esc_html__('Tile Texture', 'antimena'); ?></option>
                            </select>
                        </div>
                    </div>
                </div>
            </li>
        </ul>
        <button id="sai-image-generate" type="button" class="palleon-btn primary palleon-lg-btn btn-full" autocomplete="off" disabled><span class="material-icons arrow">landscape</span><?php echo esc_html__('Generate', 'antimena'); ?></button>
        <div id="sai-balance-notice" class="notice notice-info">
            <span id="sai-balance"><?php echo Antimena::sai_get_balance(); ?></span><a href="#" id="sai-balance-check"><span class="material-icons arrow">refresh</span></a>
        </div>
    </div>
</div>
</div>