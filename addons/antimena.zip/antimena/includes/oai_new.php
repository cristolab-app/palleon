<?php $model = PalleonSettings::get_option('oai_model', 'dall-e-2'); ?>
<div id="oai-text-to-text-tab" class="palleon-tab">
<div class="modal-ai-image-wrap">
    <div class="modal-ai-image-column-left">
        <div id="antimena-loader-4" class="palleon-loader-wrap antimena-loader"><div class="palleon-loader"></div></div>
        <div id="oai-images" class="palleon-grid antimena-grid antimena-grid-placeholder">
            <div class="palleon-masonry-item">
                <div class="palleon-masonry-item-inner">
                    <div class="palleon-img-wrap">
                        <img src="<?php echo esc_url(ANTIMENA_PLUGIN_URL . 'assets/placeholder.png'); ?>" />
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal-ai-image-column-right">
        <ul class="palleon-accordion">
            <li class="opened">
                <a href="#"><span class="material-icons accordion-icon text-success">check_circle</span><?php echo esc_html__('Prompt (required)', 'antimena'); ?><span class="material-icons arrow">keyboard_arrow_down</span></a>
                <div>
                    <textarea id="oai-prompt" class="palleon-form-field" rows="2" autocomplete="off" placeholder="<?php echo esc_attr__('Post-apocalyptic wasteland with rusted and abandoned vehicles, dust storms and towering dust clouds, gritty, dark, dramatic, apocalyptic, stylized', 'antimena'); ?>" maxlength="1000"></textarea>
                </div>
            </li>
            <li>
                <a href="#"><span class="material-icons accordion-icon">image</span><?php echo esc_html__('Source', 'antimena'); ?><span class="material-icons arrow">keyboard_arrow_down</span></a>
                <div>
                    <div class="palleon-control-wrap label-block">
                        <label class="palleon-control-label"><?php echo esc_html__('Image Size', 'antimena'); ?></label>
                        <div class="palleon-control">
                            <select id="oai-size" class="palleon-select" autocomplete="off">
                                <?php if ($model == 'dall-e-2') { ?>
                                <option value="1024x1024" selected><?php echo esc_html__('1024x1024 px', 'antimena'); ?></option>
                                <option value="512x512"><?php echo esc_html__('512x512 px', 'antimena'); ?></option>
                                <option value="256x256"><?php echo esc_html__('256x256 px', 'antimena'); ?></option>
                                <?php } else { ?>
                                <option value="1024x1024" selected><?php echo esc_html__('1024x1024 px', 'antimena'); ?></option>
                                <option value="1792x1024"><?php echo esc_html__('1792x1024 px', 'antimena'); ?></option>
                                <option value="1024x1792"><?php echo esc_html__('1024x1792 px', 'antimena'); ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                </div>
            </li>
            <?php if ($model == 'dall-e-3') { ?>
            <li>
                <a href="#"><span class="material-icons accordion-icon">brush</span><?php echo esc_html__('Style', 'antimena'); ?><span class="material-icons arrow">keyboard_arrow_down</span></a>
                <div>
                    <div class="palleon-control-wrap label-block">
                        <label class="palleon-control-label"><?php echo esc_html__('Quality', 'antimena'); ?></label>
                        <div class="palleon-control">
                            <select id="oai-quality" class="palleon-select" autocomplete="off">
                                <option value="standard" selected><?php echo esc_html__('Standard', 'antimena'); ?></option>
                                <option value="hd"><?php echo esc_html__('HD', 'antimena'); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="palleon-control-wrap label-block">
                        <label class="palleon-control-label"><?php echo esc_html__('Style', 'antimena'); ?></label>
                        <div class="palleon-control">
                            <select id="oai-style" class="palleon-select" autocomplete="off">
                                <option value="vivid" selected><?php echo esc_html__('Vivid', 'antimena'); ?></option>
                                <option value="natural"><?php echo esc_html__('Natural', 'antimena'); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="palleon-control-desc">
                        <?php echo esc_html__('Vivid causes the model to lean towards generating hyper-real and dramatic images. Natural causes the model to produce more natural, less hyper-real looking images.', 'antimena'); ?>
                    </div>
                </div>
            </li>
            <?php } ?>
        </ul>
        <button id="oai-image-generate" type="button" class="palleon-btn primary palleon-lg-btn btn-full" autocomplete="off" disabled><span class="material-icons arrow">landscape</span><?php echo esc_html__('Generate', 'antimena'); ?></button>
    </div>
</div>
</div>