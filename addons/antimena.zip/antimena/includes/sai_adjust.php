<?php $saiModules =  PalleonSettings::get_option('sai_modules', array()); ?>
<?php if (!in_array('regenerator', $saiModules)) { ?>
<li id="antimena-sai-regenerator">
    <a href="#"><span class="material-icons accordion-icon">landscape</span><?php echo esc_html__('Regenerator', 'antimena'); ?><span class="data-count"><?php echo esc_html__( 'stability.ai', 'antimena' ); ?></span><span class="material-icons arrow">keyboard_arrow_down</span></a>
    <div>
        <div class="palleon-control-wrap label-block">
            <label class="palleon-control-label"><?php echo esc_html__('Prompt (Required)', 'antimena'); ?></label>
            <div class="palleon-control">
            <textarea id="sai-imgtoimg-prompt" class="palleon-form-field" rows="2" autocomplete="off" placeholder="<?php echo esc_attr__('Golden hour New York City skyline, iconic, dramatic', 'antimena'); ?>" maxlength="10000"></textarea>
            </div>
        </div>
        <div class="palleon-control-wrap label-block">
            <label class="palleon-control-label"><?php echo esc_html__('Negative Prompt', 'antimena'); ?></label>
            <div class="palleon-control">
            <textarea id="sai-imgtoimg-negative-prompt" class="palleon-form-field" rows="2" autocomplete="off" placeholder="<?php echo esc_attr__('black and white, monochrome', 'antimena'); ?>"></textarea>
            </div>
        </div>
        <div class="palleon-control-wrap">
            <label class="palleon-control-label"><?php echo esc_html__('Seed', 'antimena'); ?></label>
            <div class="palleon-control">
                <input id="sai-imgtoimg-seed" class="palleon-form-field" type="number" value="" autocomplete="off">
            </div>
        </div>
        <div class="palleon-control-wrap">
            <label class="palleon-control-label"><?php echo esc_html__('Alpha Mask', 'antimena'); ?></label>
            <div class="palleon-control palleon-toggle-control">
                <label class="palleon-toggle">
                    <input id="sai-imgtoimg-mask" class="palleon-toggle-checkbox" type="checkbox" autocomplete="off" />
                    <div class="palleon-toggle-switch"></div>
                </label>
            </div>
        </div>
        <div class="palleon-control-desc antimena-desc">
            <?php echo esc_html__('If alpha mask is enabled, fully transparent pixels are replaced and fully opaque pixels are unchanged. You can use "Erase BG Image" brush to remove the pixels on the background image.', 'antimena'); ?>
        </div>
        <button id="sai-imgtoimg-generate" type="button" class="palleon-btn primary palleon-lg-btn btn-full" autocomplete="off" disabled><span class="material-icons arrow">landscape</span><?php echo esc_html__('Generate', 'antimena'); ?></button>
    </div>
</li>
<?php } ?>
<?php if (!in_array('remove_bg', $saiModules)) { ?>
<li id="antimena-sai-remove-background" class="hide-on-canvas-mode">
    <a href="#"><span class="material-icons accordion-icon">landscape</span><?php echo esc_html__('Remove BG', 'antimena'); ?><span class="data-count"><?php echo esc_html__( 'stability.ai', 'antimena' ); ?></span><span class="material-icons arrow">keyboard_arrow_down</span></a>
    <div>
        <div class="palleon-control-desc">
            <?php echo esc_html__('Layers will not be pushed to the API. Only the background image will be affected.', 'antimena'); ?>
        </div>
        <button id="sai-remove-background" type="button" class="palleon-btn primary palleon-lg-btn btn-full" autocomplete="off"><span class="material-icons arrow">landscape</span><?php echo esc_html__('Remove Background', 'antimena'); ?></button>
    </div>
</li>    
<?php } ?>
<?php if (!in_array('upscaler', $saiModules)) { ?>
<li id="antimena-sai-upscaler">
    <a href="#"><span class="material-icons accordion-icon">landscape</span><?php echo esc_html__('Upscaler', 'antimena'); ?><span class="data-count"><?php echo esc_html__( 'stability.ai', 'antimena' ); ?></span><span class="material-icons arrow">keyboard_arrow_down</span></a>
    <div>
        <button id="sai-upscale" type="button" class="palleon-btn primary palleon-lg-btn btn-full" autocomplete="off"><span class="material-icons arrow">landscape</span><?php echo esc_html__('Upscale Image', 'antimena'); ?></button>
        <div class="palleon-control-desc antimena-desc">
            <?php echo esc_html__('Enhances image resolution by 4x using predictive and generative AI.', 'antimena'); ?>
        </div>
    </div>
</li>
<?php } ?>
<?php if (!in_array('erase', $saiModules)) { ?>
<li id="antimena-sai-erase" class="hide-on-canvas-mode">
    <a href="#"><span class="material-icons accordion-icon">landscape</span><?php echo esc_html__('Erase', 'antimena'); ?><span class="data-count"><?php echo esc_html__( 'stability.ai', 'antimena' ); ?></span><span class="material-icons arrow">keyboard_arrow_down</span></a>
    <div>
        <div class="palleon-control-desc">
            <?php echo esc_html__('Mark unwanted objects or defects using the "pencil brush" and click the button to remove them from the image. You can use any brush color.', 'antimena'); ?>
        </div>
        <button id="sai-erase" type="button" class="palleon-btn primary palleon-lg-btn btn-full" autocomplete="off"><span class="material-icons arrow">landscape</span><?php echo esc_html__('Erase', 'antimena'); ?></button>
    </div>
</li>
<?php } ?>
<?php if (!in_array('outpaint', $saiModules)) { ?>
<li id="antimena-sai-outpaint" class="hide-on-canvas-mode">
    <a href="#"><span class="material-icons accordion-icon">landscape</span><?php echo esc_html__('Outpaint', 'antimena'); ?><span class="data-count"><?php echo esc_html__( 'stability.ai', 'antimena' ); ?></span><span class="material-icons arrow">keyboard_arrow_down</span></a>
    <div>
    <div class="palleon-control-wrap label-block">
        <label class="palleon-control-label slider-label"><?php echo esc_html__('Extend Top (px)', 'antimena'); ?><span>400</span></label>
        <div class="palleon-control">
            <input id="sai-extend-top" type="range" min="0" max="2000" value="400" step="10" class="palleon-slider" autocomplete="off">
        </div>
    </div>
    <div class="palleon-control-wrap label-block">
        <label class="palleon-control-label slider-label"><?php echo esc_html__('Extend Bottom (px)', 'antimena'); ?><span>400</span></label>
        <div class="palleon-control">
            <input id="sai-extend-bottom" type="range" min="0" max="2000" value="400" step="10" class="palleon-slider" autocomplete="off">
        </div>
    </div>
    <div class="palleon-control-wrap label-block">
        <label class="palleon-control-label slider-label"><?php echo esc_html__('Extend Left (px)', 'antimena'); ?><span>400</span></label>
        <div class="palleon-control">
            <input id="sai-extend-left" type="range" min="0" max="2000" value="400" step="10" class="palleon-slider" autocomplete="off">
        </div>
    </div>
    <div class="palleon-control-wrap label-block">
        <label class="palleon-control-label slider-label"><?php echo esc_html__('Extend Right (px)', 'antimena'); ?><span>400</span></label>
        <div class="palleon-control">
            <input id="sai-extend-right" type="range" min="0" max="2000" value="400" step="10" class="palleon-slider" autocomplete="off">
        </div>
    </div>
    <button id="sai-outpaint" type="button" class="palleon-btn primary palleon-lg-btn btn-full" autocomplete="off"><span class="material-icons arrow">landscape</span><?php echo esc_html__('Generate', 'antimena'); ?></button>
    </div>
</li>
<?php } ?>
<?php if (!in_array('replace', $saiModules)) { ?>
<li id="antimena-sai-replace" class="hide-on-canvas-mode">
    <a href="#"><span class="material-icons accordion-icon">landscape</span><?php echo esc_html__('Replace', 'antimena'); ?><span class="data-count"><?php echo esc_html__( 'stability.ai', 'antimena' ); ?></span><span class="material-icons arrow">keyboard_arrow_down</span></a>
    <div>
        <div class="palleon-control-wrap label-block">
            <label class="palleon-control-label"><?php echo esc_html__('Prompt (Required)', 'antimena'); ?></label>
            <div class="palleon-control">
            <textarea id="sai-replace-prompt" class="palleon-form-field" rows="2" autocomplete="off" placeholder="<?php echo esc_attr__('golden retriever in a field', 'antimena'); ?>" maxlength="10000"></textarea>
            </div>
        </div>
        <div class="palleon-control-desc antimena-desc">
            <?php echo esc_html__('What you wish to see in the output image. A strong, descriptive prompt that clearly defines elements, colors, and subjects will lead to better results.', 'antimena'); ?>
        </div>
        <div class="palleon-control-wrap label-block">
            <label class="palleon-control-label"><?php echo esc_html__('Search Prompt (Required)', 'antimena'); ?></label>
            <div class="palleon-control">
            <textarea id="sai-replace-search-prompt" class="palleon-form-field" rows="2" autocomplete="off" placeholder="<?php echo esc_attr__('dog', 'antimena'); ?>" maxlength="10000"></textarea>
            </div>
        </div>
        <div class="palleon-control-desc antimena-desc">
            <?php echo esc_html__('Short description of what to inpaint in the image.', 'antimena'); ?>
        </div>
        <button id="sai-replace" type="button" class="palleon-btn primary palleon-lg-btn btn-full" autocomplete="off"><span class="material-icons arrow">landscape</span><?php echo esc_html__('Generate', 'antimena'); ?></button>
    </div>
</li>
<?php } ?>
<?php if (!in_array('recolor', $saiModules)) { ?>
<li id="antimena-sai-recolor" class="hide-on-canvas-mode">
    <a href="#"><span class="material-icons accordion-icon">landscape</span><?php echo esc_html__('Recolor', 'antimena'); ?><span class="data-count"><?php echo esc_html__( 'stability.ai', 'antimena' ); ?></span><span class="material-icons arrow">keyboard_arrow_down</span></a>
    <div>
        <div class="palleon-control-wrap label-block">
            <label class="palleon-control-label"><?php echo esc_html__('Prompt (Required)', 'antimena'); ?></label>
            <div class="palleon-control">
            <textarea id="sai-recolor-prompt" class="palleon-form-field" rows="2" autocomplete="off" placeholder="<?php echo esc_attr__('a yellow car', 'antimena'); ?>" maxlength="10000"></textarea>
            </div>
        </div>
        <div class="palleon-control-desc antimena-desc">
            <?php echo esc_html__('What you wish to see in the output image. A strong, descriptive prompt that clearly defines elements, colors, and subjects will lead to better results.', 'antimena'); ?>
        </div>
        <div class="palleon-control-wrap label-block">
            <label class="palleon-control-label"><?php echo esc_html__('Select Prompt (Required)', 'antimena'); ?></label>
            <div class="palleon-control">
            <textarea id="sai-recolor-select-prompt" class="palleon-form-field" rows="2" autocomplete="off" placeholder="<?php echo esc_attr__('car', 'antimena'); ?>" maxlength="10000"></textarea>
            </div>
        </div>
        <div class="palleon-control-desc antimena-desc">
            <?php echo esc_html__('Short description of what to search for in the image.', 'antimena'); ?>
        </div>
        <button id="sai-recolor" type="button" class="palleon-btn primary palleon-lg-btn btn-full" autocomplete="off"><span class="material-icons arrow">landscape</span><?php echo esc_html__('Generate', 'antimena'); ?></button>
    </div>
</li>
<?php } ?>
