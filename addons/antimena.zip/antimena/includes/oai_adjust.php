<?php $oaiModules =  PalleonSettings::get_option('oai_modules', array()); ?>
<?php if (!in_array('edit', $oaiModules)) { ?>
<li id="antimena-oai-edit">
    <a href="#"><span class="material-icons accordion-icon">landscape</span><?php echo esc_html__('Image Edit', 'antimena'); ?><span class="data-count"><?php echo esc_html__( 'OpenAI', 'antimena' ); ?></span><span class="material-icons arrow">keyboard_arrow_down</span></a>
    <div>
        <div class="palleon-control-wrap label-block">
            <label class="palleon-control-label"><?php echo esc_html__('Image Size', 'antimena'); ?></label>
            <div class="palleon-control">
                <select id="oai-edit-size" class="palleon-select" autocomplete="off">
                    <option value="1024x1024" selected><?php echo esc_html__('1024x1024 px', 'antimena'); ?></option>
                    <option value="512x512"><?php echo esc_html__('512x512 px', 'antimena'); ?></option>
                    <option value="256x256"><?php echo esc_html__('256x256 px', 'antimena'); ?></option>
                </select>
            </div>
        </div>
        <div class="palleon-control-wrap label-block">
            <label class="palleon-control-label"><?php echo esc_html__('Prompt (Required)', 'antimena'); ?></label>
            <div class="palleon-control">
            <textarea id="oai-edit-prompt" class="palleon-form-field" rows="2" autocomplete="off" placeholder="<?php echo esc_attr__('Golden hour New York City skyline, iconic, dramatic', 'antimena'); ?>" maxlength="1000"></textarea>
            </div>
        </div>
        <div class="palleon-control-desc">
            <?php echo esc_html__('The transparent areas of the image indicate where the image should be edited, and the prompt should describe the full new image, not just the transparent areas. You can use "Erase BG Image" brush to remove the pixels on the background image.', 'antimena'); ?>
        </div>
        <button id="oai-edit" type="button" class="palleon-btn primary palleon-lg-btn btn-full" autocomplete="off" disabled><span class="material-icons arrow">landscape</span><?php echo esc_html__('Edit Image', 'antimena'); ?></button>
    </div>
</li>
<?php } ?>
<?php if (!in_array('variation', $oaiModules)) { ?>
<li id="antimena-oai-variation" class="hide-on-canvas-mode">
    <a href="#"><span class="material-icons accordion-icon">landscape</span><?php echo esc_html__('Image Variation', 'antimena'); ?><span class="data-count"><?php echo esc_html__( 'OpenAI', 'antimena' ); ?></span><span class="material-icons arrow">keyboard_arrow_down</span></a>
    <div>
        <div class="palleon-control-desc">
            <?php echo esc_html__('Creates a variation of the background image. Layers will not be pushed to the API. Only the background image will be affected.', 'antimena'); ?>
        </div>
        <button id="oai-variation" type="button" class="palleon-btn primary palleon-lg-btn btn-full" autocomplete="off"><span class="material-icons arrow">landscape</span><?php echo esc_html__('Generate', 'antimena'); ?></button>
    </div>
</li>
<?php } ?>