<?php
namespace ElementorCalumma;
use PalleonSettings;

class CalummaLoadElementor {

    /**
	 * The single instance of the class
	 */
	private static $_instance = null;

    /**
	 * Main Instance
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

    /**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'widget_styles' ] );
        add_action( 'elementor/frontend/after_register_scripts', [ $this, 'widget_scripts' ] );
		add_action( 'elementor/elements/categories_registered', [ $this, 'widget_category' ] );
		add_action( 'elementor/widgets/register', [ $this, 'register_widgets' ] );
	}

    /**
	 * Include widget files
	 */
	private function include_widgets_files() {
		require_once( __DIR__ . '/widgets/ajax-grid.php' );
		require_once( __DIR__ . '/widgets/classic-grid.php' );
		require_once( __DIR__ . '/widgets/pexels.php' );
		require_once( __DIR__ . '/widgets/pixabay.php' );
	}

    /**
	 * Register styles
	 */
	public function widget_styles() {
        wp_register_style( 'spotlight', plugins_url( '/css/spotlight.css', __FILE__ ), false, CALUMMA_VERSION);
		wp_register_style( 'calumma-style', plugins_url( '/css/style.css', __FILE__ ), false, CALUMMA_VERSION);

		$inline_style = '';
		$font_family =  PalleonSettings::get_option('calumma_lightbox_font_family', 'inherit');
		$title_size =  PalleonSettings::get_option('calumma_lightbox_title_size', 18);
		$pager_size =  PalleonSettings::get_option('calumma_lightbox_pager_size', 16);
		$button_size =  PalleonSettings::get_option('calumma_lightbox_button_size', 16);
		$title_color =  PalleonSettings::get_option('calumma_lightbox_color', '#FFFFFF');
		$background =  PalleonSettings::get_option('calumma_lightbox_bg', '#000000');
		$loader_bg =  PalleonSettings::get_option('calumma_lightbox_loader', 'rgba(255,255,255,0.45)');
		$header_color =  PalleonSettings::get_option('calumma_lightbox_header', 'rgba(0,0,0,0.45)');
		$icon_color =  PalleonSettings::get_option('calumma_lightbox_icon_color', 'light');
		$btn_bg =  PalleonSettings::get_option('calumma_lightbox_btn_bg', '#6658EA');
		$btn_bg_hover =  PalleonSettings::get_option('calumma_lightbox_btn_bg_hover', '#5546E8');
		$btn_color =  PalleonSettings::get_option('calumma_lightbox_btn_text', '#FFFFFF');
		$btn_color_hover =  PalleonSettings::get_option('calumma_lightbox_btn_text_hover', '#FFFFFF');

		if ($font_family != 'inherit') {
			$inline_style .= '#spotlight {font-family: ' . $font_family . ';}';
		}
		if ($title_size != 18) {
			$inline_style .= '#spotlight .spl-title {font-size: ' . $title_size . 'px;}';
		}
		if ($pager_size != 16) {
			$inline_style .= '#spotlight .spl-page {font-size: ' . $pager_size . 'px;}';
		}
		if ($button_size != 16) {
			$inline_style .= '#spotlight .spl-button {font-size: ' . $button_size . 'px;}';
		}
		if ($title_color != '#FFFFFF') {
			$inline_style .= '#spotlight {color: ' . $title_color . ' !important;}';
		}
		if ($background != '#FFFFFF') {
			$inline_style .= '#spotlight {background: ' . $background . ' !important;}';
		}
		if ($loader_bg != 'rgba(255,255,255,0.45)') {
			$inline_style .= '#spotlight .spl-progress {background-color: ' . $loader_bg . ';}';
		}
		if ($header_color != 'rgba(0,0,0,0.45)') {
			$inline_style .= '#spotlight .spl-header,#spotlight .spl-footer {background-color: ' . $header_color . ';}';
		}
		if ($icon_color == 'dark') {
			$inline_style .= '#spotlight .spl-spinner,#spotlight .spl-prev,#spotlight .spl-next,#spotlight .spl-page ~ * {filter: invert(1);}';
		}
		if ($btn_bg != '#6658EA') {
			$inline_style .= '#spotlight .spl-button {background-color: ' . $btn_bg . ';}';
		}
		if ($btn_bg_hover != '#5546E8') {
			$inline_style .= '#spotlight .spl-button:hover,#spotlight .spl-button:focus {background-color: ' . $btn_bg_hover . ';}';
		}
		if ($btn_color != '#6658EA') {
			$inline_style .= '#spotlight .spl-button {color: ' . $btn_color . ';}';
		}
		if ($btn_color_hover != '#5546E8') {
			$inline_style .= '#spotlight .spl-button:hover,#spotlight .spl-button:focus {color: ' . $btn_color_hover . ';}';
		}

		wp_add_inline_style( 'spotlight', $inline_style );
	}

    /**
	 * Register widgets
	 */
	public function register_widgets() {
		$this->include_widgets_files();
		
		\Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Calumma_Ajax_Grid() );
		\Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Calumma_Classic_Grid() );
		\Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Calumma_Pexels() );
		\Elementor\Plugin::instance()->widgets_manager->register( new Widgets\Calumma_Pixabay() );
	}

    /**
	 * Register scripts
	 */
    public function widget_scripts() {
		wp_register_script( 'spotlight', plugins_url( '/js/spotlight.min.js', __FILE__ ), [ 'jquery' ], CALUMMA_VERSION, true );
		wp_register_script( 'calumma-classic-grid', plugins_url( '/js/classic-grid.js', __FILE__ ), [ 'jquery' ], CALUMMA_VERSION, true );
		wp_register_script( 'calumma-ajax-grid', plugins_url( '/js/ajax-grid.js', __FILE__ ), [ 'jquery' ], CALUMMA_VERSION, true );
		wp_register_script( 'calumma-pexels', plugins_url( '/js/pexels.js', __FILE__ ), [ 'jquery' ], CALUMMA_VERSION, true );
		wp_register_script( 'calumma-pixabay', plugins_url( '/js/pixabay.js', __FILE__ ), [ 'jquery' ], CALUMMA_VERSION, true );
		$param = array(
			"ajaxurl" => admin_url( 'admin-ajax.php' ),
            "nonce" => wp_create_nonce('calumma-nonce'),
			"add" => esc_html__( 'Add to favorites', 'calumma' ),
			"added" => esc_html__( 'Unfavorite', 'calumma' ),
			"error" => esc_html__( 'An unexpected error occured!', 'calumma' ),
			"nothing" => esc_html__( 'No results found.', 'calumma' ),
		);
		wp_localize_script('spotlight', 'calumma', $param);
	}

    /**
	 * Register category
	 */
	public function widget_category($elements_manager) {
		$elements_manager->add_category(
			'calumma-widgets',
			[
				'title' => esc_html__( 'Palleon', 'calumma' ),
				'icon' => 'fa fa-plug',
			]
		);
	}
}

/**
 * Returns the main instance of the class
 */
function CalummaLoadElementor() {  
	CalummaLoadElementor::instance();
}
// Global for backwards compatibility
$GLOBALS['CalummaLoadElementor'] = CalummaLoadElementor();  