<?php
defined( 'ABSPATH' ) || exit;

class Calumma extends Palleon {
    /**
	 * The single instance of the class
	 */
	protected static $_instance = null;

    /**
	 * Main Instance
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

    /**
	 * Constructor
	 */
    public function __construct() {
        add_action('init', array($this, 'calumma_init'), 1);
        add_filter('plugin_row_meta', array($this, 'calumma_plugin_links'), 10, 4);
        add_action('palleon_add_setting_tab', array($this, 'calumma_setting_tab'));
		add_action('palleon_add_settings', array($this, 'calumma_settings'));
        add_action('wp_ajax_calummaFav', array($this, 'fav_template'));
        add_action('wp_ajax_nopriv_calummaFav', array($this, 'fav_template'));
        add_action('wp_ajax_calummaSearch', array($this, 'template_search'));
        add_action('wp_ajax_nopriv_calummaSearch', array($this, 'template_search'));
        add_action('wp_ajax_calummaPexelsSearch', array($this, 'pexels_search'));
        add_action('wp_ajax_nopriv_calummaPexelsSearch', array($this, 'pexels_search'));
        add_action('wp_ajax_calummaPixabaySearch', array($this, 'pixabay_search'));
        add_action('wp_ajax_nopriv_calummaPixabaySearch', array($this, 'pixabay_search'));
    }

    /**
	 * Init
	 */
    public function calumma_init() {
        // Load text domain
        load_plugin_textdomain( 'calumma', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
    }

    /**
	 * Add plugin links to plugins page on the admin dashboard
	 */
    public function calumma_plugin_links($links_array, $plugin_file_name, $plugin_data, $status) {
        if ( strpos( $plugin_file_name, 'calumma.php' ) !== false ) {
            $links_array[] = '<a href="'. esc_url( get_admin_url(null, 'admin.php?page=palleon_options&tab=cmb2-id-calumma-title') ) .'">' . esc_html__( 'Settings', 'calumma' ) . '</a>';
            $links_array[] = '<a href="https://palleon.website/calumma/documentation/" target="_blank">' . esc_html__( 'Documentation', 'calumma' ) . '</a>';
        }
        return $links_array;
    }

    /**
	 * Add Setting Tab
	 */
    public function calumma_setting_tab($options) {
        $options->add_field( array(
            'name' => '<span class="dashicons dashicons-admin-plugins"></span>' . esc_html__( 'Calumma (Lightbox)', 'calumma' ),
            'id'   => 'calumma_title',
            'type' => 'title'
        ) );
    }

    /**
	 * Add Settings
	 */
    public function calumma_settings($options) {
        $options->add_field( array(
            'name' => esc_html__( 'Font Family', 'calumma' ),
            'id'   => 'calumma_lightbox_font_family',
            'type' => 'select',
            'options' => array(
                'inherit' => esc_html__( 'Theme Default', 'calumma' ),
                'Impact, Charcoal, sans-serif' => esc_html__( 'Impact', 'calumma' ),
                'Helvetica Neue, Helvetica, Arial, sans-serif' => esc_html__( 'Helvetica Neue', 'calumma' ),
                'Georgia, serif' => esc_html__( 'Georgia', 'calumma' ),
                "'Palatino Linotype', 'Book Antiqua', Palatino, serif" => esc_html__( 'Palatino Linotype', 'calumma' ),
                'Times New Roman, Times, serif' => esc_html__( 'Times New Roman', 'calumma' ),
                'Arial, Helvetica, sans-serif' => esc_html__( 'Arial', 'calumma' ),
                'Arial Black, Gadget, sans-serif' => esc_html__( 'Arial Black', 'calumma' ),
                'Comic Sans MS, cursive, sans-serif' => esc_html__( 'Comic Sans', 'calumma' ),
                'Lucida Sans Unicode, Lucida Grande, sans-serif' => esc_html__( 'Lucida Sans', 'calumma' ),
                'Tahoma, Geneva, sans-serif' => esc_html__( 'Tahoma', 'calumma' ),
                'Trebuchet MS, Helvetica, sans-serif' => esc_html__( 'Trebuchet', 'calumma' ),
                'Verdana, Geneva, sans-serif' => esc_html__( 'Verdana', 'calumma' ),
                'Courier New, Courier, monospace' => esc_html__( 'Courier New', 'calumma' ),
                'Lucida Console, Monaco, monospace' => esc_html__( 'Lucida Console', 'calumma' )
            ),
            'attributes' => array(
                'autocomplete' => 'off'
            ),
            'default' => 'inherit',
            'before_row' => '<div class="palleon-tab-content" data-id="calumma-title">'
        ) );

        $options->add_field( array(
            'name'    => esc_html__( 'Title Font Size (px)', 'calumma' ),
            'id'      => 'calumma_lightbox_title_size',
            'type' => 'text',
            'attributes' => array(
                'type' => 'number',
                'pattern' => '\d*',
                'autocomplete' => 'off'
            ),
            'default' => 18
        ) );

        $options->add_field( array(
            'name'    => esc_html__( 'Title Color', 'calumma' ),
            'id'      => 'calumma_lightbox_color',
            'type'    => 'colorpicker',
            'default' => '#FFFFFF',
            'options' => array(
                'alpha' => true
            )
        ) );

        $options->add_field( array(
            'name'    => esc_html__( 'Background', 'calumma' ),
            'id'      => 'calumma_lightbox_bg',
            'type'    => 'colorpicker',
            'default' => '#000000',
            'options' => array(
                'alpha' => true
            )
        ) );

        $options->add_field( array(
            'name'    => esc_html__( 'Loader Background', 'calumma' ),
            'id'      => 'calumma_lightbox_loader',
            'type'    => 'colorpicker',
            'default' => 'rgba(255,255,255,0.45)',
            'options' => array(
                'alpha' => true
            )
        ) );

        $options->add_field( array(
            'name'    => esc_html__( 'Header/Footer Background', 'calumma' ),
            'id'      => 'calumma_lightbox_header',
            'type'    => 'colorpicker',
            'default' => 'rgba(0,0,0,0.45)',
            'options' => array(
                'alpha' => true
            )
        ) );

        $options->add_field( array(
            'name' => esc_html__( 'Icon Color', 'calumma' ),
            'id'   => 'calumma_lightbox_icon_color',
            'type' => 'radio_inline',
            'options' => array(
                'dark' => esc_html__( 'Dark', 'calumma' ),
                'light'   => esc_html__( 'Light', 'calumma' )
            ),
            'attributes' => array(
                'autocomplete' => 'off'
            ),
            'default' => 'light'
        ) );

        $options->add_field( array(
            'name'    => esc_html__( 'Button Font Size (px)', 'calumma' ),
            'id'      => 'calumma_lightbox_button_size',
            'type' => 'text',
            'attributes' => array(
                'type' => 'number',
                'pattern' => '\d*',
                'autocomplete' => 'off'
            ),
            'default' => 16
        ) );

        $options->add_field( array(
            'name'    => esc_html__( 'Button Background', 'calumma' ),
            'id'      => 'calumma_lightbox_btn_bg',
            'type'    => 'colorpicker',
            'default' => '#6658EA',
            'options' => array(
                'alpha' => true
            )
        ) );

        $options->add_field( array(
            'name'    => esc_html__( 'Button Hover Background', 'calumma' ),
            'id'      => 'calumma_lightbox_btn_bg_hover',
            'type'    => 'colorpicker',
            'default' => '#5546E8',
            'options' => array(
                'alpha' => true
            )
        ) );

        $options->add_field( array(
            'name'    => esc_html__( 'Button Text Color', 'calumma' ),
            'id'      => 'calumma_lightbox_btn_text',
            'type'    => 'colorpicker',
            'default' => '#FFFFFF',
            'options' => array(
                'alpha' => true
            )
        ) );

        $options->add_field( array(
            'name'    => esc_html__( 'Button Text Hover Color', 'calumma' ),
            'id'      => 'calumma_lightbox_btn_text_hover',
            'type'    => 'colorpicker',
            'default' => '#FFFFFF',
            'options' => array(
                'alpha' => true
            )
        ) );

        $options->add_field( array(
            'name'    => esc_html__( 'Pager Font Size (px)', 'calumma' ),
            'id'      => 'calumma_lightbox_pager_size',
            'type' => 'text',
            'attributes' => array(
                'type' => 'number',
                'pattern' => '\d*',
                'autocomplete' => 'off'
            ),
            'default' => 16,
            'after_row' => '</div>'
        ) );
    }

    /**
	 * Ajax Add To Favorites
	 */
    public function fav_template(){
        if ( ! wp_verify_nonce( $_POST['nonce'], 'calumma-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'calumma'));
        }
        $templates = palleon_get_templates(false);
        $selected_templates = get_user_meta(get_current_user_id(), 'palleon_template_fav',true);
        if (empty($selected_templates)) {
            add_user_meta(get_current_user_id(), 'palleon_template_fav', array(), true);
            $selected_templates = array();
        }
        if ($_POST['mode'] == 'remove') {
            $remove = array($_POST['templateid']);
            $selected_templates = array_diff( $selected_templates, $remove);
        } else {
            array_unshift($selected_templates, $_POST['templateid']); 
        }
        update_user_meta(get_current_user_id(),'palleon_template_fav', $selected_templates, false);
        wp_die();
    }

    /**
	 * Template Search
	 */
    public function template_search(){
        if ( ! wp_verify_nonce( $_POST['nonce'], 'calumma-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'calumma'));
        }
        $user_fav = get_user_meta(get_current_user_id(), 'palleon_template_fav',true);
        if (empty($user_fav)) {
            $user_fav = array();
        }
        $template_order =  PalleonSettings::get_option('template_order', 'random');
        $templates = palleon_templates();
        if ($template_order == 'random') {
            shuffle($templates);
        } else if ($template_order == 'new') {
            $templates = array_reverse($templates);
        }
        $category = $_POST['category'];
        if (!empty($category) && $category != 'all') {
            $filteredArray = array();
            foreach($templates as $template) {
                if (in_array($category, $template[4])) {
                    $filteredArray[] = $template;
                }
            }
            $templates = $filteredArray;
        }
        $keyword = $_POST['keyword'];
        if (!empty($keyword)) {
            $filteredArray = array();
            foreach($templates as $template) {
                if (stripos($template[1], $keyword) !== false) {
                    $filteredArray[] = $template;
                }
            }
            $templates = $filteredArray;
        }
        if ($templates == array()) {
            echo '';
        } else {
            $max = 0;
            if (intval($_POST['page']) !== 0 && intval($_POST['page']) !== 1) {
                $offset = intval($_POST['max']) * (intval($_POST['page']) - 1);
                $templates = array_slice($templates, $offset);
            }
            foreach($templates as $template) {
				$template_version = 'free';
				if (isset($template[5])) {
					$template_version = $template[5]; 
				}
                if ($max >= intval($_POST['max'])) {
					break;
				} else {
					$max ++;
				}
                $item_img = $template[2];
                if ($_POST['size'] == 'full') {
					$item_img = $template[6];
				}
			?><div class="calumma-masonry-item">
				<div class="calumma-masonry-item-inner">
                    <div class="calumma-img-loader"><div></div></div>
					<?php if ($template_version == 'pro') { ?>
                	<div class="calumma-masonry-item-icon calumma-masonry-item-version" title="<?php echo esc_attr__( 'PRO Template', 'calumma' ); ?>"><i class="fas fa-crown"></i></div>
                	<?php } ?>
					<div class="calumma-masonry-item-icon calumma-masonry-item-menu"><i class="fas fa-ellipsis-h"></i></div>
					<div class="calumma-masonry-item-dropdown">
						<h5><?php echo esc_html($template[1]); ?><i class="fas fa-times calumma-close"></i></h5>
						<div class="calumma-masonry-item-dropdown-list">
							<?php 
							if (is_user_logged_in()) { 
								$user_fav = get_user_meta(get_current_user_id(), 'palleon_template_fav',true);
								if (empty($user_fav)) {
									$user_fav = array();
								}
								$fav_class = '';
								$fav_text = esc_html__( 'Add to favorites', 'calumma' );
								$icon_class = 'far';
								if (in_array($template[0], $user_fav)) {
									$fav_class = 'favorited';
									$fav_text = esc_html__( 'Unfavorite', 'calumma' );
									$icon_class = $fav_class . ' fas';
								}
								echo '<div data-templateid="' . esc_attr($template[0]) . '" class="calumma-add-to-fav calumma-link ' . $fav_class . '"><i class="' . $icon_class . ' fa-star"></i> ' . $fav_text . '</div>';
							}
							$slug =  PalleonSettings::get_option('be_slug', 'palleon');
							$temp_url = admin_url('admin.php?page=' . $slug . '&template_id=' . $template[0]);
							if ($fe_editor == 'enable') {
								$slug =  PalleonSettings::get_option('fe_slug', 'palleon');
								$temp_url = get_site_url() . '?page=' . $slug . '&template_id=' . $template[0];
							}
							echo '<a class="calumma-customize-link calumma-link" href="' . esc_url($temp_url) . '"><i class="fas fa-edit"></i> ' . esc_html__( 'Customize this template', 'calumma' ) . '</a>';
							echo '<div class="calumma-preview-link spotlight calumma-link" data-button="' . esc_attr__( 'Customize this template', 'calumma' ) . '" data-button-href="' . esc_url($temp_url) . '" data-href="' . esc_url($template[6]) . '" data-title="' . esc_attr($template[1]) . '"><i class="fas fa-search-plus"></i> ' . esc_html__( 'Preview this template', 'calumma' ) . '</div>';
							?>
						</div>
					</div>
					<img src="<?php echo esc_url($item_img); ?>" alt="<?php echo esc_attr($template[1]); ?>" />
				</div>
			</div><?php
            }
        }
        wp_die();
    }

    /**
	 * Pexels Search
	 */
    public function pexels_search() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'calumma-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'calumma'));
        }
        // Get The Api Key
        $getApiKey =  PalleonSettings::get_option('pexels', '');
        $apiKey = trim($getApiKey);
        $error = '';
        $curlURL = '';
        $lang =  PalleonSettings::get_option('pexels_lang', 'en-US');
        $caching =  PalleonSettings::get_option('pexels_caching', 24);
        $query = $_POST['keyword'];
        $orientation = $_POST['orientation'];
        $color = $_POST['color'];
        $page = intval($_POST['page']);
        $pagination = intval($_POST['max']);
        $thumbSize = $_POST['thumb'];

        if (empty($query) && empty($orientation) && empty($color)) {
            $curlURL = "https://api.pexels.com/v1/curated?locale=" . $lang . "&page=" . $page . "&per_page=" . $pagination;
        } else {
            $curlURL = "https://api.pexels.com/v1/search?";
            $curlURL .= 'locale=' . $lang . '&';
            if (!empty($query)) {
                $query = str_replace(' ', '%20', $query);
                $curlURL .= 'query=' . $query . '&';
            }
            if (!empty($orientation)) {
                $curlURL .= 'orientation=' . $orientation . '&';
            }
            if (!empty($color)) {
                $curlURL .= 'color=' . $color . '&';
            }
            $curlURL .= 'page=' . $page . '&per_page=' . $pagination;
        }

        $transient_value = get_transient($curlURL);

        if (false !== $transient_value){
            $response =	get_transient($curlURL);
        } else {
            $ch = curl_init();
            curl_setopt_array($ch, array(
                CURLOPT_URL => $curlURL,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 20,
                CURLOPT_HTTPHEADER => array(
                    "Authorization: {$apiKey}"
                )
            ));
        
            $response = curl_exec($ch);
            if (curl_errno($ch) > 0) { 
                $error = esc_html__( 'Error connecting to API: ', 'calumma' ) . curl_error($ch);
            }
        
            $responseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if ($responseCode === 429) {
                $error = esc_html__( 'Too many requests!', 'calumma' );
            }
            if ($responseCode !== 200) {
                $error = "HTTP {$responseCode}";
            }
            if (empty($error)) {
                set_transient( $curlURL, $response,$caching * HOUR_IN_SECONDS );
            }
        }

        $data = json_decode($response);
        if ($data === false && json_last_error() !== JSON_ERROR_NONE) {
            $error = esc_html__( 'Error parsing response', 'calumma' );
        }

        if (!empty($error)) {
            wp_die($error);
        } else {
            $photos = $data->photos;
            if ($photos == array()) {
                echo '';
            } else {
                foreach ( $photos as $photo ) {
                    $url = $photo->url;
                    $src = $photo->src;
                    $thumb = $src->$thumbSize;
                    $full = $src->original;
                    $alt = $photo->alt;
                    $check_alt = '';
                    if (empty($alt)) {
                        $check_alt = 'no-border';
                    }
                    ?><div class="calumma-masonry-item">
                        <div class="calumma-masonry-item-inner">
                            <div class="calumma-img-loader"><div></div></div>
                            <div class="calumma-masonry-item-icon calumma-masonry-item-menu"><i class="fas fa-ellipsis-h"></i></div>
                            <div class="calumma-masonry-item-dropdown">
                                <?php if (!empty($alt)) { ?>
                                <h5><?php echo esc_html($alt); ?><i class="fas fa-times calumma-close"></i></h5>
                                <?php } ?>
                                <div class="calumma-masonry-item-dropdown-list">
                                    <?php
                                    $slug =  PalleonSettings::get_option('be_slug', 'palleon');
                                    $temp_url = admin_url('admin.php?page=' . $slug . '&url=' . $full);
                                    if ($fe_editor == 'enable') {
                                        $slug =  PalleonSettings::get_option('fe_slug', 'palleon');
                                        $temp_url = get_site_url() . '?page=' . $slug . '&url=' . $full;
                                    }
                                    echo '<a class="calumma-customize-link calumma-link ' . $check_alt . '" href="' . esc_url($temp_url) . '"><i class="fas fa-edit"></i> ' . esc_html__( 'Customize this image', 'calumma' ) . '</a>';
                                    echo '<div class="calumma-preview-link spotlight calumma-link" data-button="' . esc_attr__( 'Customize this image', 'calumma' ) . '" data-button-href="' . esc_url($temp_url) . '" data-href="' . esc_url($full) . '" data-title="' . esc_attr($alt) . '"><i class="fas fa-search-plus"></i> ' . esc_html__( 'Preview this image', 'calumma' ) . '</div>';
                                    echo '<a class="calumma-pexels-link calumma-link" href="' . esc_url($url) . '" target="_blank"><i class="fas fa-link"></i> ' . esc_html__( 'View On Pexels', 'calumma' ) . '</a>';
                                    ?>
                                </div>
                            </div>
                            <img src="<?php echo esc_url($thumb); ?>" alt="<?php echo esc_attr($alt); ?>" />
                        </div>
                    </div><?php
                }
            }
        }
        wp_die();
    }

    /**
	 * Pixabay Search
	 */
    public function pixabay_search() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'calumma-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'calumma'));
        }
        // Get The Api Key
        $getApiKey =  PalleonSettings::get_option('pixabay', '');
        $apiKey = trim($getApiKey);
        $error = '';
        $curlURL = '';
        $lang =  PalleonSettings::get_option('pixabay_lang', 'en-US');
        $caching =  PalleonSettings::get_option('pixabay_caching', 24);
        $safe =  PalleonSettings::get_option('pixabay_safe', 'disable');
        $editors_choice =  PalleonSettings::get_option('pixabay_editors_choice', 'disable');
        if ($safe == 'disable') {
            $safe = 'false';
        } else {
            $safe = 'true';
        }
        if ($editors_choice == 'disable') {
            $editors_choice = 'false';
        } else {
            $editors_choice = 'true';
        }
        $query = $_POST['keyword'];
        $orientation = $_POST['orientation'];
        $category = $_POST['category'];
        $color = $_POST['color'];
        $page = intval($_POST['page']);
        $pagination = intval($_POST['max']);
        $thumbSize = $_POST['thumb'];

        if (empty($query) && empty($orientation) && empty($color) && empty($category)) {
            $curlURL = "https://pixabay.com/api/?key=". $apiKey . "&editors_choice=true&order=latest&image_type=photo&lang=" . $lang . "&safesearch=" . $safe . "&page=" . $page . "&per_page=" . $pagination;
        } else {
            $curlURL = "https://pixabay.com/api/?";
            $curlURL .= 'key=' . $apiKey . '&image_type=photo&order=latest&lang=' . $lang . '&safesearch=' . $safe . '&editors_choice=' . $editors_choice . '&';
            if (!empty($query)) {
                $query = str_replace(' ', '+', $query);
                $curlURL .= 'q=' . $query . '&';
            }
            if (!empty($orientation)) {
                $curlURL .= 'orientation=' . $orientation . '&';
            }
            if (!empty($color)) {
                $curlURL .= 'colors=' . $color . '&';
            }
            if (!empty($category)) {
                $curlURL .= 'category=' . $category . '&';
            }
            $curlURL .= 'page=' . $page . '&per_page=' . $pagination;
        }

        $transient_value = get_transient($curlURL);

        if (false !== $transient_value){
            $response =	get_transient($curlURL);
        } else {
            $ch = curl_init();
            curl_setopt_array($ch, array(
                CURLOPT_URL => $curlURL,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 20
            ));
        
            $response = curl_exec($ch);
            if (curl_errno($ch) > 0) { 
                $error = esc_html__( 'Error connecting to API: ', 'calumma' ) . curl_error($ch);
            }
        
            $responseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if ($responseCode !== 200) {
                $error = "HTTP {$responseCode}";
            }
            if ($responseCode === 429) {
                $error = esc_html__( 'Too many requests!', 'calumma' );
            }
            if ($responseCode === 400) {
                $error = esc_html__( 'Invalid or missing API key.', 'calumma' );
            } 
            if (empty($error)) {
                set_transient( $curlURL, $response,$caching * HOUR_IN_SECONDS );
            }
        }

        $data = json_decode($response);
        if ($data === false && json_last_error() !== JSON_ERROR_NONE) {
            $error = esc_html__( 'Error parsing response', 'calumma' );
        }

        if (!empty($error)) {
            wp_die($error);
        } else {
            $photos = $data->hits;
            if ($photos == array()) {
                echo '';
            } else {
                foreach ( $photos as $photo ) {
                    $url = $photo->pageURL;
                    $thumb = $photo->$thumbSize;
                    $full = $photo->largeImageURL;
                    if (isset($photo->fullHDURL)) {
                        $full = $photo->fullHDURL;
                    }
                    $alt = $photo->tags;
                    $check_alt = '';
                    if (empty($alt)) {
                        $check_alt = 'no-border';
                    }
                    ?><div class="calumma-masonry-item">
                        <div class="calumma-masonry-item-inner">
                            <div class="calumma-img-loader"><div></div></div>
                            <div class="calumma-masonry-item-icon calumma-masonry-item-menu"><i class="fas fa-ellipsis-h"></i></div>
                            <div class="calumma-masonry-item-dropdown">
                                <?php if (!empty($alt)) { ?>
                                <h5><?php echo esc_html($alt); ?><i class="fas fa-times calumma-close"></i></h5>
                                <?php } ?>
                                <div class="calumma-masonry-item-dropdown-list">
                                    <?php
                                    $slug =  PalleonSettings::get_option('be_slug', 'palleon');
                                    $temp_url = admin_url('admin.php?page=' . $slug . '&url=' . $full);
                                    if ($fe_editor == 'enable') {
                                        $slug =  PalleonSettings::get_option('fe_slug', 'palleon');
                                        $temp_url = get_site_url() . '?page=' . $slug . '&url=' . $full;
                                    }
                                    echo '<a class="calumma-customize-link calumma-link ' . $check_alt . '" href="' . esc_url($temp_url) . '"><i class="fas fa-edit"></i> ' . esc_html__( 'Customize this image', 'calumma' ) . '</a>';
                                    echo '<div class="calumma-preview-link spotlight calumma-link" data-button="' . esc_attr__( 'Customize this image', 'calumma' ) . '" data-button-href="' . esc_url($temp_url) . '" data-href="' . esc_url($full) . '" data-title="' . esc_attr($alt) . '"><i class="fas fa-search-plus"></i> ' . esc_html__( 'Preview this image', 'calumma' ) . '</div>';
                                    echo '<a class="calumma-pixabay-link calumma-link" href="' . esc_url($url) . '" target="_blank"><i class="fas fa-link"></i> ' . esc_html__( 'View On Pixabay', 'calumma' ) . '</a>';
                                    ?>
                                </div>
                            </div>
                            <img src="<?php echo esc_url($thumb); ?>" alt="<?php echo esc_attr($alt); ?>" />
                        </div>
                    </div><?php
                }
            }
        }
        wp_die();
    }
}

/**
 * Returns the main instance of the class
 */
function Calumma() {  
	return Calumma::instance();
}
// Global for backwards compatibility
$GLOBALS['Calumma'] = Calumma();    