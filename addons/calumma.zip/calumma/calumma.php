<?php
/**
 * Plugin Name: Calumma
 * Plugin URI: https://palleon.website/calumma/
 * Description: Elementor Widgets For Palleon WordPress Image Editor
 * Version: 2.0
 * Requires PHP: 7.0
 * Author: Palleon Team
 * Author URI: https://palleon.website/
 * Text Domain: calumma
 * Domain Path: /languages
 *
 */

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'CALUMMA_PLUGIN_URL' ) ) {
	define( 'CALUMMA_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

if ( ! defined( 'CALUMMA_PLUGIN_PATH' ) ) {
	define( 'CALUMMA_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'CALUMMA_VERSION' ) ) {
	define( 'CALUMMA_VERSION', '2.0');
}

if ( ! defined( 'CALUMMA_PALLEON_VERSION' ) ) {
	define( 'CALUMMA_PALLEON_VERSION', '4.0');
}

/* Admin notices */
function calumma_requires_palleon(){
    echo '<div class="notice notice-error"><p>' . esc_html__( 'Calumma requires Palleon to be installed.', 'calumma' ) . ' <a href="https://palleon.website" target="_blank">' . esc_html__( 'Buy now!', 'calumma' ) . '</a></p></div>';
}

function calumma_requires_palleon_version(){
    echo '<div class="notice notice-warning"><p>' . esc_html__( 'Calumma requires Palleon version', 'calumma' ) . ' ' . CALUMMA_PALLEON_VERSION . ' ' . esc_html__( 'or greater. You can download the latest version from your Codecanyon account.', 'calumma' ) . '</p></div>';
}

function calumma_requires_elementor(){
    echo '<div class="notice notice-error"><p>' . esc_html__( 'Calumma requires Elementor to be installed.', 'calumma' ) . ' <a href="https://wordpress.org/plugins/elementor/" target="_blank">' . esc_html__( 'Download now!', 'calumma' ) . '</a></p></div>';
}

function calumma_pro_only(){
    echo '<div class="notice notice-error"><p>' . esc_html__( 'Calumma requires Pro Plan to be purchased.', 'calumma' ) . ' <a href="https://palleon.website" target="_blank">' . esc_html__( 'Buy now!', 'antimena' ) . '</a></p></div>';
}

/* Init */
function calumma_plugins_loaded() {
    if ( !defined( 'PALLEON_PLUGIN_URL' ) || !function_exists( 'palleon_fs' )  ) {
        add_action('admin_notices', 'calumma_requires_palleon');
        return;
    } 
    if ( ! did_action( 'elementor/loaded' ) ) {
        add_action('admin_notices', 'calumma_requires_elementor');
        return;
    } 
    if ( !defined( 'PALLEON_VERSION' )  ) {
        add_action('admin_notices', 'calumma_requires_palleon_version');
        return;
    } else {
        if ( !version_compare( PALLEON_VERSION, CALUMMA_PALLEON_VERSION, '>=' ) ) {
            add_action('admin_notices', 'calumma_requires_palleon_version');
            return;
        }
    }
    if ( palleon_fs()->is_plan('pro', true) ) {
        // If everything is OK, include required files
        require_once('mainClass.php');
        require_once('loadElementor.php');
    } else {
        add_action('admin_notices', 'calumma_pro_only');
        return;
    }
}
add_action('plugins_loaded', 'calumma_plugins_loaded', 11);