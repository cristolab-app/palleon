<?php
namespace ElementorCalumma\Widgets;
use PalleonSettings;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if ( ! defined( 'ABSPATH' ) ) exit;

class Calumma_Ajax_Grid extends Widget_Base {

	public function get_name() {
		return 'calumma-ajax-grid';
	}

	public function get_title() {
		return esc_html__( 'Ajax Grid', 'calumma' );
	}

	public function get_icon() {
		return 'eicon-gallery-masonry';
	}

	public function get_categories() {
		return [ 'calumma-widgets' ];
	}

    public function get_style_depends() {
		return [ 'elementor-icons-fa-solid', 'elementor-icons-fa-regular', 'elementor-icons-fa-brands', 'calumma-style', 'spotlight'];
	}
    
    public function get_script_depends() {
		return [ 'imagesloaded', 'masonry', 'calumma-ajax-grid', 'spotlight'];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'settings_section',
			[
				'label' => esc_html__( 'Settings', 'calumma' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'search_box', [
				'label' => esc_html__( 'Search Box', 'calumma' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'ON', 'calumma' ),
				'label_off' => esc_html__( 'OFF', 'calumma' ),
				'return_value' => 'on',
				'default' => 'on',
				'show_label' => true,
			]
		);
		$default_template_tag = array('all' => esc_html__('All Tags', 'calumma') . ' (' . palleon_get_template_count() . ')');
		$original_tags = palleon_get_template_tags();
		$template_tags = array_merge($default_template_tag, $original_tags);

		$this->add_control(
			'default_tag',
			[
				'label' => esc_html__( 'Default Tag', 'calumma' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'all',
				'options' => $template_tags
			]
		);

		$this->add_responsive_control(
			'column_width',
			[
				'label' => esc_html__( 'Columns', 'calumma' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '33.3333%',
				'options' => [
					'100%' => esc_html__( '1 Column', 'calumma' ),
					'50%'  => esc_html__( '2 Column', 'calumma' ),
					'33.3333%' => esc_html__( '3 Column', 'calumma' ),
					'25%' => esc_html__( '4 Column', 'calumma' ),
					'20%' => esc_html__( '5 Column', 'calumma' ),
					'16.6666%' => esc_html__( '6 Column', 'calumma' ),
					'14.2857%' => esc_html__( '7 Column', 'calumma' ),
					'12.5%'  => esc_html__( '8 Column', 'calumma' ),
					'11.11%' => esc_html__( '9 Column', 'calumma' ),
					'10%' => esc_html__( '10 Column', 'calumma' ),
					'9.0909%' => esc_html__( '11 Column', 'calumma' ),
					'8.3333%' => esc_html__( '12 Column', 'calumma' ),
				],
				'selectors' => [
					'{{WRAPPER}} .calumma-grid-sizer, {{WRAPPER}} .calumma-masonry-item' => 'width: {{VALUE}};',
				],
				'render_type' => 'template'
			]
		);

		$this->add_control(
			'max',
			[
				'label' => esc_html__( 'Max. Items', 'calumma' ),
				'description' => esc_html__( 'Maximum number of templates to show.', 'calumma' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 100,
				'step' => 1,
				'default' => 12
			]
		);

		$this->add_responsive_control(
			'item_h_spacing',
			[
				'label' => esc_html__( 'Horizontal Item Spacing (2x)', 'calumma' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 100,
				'step' => 1,
				'default' => 10,
				'selectors' => [
					'{{WRAPPER}} .calumma-grid' => 'margin: 0 -{{VALUE}}px;',
					'{{WRAPPER}} .calumma-masonry-item' => 'padding: 0 {{VALUE}}px;',
				],
				'render_type' => 'template'
			]
		);

		$this->add_responsive_control(
			'item_v_spacing',
			[
				'label' => esc_html__( 'Vertical Item Spacing', 'calumma' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 100,
				'step' => 1,
				'default' => 20,
				'selectors' => [
					'{{WRAPPER}} .calumma-masonry-item' => 'margin-bottom: {{VALUE}}px;',
				],
				'render_type' => 'template'
			]
		);

		$this->add_control(
			'image_size',
			[
				'label' => esc_html__( 'Image Size', 'calumma' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'full',
				'options' => [
					'full' => esc_html__( 'Full Size', 'calumma' ),
					'thumbnail'  => esc_html__( 'Square Thumbnail', 'calumma' ),
				]
			]
		);

		$this->add_control(
			'load_more', [
				'label' => esc_html__( 'Load More Button', 'calumma' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'ON', 'calumma' ),
				'label_off' => esc_html__( 'OFF', 'calumma' ),
				'return_value' => 'on',
				'default' => 'on',
				'show_label' => true
			]
		);

        $this->end_controls_section();  

		$this->start_controls_section(
			'section_search_box',
			[
				'label' => esc_html__( 'Search Container', 'calumma' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'search_box_align',
			[
				'label' => esc_html__( 'Horizontal Align', 'calumma' ),
				'description' => esc_html__( 'Maximum width must be smaller than 100%.', 'calumma' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'flex-start' => [
						'title' => esc_html__( 'Start', 'calumma' ),
						'icon' => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'calumma' ),
						'icon' => 'eicon-h-align-center',
					],
					'flex-end' => [
						'title' => esc_html__( 'End', 'calumma' ),
						'icon' => 'eicon-h-align-right',
					],
				],
				'default' => 'flex-start',
				'selectors' => [
					'{{WRAPPER}} .calumma-search' => 'justify-content: {{VALUE}};',
				],
                'toggle' => false
			]
		);

		$this->add_responsive_control(
			'search_box_direction',
			[
				'label' => esc_html__( 'Direction', 'calumma' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'row' => [
						'title' => esc_html__( 'Row - Horizontal', 'calumma' ),
						'icon' => 'eicon-arrow-right',
					],
					'column' => [
						'title' => esc_html__( 'Column - Vertical', 'calumma' ),
						'icon' => 'eicon-arrow-down',
					],
					'row-reverse' => [
						'title' => esc_html__( 'Row - Reversed', 'calumma' ),
						'icon' => 'eicon-arrow-left',
					],
					'column-reverse' => [
						'title' => esc_html__( 'Column - Reversed', 'calumma' ),
						'icon' => 'eicon-arrow-left',
					],
				],
				'default' => 'row',
				'selectors' => [
					'{{WRAPPER}} .calumma-search-inner' => 'flex-direction: {{VALUE}};',
				],
                'toggle' => false
			]
		);

		$this->add_responsive_control(
			'search_box_width',
			[
				'label' => esc_html__( 'Maximum Width', 'calumma' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['%', 'px'],
				'range' => [
					'%' => [
						'min' => 0,
						'max' => 100,
					],
                    'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .calumma-search-inner' => 'max-width: {{SIZE}}{{UNIT}};'
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'search_box_bg',
				'label' => esc_html__( 'Background', 'calumma' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .calumma-search-inner',
			]
        );

		$this->add_control(
			'search_box_hr_1',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'search_box_border',
				'label' => esc_html__( 'Border', 'calumma' ),
				'selector' => '{{WRAPPER}} .calumma-search-inner',
			]
		);
        
        $this->add_responsive_control(
			'search_box_radius',
			[
				'label' => esc_html__( 'Border Radius', 'calumma' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .calumma-search-inner' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'search_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'calumma' ),
				'selector' => '{{WRAPPER}} .calumma-search-inner',
			]
        );

        $this->add_control(
			'search_box_hr_2',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_responsive_control(
			'search_box_padding',
			[
				'label' => esc_html__( 'Padding', 'calumma' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .calumma-search-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->add_responsive_control(
			'search_box_margin',
			[
				'label' => esc_html__( 'Margin', 'calumma' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .calumma-search' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
        );

		$this->end_controls_section();  

		$this->start_controls_section(
			'section_search_input',
			[
				'label' => esc_html__( 'Search Input', 'calumma' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'search_input_typography',
				'selector' => '{{WRAPPER}} input.calumma-form-field'
			]
		);
        
        $this->add_control(
			'search_input_hr_1',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		); 
        
        $this->start_controls_tabs( 'search_input_tabs' );
        
        $this->start_controls_tab(
			'search_input_normal',
			[
				'label' => esc_html__( 'Normal', 'calumma' ),
			]
		);
        
        $this->add_control(
			'search_input_text_color',
			[
				'label' => esc_html__( 'Text Color', 'calumma' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} input.calumma-form-field' => 'color: {{VALUE}};'
				]
			]
		);
        
        $this->add_control(
			'search_input_placeholder_color',
			[
				'label' => esc_html__( 'Placeholder Color', 'calumma' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} input.calumma-form-field::placeholder' => 'color: {{VALUE}};'
				]
			]
		);

		$this->add_control(
			'search_input_clear_color',
			[
				'label' => esc_html__( 'Clear Icon Color', 'calumma' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .calumma-clear-text' => 'color: {{VALUE}};'
				]
			]
		);
        
        $this->add_control(
			'search_input_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'calumma' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} input.calumma-form-field' => 'background-color: {{VALUE}};'
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'search_input_border',
				'label' => esc_html__( 'Border', 'calumma' ),
				'selector' => '{{WRAPPER}} input.calumma-form-field'
			]
		);
        
        $this->add_responsive_control(
			'search_input_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'calumma' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} input.calumma-form-field' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};',
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'search_input_border_shadow',
				'label' => esc_html__( 'Box Shadow', 'calumma' ),
				'selector' => '{{WRAPPER}} input.calumma-form-field'
			]
		);
        
        $this->end_controls_tab();

		$this->start_controls_tab(
			'search_input_hover',
			[
				'label' => esc_html__( 'Focus', 'calumma' ),
			]
		);
        
        $this->add_control(
			'search_input_text_hover_color',
			[
				'label' => esc_html__( 'Text Color', 'calumma' ),
				'type' => Controls_Manager::COLOR, 
				'selectors' => [
					'{{WRAPPER}} input.calumma-form-field:focus' => 'color: {{VALUE}};'
				]
			]
		);
        
        $this->add_control(
			'search_input_bg_hover_color',
			[
				'label' => esc_html__( 'Background Color', 'calumma' ),
				'type' => Controls_Manager::COLOR, 
				'selectors' => [
					'{{WRAPPER}} input.calumma-form-field:focus' => 'background-color: {{VALUE}};'
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'search_input_hover_border',
				'label' => esc_html__( 'Border', 'calumma' ),
				'selector' => '{{WRAPPER}} input.calumma-form-field:focus'
			]
		);
        
        $this->add_responsive_control(
			'search_input_border_hover_radius',
			[
				'label' => esc_html__( 'Border Radius', 'calumma' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} input.calumma-form-field:focus' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};',
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'search_input_border_hover_shadow',
				'label' => esc_html__( 'Box Shadow', 'calumma' ),
				'selector' => '{{WRAPPER}} input.calumma-form-field:focus'
			]
		);
        
        $this->end_controls_tab();
        $this->end_controls_tabs();
        
        $this->add_control(
			'search_input_hr_2',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
        
        $this->add_responsive_control(
			'search_input_padding',
			[
				'label' => esc_html__( 'Padding', 'calumma' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
                    '{{WRAPPER}} input.calumma-form-field' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'search_input_margin',
			[
				'label' => esc_html__( 'Margin', 'calumma' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
                    '{{WRAPPER}} .calumma-input-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();  

		$this->start_controls_section(
			'section_tag_select',
			[
				'label' => esc_html__( 'Tag Select', 'calumma' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'tag_select_typography',
				'selector' => '{{WRAPPER}} select.calumma-select'
			]
		);
        
        $this->add_control(
			'tag_select_hr_1',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		); 
        
        $this->start_controls_tabs( 'tag_select_tabs' );
        
        $this->start_controls_tab(
			'tag_select_normal',
			[
				'label' => esc_html__( 'Normal', 'calumma' ),
			]
		);
        
        $this->add_control(
			'tag_select_text_color',
			[
				'label' => esc_html__( 'Text Color', 'calumma' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} select.calumma-select' => 'color: {{VALUE}};'
				]
			]
		);
        
        $this->add_control(
			'tag_select_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'calumma' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} select.calumma-select' => 'background-color: {{VALUE}};'
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'tag_select_border',
				'label' => esc_html__( 'Border', 'calumma' ),
				'selector' => '{{WRAPPER}} select.calumma-select'
			]
		);
        
        $this->add_responsive_control(
			'tag_select_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'calumma' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} select.calumma-select' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};',
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'tag_select_border_shadow',
				'label' => esc_html__( 'Box Shadow', 'calumma' ),
				'selector' => '{{WRAPPER}} select.calumma-select'
			]
		);
        
        $this->end_controls_tab();

		$this->start_controls_tab(
			'tag_select_hover',
			[
				'label' => esc_html__( 'Focus', 'calumma' ),
			]
		);
        
        $this->add_control(
			'tag_select_text_hover_color',
			[
				'label' => esc_html__( 'Text Color', 'calumma' ),
				'type' => Controls_Manager::COLOR, 
				'selectors' => [
					'{{WRAPPER}} select.calumma-select:focus' => 'color: {{VALUE}};'
				]
			]
		);
        
        $this->add_control(
			'tag_select_bg_hover_color',
			[
				'label' => esc_html__( 'Background Color', 'calumma' ),
				'type' => Controls_Manager::COLOR, 
				'selectors' => [
					'{{WRAPPER}} select.calumma-select:focus' => 'background-color: {{VALUE}};'
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'tag_select_hover_border',
				'label' => esc_html__( 'Border', 'calumma' ),
				'selector' => '{{WRAPPER}} select.calumma-select:focus'
			]
		);
        
        $this->add_responsive_control(
			'tag_select_hover_radius',
			[
				'label' => esc_html__( 'Border Radius', 'calumma' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} select.calumma-select:focus' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};',
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'tag_select_border_hover_shadow',
				'label' => esc_html__( 'Box Shadow', 'calumma' ),
				'selector' => '{{WRAPPER}} select.calumma-select:focus'
			]
		);
        
        $this->end_controls_tab();
        $this->end_controls_tabs();
        
        $this->add_control(
			'tag_select_hr_2',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
        
        $this->add_responsive_control(
			'tag_select_padding',
			[
				'label' => esc_html__( 'Padding', 'calumma' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
                    '{{WRAPPER}} select.calumma-select' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'tag_select_margin',
			[
				'label' => esc_html__( 'Margin', 'calumma' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
                    '{{WRAPPER}} select.calumma-select' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		 // section start
		 $this->start_controls_section(
			'section_search_btn',
			[
				'label' => esc_html__( 'Search Button', 'calumma' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'search_btn_icon_size',
			[
				'label' => esc_html__( 'Icon Size', 'calumma' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 100,
				'step' => 1,
				'default' => 16,
				'selectors' => [
					'{{WRAPPER}} button.calumma-btn' => 'font-size: {{VALUE}}px;'
				]
			]
		);
        
        $this->add_control(
			'search_btn_hr_1',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);  
        
        $this->start_controls_tabs( 'search_btn_tabs' );
        
        $this->start_controls_tab(
			'search_btn_normal',
			[
				'label' => esc_html__( 'Normal', 'calumma' ),
			]
		);
        
        $this->add_control(
			'search_btn_text_color',
			[
				'label' => esc_html__( 'Icon Color', 'calumma' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} button.calumma-btn' => 'color: {{VALUE}};',
				]
			]
		);
        
        $this->add_control(
			'search_btn_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'calumma' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} button.calumma-btn' => 'background-color: {{VALUE}};',
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'search_btn_border',
				'label' => esc_html__( 'Border', 'calumma' ),
				'selector' => '{{WRAPPER}} button.calumma-btn'
			]
		);
        
        $this->add_responsive_control(
			'search_btn_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'calumma' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} button.calumma-btn' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};'
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'search_btn_border_shadow',
				'label' => esc_html__( 'Box Shadow', 'calumma' ),
				'selector' => '{{WRAPPER}} button.calumma-btn'
			]
		);
        
        $this->end_controls_tab();

		$this->start_controls_tab(
			'search_btn_button_hover',
			[
				'label' => esc_html__( 'Hover', 'calumma' ),
			]
		);
        
        $this->add_control(
			'search_btn_text_hover_color',
			[
				'label' => esc_html__( 'Text Color', 'calumma' ),
				'type' => Controls_Manager::COLOR, 
				'selectors' => [
					'{{WRAPPER}} button.calumma-btn:hover, {{WRAPPER}} button.calumma-btn:focus' => 'color: {{VALUE}};'
				]
			]
		);
        
        $this->add_control(
			'search_btn_bg_hover_color',
			[
				'label' => esc_html__( 'Background Color', 'calumma' ),
				'type' => Controls_Manager::COLOR, 
				'selectors' => [
					'{{WRAPPER}} button.calumma-btn:hover, {{WRAPPER}} button.calumma-btn:focus' => 'background-color: {{VALUE}};'
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'search_btn_hover_border',
				'label' => esc_html__( 'Border', 'calumma' ),
				'selector' => '{{WRAPPER}} button.calumma-btn:hover, {{WRAPPER}} button.calumma-btn:focus'
			]
		);
        
        $this->add_responsive_control(
			'search_btn_border_hover_radius',
			[
				'label' => esc_html__( 'Border Radius', 'calumma' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} button.calumma-btn:hover' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} button.calumma-btn:focus' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};'
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'search_btn_border_hover_shadow',
				'label' => esc_html__( 'Box Shadow', 'calumma' ),
				'selector' => '{{WRAPPER}} button.calumma-btn:hover, {{WRAPPER}} button.calumma-btn:focus'
			]
		);
        
        $this->end_controls_tab();
        $this->end_controls_tabs();
        
        $this->add_control(
			'search_btn_hr_2',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		); 
        
        $this->add_responsive_control(
			'search_btn_padding',
			[
				'label' => esc_html__( 'Padding', 'calumma' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
                    '{{WRAPPER}} button.calumma-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);

		$this->add_responsive_control(
			'search_btn_margin',
			[
				'label' => esc_html__( 'Margin', 'calumma' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
                    '{{WRAPPER}} button.calumma-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);

		$this->end_controls_section();  

		$this->start_controls_section(
			'section_info_msg',
			[
				'label' => esc_html__( 'Info Message', 'calumma' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'info_msg_typography',
				'selector' => '{{WRAPPER}} .calumma-notice'
			]
		);

		$this->add_control(
			'info_msg_text_color',
			[
				'label' => esc_html__( 'Text Color', 'calumma' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .calumma-notice' => 'color: {{VALUE}};',
				]
			]
		);

		$this->add_control(
			'info_msg_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'calumma' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .calumma-notice' => 'background-color: {{VALUE}};',
				]
			]
		);

		$this->add_control(
			'info_msg_hr_1',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
        
        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'info_msg_border',
				'label' => esc_html__( 'Border', 'calumma' ),
				'selector' => '{{WRAPPER}} .calumma-notice'
			]
		);
        
        $this->add_responsive_control(
			'info_msg_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'calumma' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .calumma-notice' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};'
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'info_msg_border_shadow',
				'label' => esc_html__( 'Box Shadow', 'calumma' ),
				'selector' => '{{WRAPPER}} .calumma-notice'
			]
		);

		$this->add_control(
			'info_msg_hr_2',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_responsive_control(
			'info_msg_padding',
			[
				'label' => esc_html__( 'Padding', 'calumma' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
                    '{{WRAPPER}} .calumma-notice' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);

		$this->add_responsive_control(
			'info_msg_margin',
			[
				'label' => esc_html__( 'Margin', 'calumma' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
                    '{{WRAPPER}} .calumma-notice' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);

		$this->end_controls_section();  

		$this->start_controls_section(
			'section_item_container',
			[
				'label' => esc_html__( 'Template Container', 'calumma' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'item_container_bg',
				'label' => esc_html__( 'Background', 'calumma' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .calumma-masonry-item-inner',
			]
        );

		$this->add_control(
			'item_container_hr_1',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'item_container_border',
				'label' => esc_html__( 'Border', 'calumma' ),
				'selector' => '{{WRAPPER}} .calumma-masonry-item-inner img',
			]
		);
        
        $this->add_responsive_control(
			'item_container_radius',
			[
				'label' => esc_html__( 'Border Radius', 'calumma' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .calumma-masonry-item-inner' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .calumma-masonry-item-inner img' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'item_container_shadow',
				'label' => esc_html__( 'Box Shadow', 'calumma' ),
				'selector' => '{{WRAPPER}} .calumma-masonry-item-inner img',
			]
        );

        $this->add_control(
			'item_container_hr_2',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_responsive_control(
			'item_container_padding',
			[
				'label' => esc_html__( 'Padding', 'calumma' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .calumma-masonry-item-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);

		$this->end_controls_section();  
		
		$this->start_controls_section(
			'section_item_btns',
			[
				'label' => esc_html__( 'Template Buttons', 'calumma' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'item_btns_menu_size',
			[
				'label' => esc_html__( 'Icon Size', 'calumma' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'calumma-default-icon',
				'options' => [
					'calumma-default-icon' => esc_html__( 'Default', 'calumma' ),
					'calumma-small-icon'  => esc_html__( 'Small', 'calumma' )
				]
			]
		);

		$this->add_control(
			'item_btns_menu_color',
			[
				'label' => esc_html__( 'Menu Icon Color', 'calumma' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .calumma-masonry-item-menu' => 'color: {{VALUE}};',
				]
			]
		);

		$this->add_control(
			'item_btns_menu_bg',
			[
				'label' => esc_html__( 'Menu Icon Background', 'calumma' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .calumma-masonry-item-menu' => 'background-color: {{VALUE}};',
				]
			]
		);

		$this->add_control(
			'item_btns_pro_color',
			[
				'label' => esc_html__( 'PRO Icon Color', 'calumma' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .calumma-masonry-item-icon.calumma-masonry-item-version' => 'color: {{VALUE}};',
				]
			]
		);

		$this->add_control(
			'item_btns_pro_bg',
			[
				'label' => esc_html__( 'PRO Background', 'calumma' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .calumma-masonry-item-icon.calumma-masonry-item-version' => 'background-color: {{VALUE}};',
				]
			]
		);

		$this->add_control(
			'item_btns_hr_1',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'item_btns_border',
				'label' => esc_html__( 'Border', 'calumma' ),
				'selector' => '{{WRAPPER}} .calumma-masonry-item-icon',
			]
		);
        
        $this->add_responsive_control(
			'item_btns_radius',
			[
				'label' => esc_html__( 'Border Radius', 'calumma' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .calumma-masonry-item-icon' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};'
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'item_btns_shadow',
				'label' => esc_html__( 'Box Shadow', 'calumma' ),
				'selector' => '{{WRAPPER}} .calumma-masonry-item-icon',
			]
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'section_item_menu',
			[
				'label' => esc_html__( 'Template Menu', 'calumma' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'item_menu_width',
			[
				'label' => esc_html__( 'Menu Width', 'calumma' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
                    'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 240,
				],
				'selectors' => [
					'{{WRAPPER}} .calumma-masonry-item-dropdown' => 'width: {{SIZE}}{{UNIT}};'
				],
			]
		);

		$this->add_control(
			'item_menu_background',
			[
				'label' => esc_html__( 'Menu Background', 'calumma' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .calumma-masonry-item-dropdown' => 'background: {{VALUE}};'
				]
			]
		);

		$this->add_control(
			'item_menu_hr_1',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Title Typography', 'calumma' ),
				'name' => 'item_menu_title_typography',
				'selector' => '{{WRAPPER}} .calumma-masonry-item-dropdown h5'
			]
		);

		$this->add_control(
			'item_menu_title_color',
			[
				'label' => esc_html__( 'Title Color', 'calumma' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .calumma-masonry-item-dropdown h5' => 'color: {{VALUE}};'
				]
			]
		);

		$this->add_responsive_control(
			'item_menu_title_padding',
			[
				'label' => esc_html__( 'Title Padding', 'calumma' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .calumma-masonry-item-dropdown h5' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);

		$this->add_control(
			'item_menu_hr_2',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Link Typography', 'calumma' ),
				'name' => 'item_menu_link_typography',
				'selector' => '{{WRAPPER}} .calumma-masonry-item-dropdown .calumma-link'
			]
		);

		$this->add_responsive_control(
			'item_menu_link_padding',
			[
				'label' => esc_html__( 'Link Padding', 'calumma' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .calumma-masonry-item-dropdown .calumma-link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);

		$this->start_controls_tabs( 'item_menu_tabs' );
        
        $this->start_controls_tab(
			'item_menu_normal',
			[
				'label' => esc_html__( 'Normal', 'calumma' ),
			]
		);
        
        $this->add_control(
			'item_menu_text_color',
			[
				'label' => esc_html__( 'Link Color', 'calumma' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .calumma-masonry-item-dropdown .calumma-link' => 'color: {{VALUE}};'
				]
			]
		);
        
        $this->add_control(
			'item_menu_bg_color',
			[
				'label' => esc_html__( 'Link Background', 'calumma' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .calumma-masonry-item-dropdown .calumma-link' => 'background-color: {{VALUE}};'
				]
			]
		);

		$this->add_control(
			'item_menu_link_border_color',
			[
				'label' => esc_html__( 'Link Border Color', 'calumma' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .calumma-masonry-item-dropdown .calumma-link' => 'border-color: {{VALUE}};'
				]
			]
		);
        
        $this->end_controls_tab();

		$this->start_controls_tab(
			'item_menu_hover',
			[
				'label' => esc_html__( 'Hover', 'calumma' ),
			]
		);
        
        $this->add_control(
			'item_menu_text_hover_color',
			[
				'label' => esc_html__( 'Link Color', 'calumma' ),
				'type' => Controls_Manager::COLOR, 
				'selectors' => [
					'{{WRAPPER}} .calumma-masonry-item-dropdown .calumma-link:hover' => 'color: {{VALUE}};'
				]
			]
		);
        
        $this->add_control(
			'item_menu_bg_hover_color',
			[
				'label' => esc_html__( 'Link Background', 'calumma' ),
				'type' => Controls_Manager::COLOR, 
				'selectors' => [
					'{{WRAPPER}} .calumma-masonry-item-dropdown .calumma-link:hover' => 'background-color: {{VALUE}};'
				]
			]
		);

		$this->add_control(
			'item_menu_link_border_hover_color',
			[
				'label' => esc_html__( 'Link Border Color', 'calumma' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .calumma-masonry-item-dropdown .calumma-link:hover' => 'border-color: {{VALUE}};'
				]
			]
		);
        
        $this->end_controls_tab();
        $this->end_controls_tabs();

		$this->add_control(
			'item_menu_hr_3',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'item_menu_border',
				'label' => esc_html__( 'Border', 'calumma' ),
				'selector' => '{{WRAPPER}} .calumma-masonry-item-dropdown',
			]
		);
        
        $this->add_responsive_control(
			'item_menu_radius',
			[
				'label' => esc_html__( 'Border Radius', 'calumma' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .calumma-masonry-item-dropdown' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .calumma-masonry-item-dropdown .calumma-link:last-child' => 'border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};'
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'item_menu_shadow',
				'label' => esc_html__( 'Box Shadow', 'calumma' ),
				'selector' => '{{WRAPPER}} .calumma-masonry-item-dropdown',
			]
        );

		$this->add_control(
			'mobile_menu', [
				'label' => esc_html__( 'Mobile Menu', 'calumma' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'ON', 'calumma' ),
				'label_off' => esc_html__( 'OFF', 'calumma' ),
				'return_value' => 'mobile-on',
				'default' => 'mobile-on',
				'show_label' => true,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_item_loader',
			[
				'label' => esc_html__( 'Template Loader', 'calumma' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'section_item_loader_size',
			[
				'label' => esc_html__( 'Loader Size', 'calumma' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 200,
				'step' => 1,
				'default' => 30,
				'selectors' => [
					'{{WRAPPER}} .calumma-img-loader > div' => 'width: {{VALUE}}px;height: {{VALUE}}px;'
				]
			]
		);

		$this->add_control(
			'section_item_loader_width',
			[
				'label' => esc_html__( 'Loader Border Width', 'calumma' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 200,
				'step' => 1,
				'default' => 3,
				'selectors' => [
					'{{WRAPPER}} .calumma-img-loader > div' => 'border-width: {{VALUE}}px;'
				]
			]
		);

		$this->add_control(
			'section_item_loader_hr_1',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'section_item_loading_bg',
				'label' => esc_html__( 'Background', 'calumma' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .calumma-img-loader',
			]
        );

		$this->add_control(
			'section_item_loader_color',
			[
				'label' => esc_html__( 'Loader Color', 'calumma' ),
				'type' => Controls_Manager::COLOR, 
				'selectors' => [
					'{{WRAPPER}} .calumma-img-loader > div' => 'border-top-color: {{VALUE}};'
				]
			]
		);

		$this->add_control(
			'section_item_loader_bg',
			[
				'label' => esc_html__( 'Loader Background', 'calumma' ),
				'type' => Controls_Manager::COLOR, 
				'selectors' => [
					'{{WRAPPER}} .calumma-img-loader > div' => 'border-bottom-color: {{VALUE}};border-left-color: {{VALUE}};border-right-color: {{VALUE}};'
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_load_more',
			[
				'label' => esc_html__( 'Load More Button', 'calumma' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'load_more_typography',
				'selector' => '{{WRAPPER}} button.calumma-load-more'
			]
		);
        
        $this->add_control(
			'load_more_hr_1',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		); 

		$this->start_controls_tabs( 'load_more_tabs' );
        
        $this->start_controls_tab(
			'load_more_normal',
			[
				'label' => esc_html__( 'Normal', 'calumma' ),
			]
		);
        
        $this->add_control(
			'load_more_text_color',
			[
				'label' => esc_html__( 'Text Color', 'calumma' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} button.calumma-load-more' => 'color: {{VALUE}};',
				]
			]
		);
        
        $this->add_control(
			'load_more_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'calumma' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} button.calumma-load-more' => 'background-color: {{VALUE}};',
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'load_more_border',
				'label' => esc_html__( 'Border', 'calumma' ),
				'selector' => '{{WRAPPER}} button.calumma-load-more'
			]
		);
        
        $this->add_responsive_control(
			'load_more_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'calumma' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} button.calumma-load-more' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};'
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'load_more_border_shadow',
				'label' => esc_html__( 'Box Shadow', 'calumma' ),
				'selector' => '{{WRAPPER}} button.calumma-load-more'
			]
		);
        
        $this->end_controls_tab();

		$this->start_controls_tab(
			'load_more_button_hover',
			[
				'label' => esc_html__( 'Hover', 'calumma' ),
			]
		);
        
        $this->add_control(
			'load_more_text_hover_color',
			[
				'label' => esc_html__( 'Text Color', 'calumma' ),
				'type' => Controls_Manager::COLOR, 
				'selectors' => [
					'{{WRAPPER}} button.calumma-load-more:hover, {{WRAPPER}} button.calumma-load-more:focus' => 'color: {{VALUE}};'
				]
			]
		);
        
        $this->add_control(
			'load_more_bg_hover_color',
			[
				'label' => esc_html__( 'Background Color', 'calumma' ),
				'type' => Controls_Manager::COLOR, 
				'selectors' => [
					'{{WRAPPER}} button.calumma-load-more:hover, {{WRAPPER}} button.calumma-load-more:focus' => 'background-color: {{VALUE}};'
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'load_more_hover_border',
				'label' => esc_html__( 'Border', 'calumma' ),
				'selector' => '{{WRAPPER}} button.calumma-load-more:hover, {{WRAPPER}} button.calumma-load-more:focus'
			]
		);
        
        $this->add_responsive_control(
			'load_more_border_hover_radius',
			[
				'label' => esc_html__( 'Border Radius', 'calumma' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} button.calumma-load-more:hover' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} button.calumma-load-more:focus' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};'
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'load_more_border_hover_shadow',
				'label' => esc_html__( 'Box Shadow', 'calumma' ),
				'selector' => '{{WRAPPER}} button.calumma-load-more:hover, {{WRAPPER}} button.calumma-load-more:focus'
			]
		);
        
        $this->end_controls_tab();
        $this->end_controls_tabs();

		$this->add_control(
			'load_more_hr_2',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		); 

		$this->add_responsive_control(
			'load_more_padding',
			[
				'label' => esc_html__( 'Padding', 'calumma' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} button.calumma-load-more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);

		$this->add_responsive_control(
			'load_more_margin',
			[
				'label' => esc_html__( 'Margin', 'calumma' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .calumma-load-more-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);

        $this->end_controls_section();
	}
    
    protected function render() {
		$mode = 'elementor-frontend';
        if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
            $mode = 'elementor-backend';
        }
		$settings = $this->get_settings_for_display();
		$widget_id = $this->get_id();
		$default_tag = $settings['default_tag'];
		$default_icon_size = $settings['item_btns_menu_size'];
		$max_item = intval($settings['max']);
		$templates = '';
		if (!empty($default_tag) && $default_tag != 'all') {
			$templates = palleon_get_templates($default_tag);
		} else {
			$templates = palleon_get_templates(false);
		}
		$templateCount = count($templates);
		$fe_editor = PalleonSettings::get_option('fe_editor','disable');
		$disable_search = '';
			if ($settings['search_box'] != 'on') {
				$disable_search = 'disabled';
			}
		?>
		<div id="calumma-search-<?php echo esc_attr($widget_id); ?>" class="calumma-search <?php echo esc_attr($disable_search); ?>">
			<div class="calumma-search-inner">
				<div class="calumma-input-wrapper">
					<input type="text" class="calumma-form-field" placeholder="<?php echo esc_attr__( 'Search by keyword...', 'calumma' ); ?>" autocomplete="off">
					<i class="fas fa-times-circle calumma-clear-text"></i>
				</div>
				<select class="calumma-select" autocomplete="off">
					<option value="all"><?php echo esc_html__('All Tags', 'calumma') . ' (' . palleon_get_template_count() . ')'; ?></option>
					<?php 
					$getTags = palleon_get_template_tags();
					foreach($getTags as $slug => $name) {
						if ($default_tag == $slug) {
							echo '<option value="' . esc_attr($slug) . '" selected>' . esc_html($name) . '</option>';
						} else {
							echo '<option value="' . esc_attr($slug) . '">' . esc_html($name) . '</option>';
						}
					}
					?>
				</select>
				<button type="button" class="calumma-btn" data-wrap="#calumma-search-<?php echo esc_attr($widget_id); ?>" data-target="#calumma-grid-<?php echo esc_attr($widget_id); ?>"><i class="fas fa-search"></i></button>
			</div>
		</div>
		<div class="calumma-notice"><span><?php echo esc_html__( 'No results found.', 'calumma' ); ?></span></div>
		<div id="calumma-grid-<?php echo esc_attr($widget_id); ?>" class="calumma-grid spotlight-group <?php echo esc_attr($settings['mobile_menu'] . ' ' . $mode . ' ' . $default_icon_size); ?>" data-size="<?php echo esc_attr($settings['image_size']); ?>">
			<div class="calumma-grid-sizer"></div>
			<?php
			if ( ! \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
			$max = 0;
			foreach($templates as $template) {
				$item_img = $settings['image_size'];
				$template_version = 'free';
				if (isset($template[5])) {
					$template_version = $template[5]; 
				}
				if ($max >= $max_item) {
					break;
				} else {
					$max ++;
				}
				if ($item_img == 'full') {
					$item_img = $template[6];
				} else {
					$item_img = $template[2];
				}
			?>
			<div class="calumma-masonry-item">
				<div class="calumma-masonry-item-inner">
					<div class="calumma-img-loader"><div></div></div>
					<?php if ($template_version == 'pro') { ?>
                	<div class="calumma-masonry-item-icon calumma-masonry-item-version" title="<?php echo esc_attr__( 'PRO Template', 'calumma' ); ?>"><i class="fas fa-crown"></i></div>
                	<?php } ?>
					<div class="calumma-masonry-item-icon calumma-masonry-item-menu"><i class="fas fa-ellipsis-h"></i></div>
					<div class="calumma-masonry-item-dropdown">
						<h5><?php echo esc_html($template[1]); ?><i class="fas fa-times calumma-close"></i></h5>
						<div class="calumma-masonry-item-dropdown-list">
							<?php 
							if (is_user_logged_in()) { 
								$user_fav = get_user_meta(get_current_user_id(), 'palleon_template_fav',true);
								if (empty($user_fav)) {
									$user_fav = array();
								}
								$fav_class = '';
								$fav_text = esc_html__( 'Add to favorites', 'calumma' );
								$icon_class = 'far';
								if (in_array($template[0], $user_fav)) {
									$fav_class = 'favorited';
									$fav_text = esc_html__( 'Unfavorite', 'calumma' );
									$icon_class = $fav_class . ' fas';
								}
								echo '<div data-templateid="' . esc_attr($template[0]) . '" class="calumma-add-to-fav calumma-link ' . $fav_class . '"><i class="' . $icon_class . ' fa-star"></i> ' . $fav_text . '</div>';
							}
							$slug =  PalleonSettings::get_option('be_slug', 'palleon');
							$temp_url = admin_url('admin.php?page=' . $slug . '&template_id=' . $template[0]);
							if ($fe_editor == 'enable') {
								$slug =  PalleonSettings::get_option('fe_slug', 'palleon');
								$temp_url = get_site_url() . '?page=' . $slug . '&template_id=' . $template[0];
							}
							echo '<a class="calumma-customize-link calumma-link" href="' . esc_url($temp_url) . '"><i class="fas fa-edit"></i> ' . esc_html__( 'Customize this template', 'calumma' ) . '</a>';
							echo '<div class="calumma-preview-link spotlight calumma-link" data-button="' . esc_attr__( 'Customize this template', 'calumma' ) . '" data-button-href="' . esc_url($temp_url) . '" data-href="' . esc_url($template[6]) . '" data-title="' . esc_attr($template[1]) . '"><i class="fas fa-search-plus"></i> ' . esc_html__( 'Preview this template', 'calumma' ) . '</div>';
							?>
						</div>
					</div>
					<img src="<?php echo esc_url($item_img); ?>" alt="<?php echo esc_attr($template[1]); ?>" />
				</div>
			</div>
			<?php }
		} ?>
		</div>
		<?php
			$disable_load_more = '';
			if ($templateCount <= $max_item) {
				$disable_load_more = 'disabled';
			}
			$hide_load_more = '';
			if ($settings['load_more'] != 'on') {
				$hide_load_more = 'hide';
			}
		?>
		<div class="calumma-load-more-wrap">
			<button type="button" class="calumma-load-more <?php echo esc_attr($hide_load_more); ?>" data-page="2" data-max="<?php echo esc_attr($settings['max']); ?>" <?php echo esc_attr($disable_load_more); ?>><?php echo esc_html__( 'Load More', 'calumma' ); ?></button>
		</div>
		<?php
    }
}
?>