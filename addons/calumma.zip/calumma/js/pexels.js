( function( $ ) {
    "use strict";
	$( window ).on( 'elementor/frontend/init', function() {            
        elementorFrontend.hooks.addAction('frontend/element_ready/calumma-pexels.default', function($scope){
            var grid = $scope.find('.calumma-grid');
            var thumb = grid.data('size');

            // Masonry
            var masonry = grid.masonry({
                itemSelector: '.calumma-masonry-item',
                columnWidth: '.calumma-grid-sizer',
                percentPosition: true
            });
           
            // Load items
            var button = $scope.find('.pexels-submit'),
            viewmore = $scope.find('.pexels-load-more'),
            orientation = $scope.find('.pexels-orientation').val(),
            color = $scope.find('.pexels-color').val(),
            keyword = $scope.find('.pexels-keyword').val(),
            max = parseInt(viewmore.attr('data-max')),
            data = {
                'action': 'calummaPexelsSearch',
                'nonce': calumma.nonce,
                'orientation': orientation,
                'color': color,
                'keyword': keyword,
                'page': '1',
                'max': max,
                'thumb': thumb
            };
            $.ajax({
                url : calumma.ajaxurl,
                data : data,
                type : 'POST',
                beforeSend: function() {
                    button.prop('disabled', true);
                    viewmore.prop('disabled', true);
                    $scope.find('.calumma-notice').fadeOut();
                },
                success: function(data){
                    var oldItems = masonry.masonry('getItemElements');
                    masonry.masonry('remove', oldItems);
                    if(data) {
                        var items = $(data);
                        masonry.prepend(items).masonry('prepended', items);
                        if (max > items.length) {
                            viewmore.prop('disabled', true);
                        } else {
                            viewmore.prop('disabled', false);
                        }
                        grid.imagesLoaded().progress( function( instance, image ) { 
                            if (image.isLoaded) {
                                $(image.img).parent().find('.calumma-img-loader').remove();
                                masonry.masonry();
                            } 
                        });
                    } else {
                        masonry.masonry();
                        $scope.find('.calumma-notice').fadeIn();
                        viewmore.prop('disabled', true);
                    }
                },
                error: function(jqXHR,error, errorThrown) {
                    if(jqXHR.status&&jqXHR.status==400){
                        alert(jqXHR.responseText);
                    }else{
                        alert(calumma.error);
                    }
                },
                complete: function() {
                    button.prop('disabled', false);
                }
            });

            if ( grid.hasClass('elementor-frontend') ) {
                /* Pexels Search */
                $scope.find('.calumma-search').on('click','.pexels-submit',function(){
                    var button = $scope.find('.pexels-submit'),
                    viewmore = $scope.find('.pexels-load-more'),
                    orientation = $scope.find('.pexels-orientation').val(),
                    color = $scope.find('.pexels-color').val(),
                    keyword = $scope.find('.pexels-keyword').val(),
                    max = parseInt(viewmore.attr('data-max')),
                    data = {
                        'action': 'calummaPexelsSearch',
                        'nonce': calumma.nonce,
                        'orientation': orientation,
                        'color': color,
                        'keyword': keyword,
                        'page': '1',
                        'max': max,
                        'thumb': thumb
                    };
                    $.ajax({
                        url : calumma.ajaxurl,
                        data : data,
                        type : 'POST',
                        beforeSend: function() {
                            button.prop('disabled', true);
                            viewmore.prop('disabled', true);
                            $scope.find('.calumma-notice').fadeOut();
                        },
                        success: function(data){
                            var oldItems = masonry.masonry('getItemElements');
                            masonry.masonry('remove', oldItems);
                            if(data) {
                                var items = $(data);
                                masonry.prepend(items).masonry('prepended', items);
                                if (max > items.length) {
                                    viewmore.prop('disabled', true);
                                } else {
                                    viewmore.prop('disabled', false);
                                }
                                grid.imagesLoaded().progress( function( instance, image ) { 
                                    if (image.isLoaded) {
                                        $(image.img).parent().find('.calumma-img-loader').remove();
                                        masonry.masonry();
                                    } 
                                });
                            } else {
                                masonry.masonry();
                                $scope.find('.calumma-notice').fadeIn();
                                viewmore.prop('disabled', true);
                            }
                            viewmore.attr('data-page', 2);
                        },
                        error: function(jqXHR,error, errorThrown) {
                            if(jqXHR.status&&jqXHR.status==400){
                                alert(jqXHR.responseText);
                            }else{
                                alert(calumma.error);
                            }
                        },
                        complete: function() {
                            button.prop('disabled', false);
                        }
                    });
                });

                /* Load More Template */
                $scope.on('click','.pexels-load-more',function(){
                    var button = $scope.find('.pexels-submit'),
                    viewmore = $scope.find('.pexels-load-more'),
                    orientation = $scope.find('.pexels-orientation').val(),
                    color = $scope.find('.pexels-color').val(),
                    keyword = $scope.find('.pexels-keyword').val(),
                    page = parseInt(viewmore.attr('data-page')),
                    max = parseInt(viewmore.attr('data-max')),
                    data = {
                        'action': 'calummaPexelsSearch',
                        'nonce': calumma.nonce,
                        'orientation': orientation,
                        'color': color,
                        'keyword': keyword,
                        'page': page,
                        'max': max,
                        'thumb': thumb
                    };
                    $.ajax({
                        url : calumma.ajaxurl,
                        data : data,
                        type : 'POST',
                        beforeSend: function() {
                            button.prop('disabled', true);
                            viewmore.addClass('disabled');
                            $scope.find('.calumma-grid').addClass('calumma-grid-loading');
                            $scope.find('.calumma-notice').fadeOut();
                        },
                        success: function(data){
                            if(data) {
                                var items = $(data);
                                masonry.append(items).masonry('appended', items);
                                if (max > items.length) {
                                    viewmore.prop('disabled', true);
                                } else {
                                    viewmore.prop('disabled', false);
                                }
                                grid.imagesLoaded().progress( function( instance, image ) { 
                                    if (image.isLoaded) {
                                        $(image.img).parent().find('.calumma-img-loader').remove();
                                        masonry.masonry();
                                    } 
                                });
                                viewmore.attr('data-page', page + 1);
                            } else {
                                viewmore.attr('data-page', 2);
                                viewmore.prop('disabled', true);
                            }
                        },
                        error: function(jqXHR,error, errorThrown) {
                            if(jqXHR.status&&jqXHR.status==400){
                                alert(jqXHR.responseText);
                            }else{
                                alert(calumma.error);
                            }
                        },
                        complete: function() {
                            button.prop('disabled', false);
                            viewmore.removeClass('disabled');
                            $scope.find('.calumma-grid').removeClass('calumma-grid-loading');
                        }
                    });
                });

                /* Preview Template */
                $scope.find('.calumma-grid').on('click','img',function(){
                    $(this).parent().find('.calumma-preview-link').trigger('click');
                });
            }

            // Template menu
            $scope.find('.calumma-grid').on('click','.calumma-masonry-item-menu',function(){
                if ($(this).hasClass('active')) {
                    $(this).removeClass('active');
                    $scope.find(".calumma-masonry-item-dropdown").hide();
                    $scope.find('.calumma-masonry-item').removeClass('active');
                } else {
                    $scope.find('.calumma-masonry-item-menu').removeClass('active');
                    $scope.find(".calumma-masonry-item-dropdown").css('display', 'none');
                    $scope.find(".calumma-masonry-item-dropdown").removeClass('align-right');
                    $scope.find('.calumma-masonry-item').removeClass('active');
                    $(this).addClass('active');
                    $(this).parent().parent().addClass('active');

                    var dropdown = $(this).next(".calumma-masonry-item-dropdown");
                    dropdown.show();

                    var width = document.body.clientWidth;
                    var offset = dropdown.offset().left;
                    var distance = dropdown.width() + offset;

                    if (distance >= width) {
                        dropdown.addClass('align-right');
                    } else {
                        dropdown.removeClass('align-right');
                    }
                }
            });

            /* Close Dropdown Button */
            $scope.find('.calumma-grid').on('click','.calumma-close',function(){
                $scope.find('.calumma-masonry-item-menu').removeClass('active');
                $scope.find(".calumma-masonry-item-dropdown").hide();
                $scope.find('.calumma-masonry-item').removeClass('active');
            });

            /* Clear Search Input */
            $scope.find('.calumma-search').on('click','.calumma-clear-text',function(){
                $(this).parent().find('.pexels-keyword').val('');
                $scope.find('.pexels-orientation').val('');
                $scope.find('.pexels-color').val('');
                $scope.find('.pexels-orientation').prop('disabled', true);
                $scope.find('.pexels-color').prop('disabled', true);
                $(this).hide();
            });

            /* Show/Hide Clear Button */
            $scope.find('.calumma-search').on('input paste','.pexels-keyword',function(){
                var val = $(this).val();
                if (val.length >= 1) {
                    $scope.find('.calumma-clear-text').show();
                    $scope.find('.pexels-orientation').prop('disabled', false);
                    $scope.find('.pexels-color').prop('disabled', false);
                } else {
                    $scope.find('.calumma-clear-text').hide();
                    $scope.find('.pexels-orientation').val('');
                    $scope.find('.pexels-color').val('');
                    $scope.find('.pexels-orientation').prop('disabled', true);
                    $scope.find('.pexels-color').prop('disabled', true);
                }
            });

            // Check default keyword on first page load
            var defaultKeyword = $scope.find('.pexels-keyword').val();
            if (defaultKeyword.length >= 1) {
                $scope.find('.calumma-clear-text').show();
                $scope.find('.pexels-orientation').prop('disabled', false);
                $scope.find('.pexels-color').prop('disabled', false);
            }
        });       
    });
} )( jQuery );