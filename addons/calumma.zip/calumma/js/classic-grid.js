( function( $ ) {
    "use strict";
	$( window ).on( 'elementor/frontend/init', function() {            
        elementorFrontend.hooks.addAction('frontend/element_ready/calumma-classic-grid.default', function($scope){
            var grid = $scope.find('.calumma-grid');
            var image_size = grid.data('size');

            // Masonry
            var masonry = grid.masonry({
                itemSelector: '.calumma-masonry-item',
                columnWidth: '.calumma-grid-sizer',
                percentPosition: true
            });

            if ( grid.hasClass('elementor-frontend') ) {
                // Remove loaders on image loaded
                grid.imagesLoaded().progress( function( instance, image ) {  
                    if (image.isLoaded) {
                        $(image.img).parent().find('.calumma-img-loader').remove();
                        masonry.masonry();
                    }
                });
            } else {
                // Load items via ajax on Elementor editor mode
                var pagination = $scope.find('.calumma-pagination'),
                defaultMax = parseInt(pagination.attr('data-max')),
                keyword = $scope.find('.calumma-search input.calumma-form-field').val(),
                category = $scope.find('.calumma-search select.calumma-select').val(),
                defaultData = {
                    'action': 'calummaSearch',
                    'nonce': calumma.nonce,
                    'keyword': keyword,
                    'category': category,
                    'page': 1,
                    'max': defaultMax,
                    'size': image_size
                };
                $.ajax({
                    url : calumma.ajaxurl,
                    data : defaultData,
                    type : 'POST',
                    beforeSend: function() {
                        pagination.hide();
                    },
                    success: function(data){
                        var oldItems = masonry.masonry('getItemElements');
                        masonry.masonry('remove', oldItems);
                        if(data) {
                            var items = $(data);
                            masonry.prepend(items).masonry('prepended', items);
                            if (defaultMax > items.length) {
                                pagination.hide();
                            } else {
                                pagination.show();
                            }
                            grid.imagesLoaded().progress( function( instance, image ) { 
                                if (image.isLoaded) {
                                    $(image.img).parent().find('.calumma-img-loader').remove();
                                    masonry.masonry();
                                } 
                            });
                        } else {
                            masonry.masonry();
                            pagination.hide();
                        }
                    },
                    error: function(jqXHR,error, errorThrown) {
                        if(jqXHR.status&&jqXHR.status==400){
                            alert(jqXHR.responseText);
                        }else{
                            alert(calumma.error);
                        }
                    }
                });
            }

            // Template menu
            $scope.find('.calumma-grid').on('click','.calumma-masonry-item-menu',function(){
                if ($(this).hasClass('active')) {
                    $(this).removeClass('active');
                    $scope.find(".calumma-masonry-item-dropdown").hide();
                    $scope.find('.calumma-masonry-item').removeClass('active');
                } else {
                    $scope.find('.calumma-masonry-item-menu').removeClass('active');
                    $scope.find(".calumma-masonry-item-dropdown").css('display', 'none');
                    $scope.find(".calumma-masonry-item-dropdown").removeClass('align-right');
                    $scope.find('.calumma-masonry-item').removeClass('active');
                    $(this).addClass('active');
                    $(this).parent().parent().addClass('active');

                    var dropdown = $(this).next(".calumma-masonry-item-dropdown");
                    dropdown.show();

                    var width = document.body.clientWidth;
                    var offset = dropdown.offset().left;
                    var distance = dropdown.width() + offset;

                    if (distance >= width) {
                        dropdown.addClass('align-right');
                    } else {
                        dropdown.removeClass('align-right');
                    }
                }
            });

            /* Close Dropdown Button */
            $scope.find('.calumma-grid').on('click','.calumma-close',function(){
                $scope.find('.calumma-masonry-item-menu').removeClass('active');
                $scope.find(".calumma-masonry-item-dropdown").hide();
                $scope.find('.calumma-masonry-item').removeClass('active');
            });

            /* Clear Search Input */
            $scope.find('.calumma-search').on('click','.calumma-clear-text',function(){
                $(this).parent().find('input.calumma-form-field').val('');
                $(this).hide();
            });

            /* Show/Hide Clear Button */
            $scope.find('.calumma-search').on('input paste','input.calumma-form-field',function(){
                var val = $(this).val();
                if (val.length >= 1) {
                    $scope.find('.calumma-clear-text').show();
                } else {
                    $scope.find('.calumma-clear-text').hide();
                }
            });

            if ( grid.hasClass('elementor-frontend') ) {
                $scope.find('input.calumma-form-field').trigger('input');

                // Helper function
                var getUrlParameter = function getUrlParameter(sParam) {
                    var sPageURL = window.location.search.substring(1),
                        sURLVariables = sPageURL.split('&'),
                        sParameterName,
                        i;
                
                    for (i = 0; i < sURLVariables.length; i++) {
                        sParameterName = sURLVariables[i].split('=');
                
                        if (sParameterName[0] === sParam) {
                            return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
                        }
                    }
                    return false;
                };

                // Check old and new values on form submit
                $scope.find('.calumma-search').on('submit', function(){
                    var old_keyword = getUrlParameter('template-keyword');
                    var old_tag = getUrlParameter('template-tag');
                    var new_keyword = $(this).find('.calumma-form-field').val();
                    var new_tag = $(this).find('.calumma-select option:selected').val();

                    if (old_keyword !== false && old_keyword !== new_keyword) {
                        $(this).find('.calumma-template-page-input').val('1');
                    } else if (old_tag !== false && old_tag !== new_tag) {
                        $(this).find('.calumma-template-page-input').val('1');
                    }

                });

                /* Preview Template */
                $scope.find('.calumma-grid').on('click','img',function(){
                    $(this).parent().find('.calumma-preview-link').trigger('click');
                });

                /* Add to Favorite */
                $scope.find('.calumma-grid').on('click','.calumma-add-to-fav',function(){
                    var button = $(this);
                    var templateid = button.data('templateid');
                    var mode = 'add';
                    if (button.hasClass('favorited')) {
                        mode = 'remove';
                    }
                    var data = {
                        'action': 'calummaFav',
                        'nonce': calumma.nonce,
                        'templateid': templateid,
                        'mode': mode
                    };
                    $.ajax({
                        url : calumma.ajaxurl,
                        data : data,
                        type : 'POST',
                        beforeSend: function() {
                            button.css('opacity', 0.7);
                            button.css('pointer-events', 'none');
                        },
                        success: function(){
                            if (mode == 'add') {
                                button.addClass('favorited');
                                button.html('<i class="fas fa-star"></i>' + calumma.added);
                            } else {
                                button.removeClass('favorited');
                                button.html('<i class="far fa-star"></i>' + calumma.add);
                            }
                        },
                        error: function(jqXHR,error, errorThrown) {
                            if(jqXHR.status&&jqXHR.status==400){
                                alert(jqXHR.responseText);
                            }else{
                                alert(calumma.error);
                            }
                        },
                        complete: function() {
                            button.css('opacity', 1);
                            button.css('pointer-events', 'auto');
                        }
                    });
                });

                /* Pagination */
                $scope.find('ul.calumma-pagination').on('click','li',function(){
                    var page = $(this).data('page');
                    $scope.find('.calumma-search .calumma-template-page-input').val(page);
                    $scope.find('.calumma-search').trigger('submit');
                });
            }
        });       
    });
} )( jQuery );