( function( $ ) {
    "use strict";
	$( window ).on( 'elementor/frontend/init', function() {            
        elementorFrontend.hooks.addAction('frontend/element_ready/calumma-ajax-grid.default', function($scope){
            var grid = $scope.find('.calumma-grid');
            var image_size = grid.data('size');

            // Masonry
            var masonry = grid.masonry({
                itemSelector: '.calumma-masonry-item',
                columnWidth: '.calumma-grid-sizer',
                percentPosition: true
            });

            if ( grid.hasClass('elementor-frontend') ) {
                // Remove loaders on image loaded
                grid.imagesLoaded().progress( function( instance, image ) {  
                    if (image.isLoaded) {
                        $(image.img).parent().find('.calumma-img-loader').remove();
                        masonry.masonry();
                    }
                });
            } else {
                // Load items via ajax on Elementor editor mode
                var defaultButton = $scope.find('.calumma-search .calumma-btn'),
                defaultViewmore = $scope.find('button.calumma-load-more'),
                defaultMax = parseInt(defaultViewmore.attr('data-max')),
                keyword = $scope.find('.calumma-search input.calumma-form-field').val(),
                category = $scope.find('.calumma-search select.calumma-select').val(),
                defaultData = {
                    'action': 'calummaSearch',
                    'nonce': calumma.nonce,
                    'keyword': keyword,
                    'category': category,
                    'page': 1,
                    'max': defaultMax,
                    'size': image_size
                };
                $.ajax({
                    url : calumma.ajaxurl,
                    data : defaultData,
                    type : 'POST',
                    beforeSend: function() {
                        defaultButton.prop('disabled', true);
                        defaultViewmore.prop('disabled', true);
                        $scope.find('.calumma-notice').fadeOut();
                    },
                    success: function(data){
                        var oldItems = masonry.masonry('getItemElements');
                        masonry.masonry('remove', oldItems);
                        if(data) {
                            var items = $(data);
                            masonry.prepend(items).masonry('prepended', items);
                            if (defaultMax > items.length) {
                                defaultViewmore.prop('disabled', true);
                            } else {
                                defaultViewmore.prop('disabled', false);
                            }
                            grid.imagesLoaded().progress( function( instance, image ) { 
                                if (image.isLoaded) {
                                    $(image.img).parent().find('.calumma-img-loader').remove();
                                    masonry.masonry();
                                } 
                            });
                        } else {
                            masonry.masonry();
                            $scope.find('.calumma-notice').fadeIn();
                            defaultViewmore.prop('disabled', true);
                        }
                        defaultViewmore.attr('data-page', 2);
                    },
                    error: function(jqXHR,error, errorThrown) {
                        if(jqXHR.status&&jqXHR.status==400){
                            alert(jqXHR.responseText);
                        }else{
                            alert(calumma.error);
                        }
                    },
                    complete: function() {
                        defaultButton.prop('disabled', false);
                    }
                });
            }

            // Template menu
            $scope.find('.calumma-grid').on('click','.calumma-masonry-item-menu',function(){
                if ($(this).hasClass('active')) {
                    $(this).removeClass('active');
                    $scope.find(".calumma-masonry-item-dropdown").hide();
                    $scope.find('.calumma-masonry-item').removeClass('active');
                } else {
                    $scope.find('.calumma-masonry-item-menu').removeClass('active');
                    $scope.find(".calumma-masonry-item-dropdown").css('display', 'none');
                    $scope.find(".calumma-masonry-item-dropdown").removeClass('align-right');
                    $scope.find('.calumma-masonry-item').removeClass('active');
                    $(this).addClass('active');
                    $(this).parent().parent().addClass('active');

                    var dropdown = $(this).next(".calumma-masonry-item-dropdown");
                    dropdown.show();

                    var width = document.body.clientWidth;
                    var offset = dropdown.offset().left;
                    var distance = dropdown.width() + offset;

                    if (distance >= width) {
                        dropdown.addClass('align-right');
                    } else {
                        dropdown.removeClass('align-right');
                    }
                }
            });

            /* Close Dropdown Button */
            $scope.find('.calumma-grid').on('click','.calumma-close',function(){
                $scope.find('.calumma-masonry-item-menu').removeClass('active');
                $scope.find(".calumma-masonry-item-dropdown").hide();
                $scope.find('.calumma-masonry-item').removeClass('active');
            });

            /* Clear Search Input */
            $scope.find('.calumma-search').on('click','.calumma-clear-text',function(){
                $(this).parent().find('input.calumma-form-field').val('');
                $(this).hide();
            });

            /* Show/Hide Clear Button */
            $scope.find('.calumma-search').on('input paste','input.calumma-form-field',function(){
                var val = $(this).val();
                if (val.length >= 1) {
                    $scope.find('.calumma-clear-text').show();
                } else {
                    $scope.find('.calumma-clear-text').hide();
                }
            });

            if ( grid.hasClass('elementor-frontend') ) {
                /* Template Search */
                $scope.find('.calumma-search').on('click','.calumma-btn',function(){
                    var button = $(this),
                    viewmore = $scope.find('button.calumma-load-more'),
                    max = parseInt(viewmore.attr('data-max')),
                    keyword = $scope.find('input.calumma-form-field').val(),
                    category = $scope.find('select.calumma-select').val(),
                    data = {
                        'action': 'calummaSearch',
                        'nonce': calumma.nonce,
                        'keyword': keyword,
                        'category': category,
                        'page': 1,
                        'max': max,
                        'size': image_size
                    };
                    $.ajax({
                        url : calumma.ajaxurl,
                        data : data,
                        type : 'POST',
                        beforeSend: function() {
                            button.prop('disabled', true);
                            viewmore.prop('disabled', true);
                            $scope.find('.calumma-grid').addClass('calumma-grid-loading');
                            $scope.find('.calumma-notice').fadeOut();
                        },
                        success: function(data){
                            var oldItems = masonry.masonry('getItemElements');
                            masonry.masonry('remove', oldItems);
                            if(data) {
                                var items = $(data);
                                masonry.prepend(items).masonry('prepended', items);
                                if (max > items.length) {
                                    viewmore.prop('disabled', true);
                                } else {
                                    viewmore.prop('disabled', false);
                                }
                                grid.imagesLoaded().progress( function( instance, image ) { 
                                    if (image.isLoaded) {
                                        image.img.parentElement.children[0].remove();
                                        masonry.masonry();
                                    } 
                                });
                            } else {
                                masonry.masonry();
                                $scope.find('.calumma-notice').fadeIn();
                                viewmore.prop('disabled', true);
                            }
                            viewmore.attr('data-page', 2);
                        },
                        error: function(jqXHR,error, errorThrown) {
                            if(jqXHR.status&&jqXHR.status==400){
                                alert(jqXHR.responseText);
                            }else{
                                alert(calumma.error);
                            }
                        },
                        complete: function() {
                            $scope.find('.calumma-grid').removeClass('calumma-grid-loading');
                            button.prop('disabled', false);
                        }
                    });
                });

                /* Preview Template */
                $scope.find('.calumma-grid').on('click','img',function(){
                    $(this).parent().find('.calumma-preview-link').trigger('click');
                });

                /* Load More Template */
                $scope.on('click','button.calumma-load-more',function(){
                    var button = $(this),
                    page = parseInt(button.attr('data-page')),
                    max = parseInt(button.attr('data-max')),
                    keyword = $scope.find('input.calumma-form-field').val(),
                    category = $scope.find('select.calumma-select').val(),
                        data = {
                        'action': 'calummaSearch',
                        'nonce': calumma.nonce,
                        'keyword': keyword,
                        'category': category,
                        'page': page,
                        'max': max,
                        'size': image_size
                    };
                    $.ajax({
                        url : calumma.ajaxurl,
                        data : data,
                        type : 'POST',
                        beforeSend: function() {
                            button.addClass('disabled');
                            $scope.find('.calumma-grid').addClass('calumma-grid-loading');
                            $scope.find('.calumma-notice').fadeOut();
                        },
                        success: function(data){
                            if(data) {
                                var items = $(data);
                                masonry.append(items).masonry('appended', items);
                                if (max > items.length) {
                                    button.prop('disabled', true);
                                } else {
                                    button.prop('disabled', false);
                                }
                                grid.imagesLoaded().progress( function( instance, image ) { 
                                    if (image.isLoaded) {
                                        $(image.img).parent().find('.calumma-img-loader').remove();
                                        masonry.masonry();
                                    } 
                                });
                                button.attr('data-page', page + 1);
                            } else {
                                button.attr('data-page', 2);
                                button.prop('disabled', true);
                            }
                        },
                        error: function(jqXHR,error, errorThrown) {
                            if(jqXHR.status&&jqXHR.status==400){
                                alert(jqXHR.responseText);
                            }else{
                                alert(calumma.error);
                            }
                        },
                        complete: function() {
                            button.removeClass('disabled');
                            $scope.find('.calumma-grid').removeClass('calumma-grid-loading');
                        }
                    });
                });

                /* Add to Favorite */
                $scope.find('.calumma-grid').on('click','.calumma-add-to-fav',function(){
                    var button = $(this);
                    var templateid = button.data('templateid');
                    var mode = 'add';
                    if (button.hasClass('favorited')) {
                        mode = 'remove';
                    }
                    var data = {
                        'action': 'calummaFav',
                        'nonce': calumma.nonce,
                        'templateid': templateid,
                        'mode': mode
                    };
                    $.ajax({
                        url : calumma.ajaxurl,
                        data : data,
                        type : 'POST',
                        beforeSend: function() {
                            button.css('opacity', 0.7);
                            button.css('pointer-events', 'none');
                        },
                        success: function(){
                            if (mode == 'add') {
                                button.addClass('favorited');
                                button.html('<i class="fas fa-star"></i>' + calumma.added);
                            } else {
                                button.removeClass('favorited');
                                button.html('<i class="far fa-star"></i>' + calumma.add);
                            }
                        },
                        error: function(jqXHR,error, errorThrown) {
                            if(jqXHR.status&&jqXHR.status==400){
                                alert(jqXHR.responseText);
                            }else{
                                alert(calumma.error);
                            }
                        },
                        complete: function() {
                            button.css('opacity', 1);
                            button.css('pointer-events', 'auto');
                        }
                    });
                });

            }
        });       
    });
} )( jQuery );