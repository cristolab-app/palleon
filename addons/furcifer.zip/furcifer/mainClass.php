<?php
defined( 'ABSPATH' ) || exit;

class Furcifer extends Palleon {
    /**
	 * The single instance of the class
	 */
	protected static $_instance = null;

    /**
	 * Main Instance
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

    /**
	 * Furcifer Constructor
	 */
    public function __construct() {
        add_action('init', array($this, 'furcifer_init'), 1);
        if (is_user_logged_in()) {
            add_filter('palleonStylesheets', array($this, 'furcifer_styles'), 20);
            add_filter('palleonScripts', array($this, 'furcifer_scripts'), 20);
            add_action('palleon_body_end', array($this, 'furcifer_single_image'), 10);
            add_action('palleon_body_end', array($this, 'furcifer_localization'), 10);
            add_action('palleon_media_library_tab', array($this, 'furcifer_tab_title'));
            add_action('palleon_media_library_tab_content', array($this, 'furcifer_tab'));
            add_action('agama_media_library_tab', array($this, 'furcifer_tab_title'));
            add_action('agama_media_library_tab_content', array($this, 'furcifer_tab'));
            add_action('palleon_backend', array($this, 'furcifer_auth'));
            add_action('palleon_frontend', array($this, 'furcifer_auth'));
            add_action('wp_ajax_filestackApiKey', array($this, 'filestack_api_key'));
            add_action('wp_ajax_furciferClient', array($this, 'furcifer_client'));
            add_action('wp_ajax_furciferUpdateToken', array($this, 'furcifer_update_token'));
            add_action('wp_ajax_furciferDeleteToken', array($this, 'furcifer_delete_token'));
            add_action('palleon_before_save_template', array($this, 'save_field'), 1);
        }
        add_filter('plugin_row_meta', array($this, 'furcifer_plugin_links'), 10, 4);
        add_action('palleon_add_setting_tab', array($this, 'furcifer_setting_tab'));
		add_action('palleon_add_settings', array($this, 'furcifer_settings'));
    }

    /**
	 * Init
	 */
    public function furcifer_init() {
        // Load text domain
        load_plugin_textdomain( 'furcifer', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
    }

    /**
	 * Add plugin links to plugins page on the admin dashboard
	 */
    public function furcifer_plugin_links($links_array, $plugin_file_name, $plugin_data, $status) {
        if ( strpos( $plugin_file_name, 'furcifer.php' ) !== false ) {
            $links_array[] = '<a href="'. esc_url( get_admin_url(null, 'admin.php?page=palleon_options&tab=cmb2-id-furcifer-title') ) .'">' . esc_html__( 'Settings', 'furcifer' ) . '</a>';
            $links_array[] = '<a href="https://palleon.website/furcifer/documentation/" target="_blank">' . esc_html__( 'Documentation', 'furcifer' ) . '</a>';
        }
        return $links_array;
    }

    /**
	 * Palleon styles
	 */
    public function furcifer_styles($styles) {
        $styles['furcifer-css'] = array(FURCIFER_PLUGIN_URL . 'css/style.css', FURCIFER_VERSION);
        return $styles;
    }
    
	/**
	 * Palleon scripts
	 */
    public function furcifer_scripts($scripts) {
        $filestack = PalleonSettings::get_option('filestack_api_key', '');
        if (!empty($filestack)) {
            $scripts['filestack'] = array('//static.filestackapi.com/filestack-js/3.x.x/filestack.min.js', FURCIFER_VERSION);
        }
        $scripts['furcifer-js'] = array(FURCIFER_PLUGIN_URL . 'js/custom.js', FURCIFER_VERSION);
        return $scripts;
    }

    /**
	 * Localization and settings
	 */
    public function furcifer_localization() {
        $apiVersion = PalleonSettings::get_option('imgur_api_version', 'free');
        $filestackServices = PalleonSettings::get_option('filestack_services', array('local_file_system'));
        $filestackMaxSize = PalleonSettings::get_option('filestack_max_size', 2000);
        $apiUrl = 'https://api.imgur.com/';
        $rapidApiKeyOption = trim(PalleonSettings::get_option('imgur_rapid_api_key', ''));
        $rapidApiKey = '';
        if ($apiVersion == 'commercial' && !empty($rapidApiKeyOption)) {
            $apiUrl = 'https://imgur-apiv3.p.rapidapi.com/';
            $rapidApiKey = esc_html($rapidApiKeyOption);
        }
        ?>
        <script>
        /* <![CDATA[ */
        var furciferParams = {
            "locale": "<?php echo get_locale(); ?>",
            "apiUrl": "<?php echo $apiUrl; ?>",
            "rapidApiKey": "<?php echo esc_html($rapidApiKey); ?>",
            "filestackServices": "<?php echo implode(",", $filestackServices); ?>",
            "filestackMaxSize": "<?php echo esc_html($filestackMaxSize); ?>",
            "tooBig": "<?php echo esc_html__('File too big, please select smaller image.', 'furcifer'); ?>",
            "uploadedOn": "<?php echo esc_html__('Upload Date', 'furcifer'); ?>",
            "size": "<?php echo esc_html__('Size', 'furcifer'); ?>",
            "views": "<?php echo esc_html__('Views', 'furcifer'); ?>",
            "wait": "<?php echo esc_html__('Please wait...', 'furcifer'); ?>",
            "edit": "<?php echo esc_html__('Edit', 'furcifer'); ?>",
            "editImg": "<?php echo esc_html__('Edit Image', 'furcifer'); ?>",
            "updated": "<?php echo esc_html__('Image information is updated.', 'furcifer'); ?>",
            "remove": "<?php echo esc_html__('Remove', 'furcifer'); ?>",
            "selectAlbum": "<?php echo esc_html__('Select Album', 'furcifer'); ?>",
            "imageDeleted": "<?php echo esc_html__('Image is deleted.', 'furcifer'); ?>",
            "albumCreated": "<?php echo esc_html__('Album is created.', 'furcifer'); ?>",
            "albumDeleted": "<?php echo esc_html__('Album is deleted.', 'furcifer'); ?>",
            "imagesAdded": "<?php echo esc_html__('Images are added to the album.', 'furcifer'); ?>",
            "imageRemoved": "<?php echo esc_html__('Image is removed from the album.', 'furcifer'); ?>",
            "imgRequired": "<?php echo esc_html__('Please select the images you want to add to the album.', 'furcifer'); ?>",
            "titleRequired": "<?php echo esc_html__('Title is required.', 'furcifer'); ?>",
            "albumRequired": "<?php echo esc_html__('Please select an album.', 'furcifer'); ?>",
            "published": "<?php echo esc_html__('The gallery is posted on Imgur.', 'furcifer'); ?>",
            "viewGallery": "<?php echo esc_html__('Click here to view your gallery.', 'furcifer'); ?>",
            "notitle": "<?php echo esc_html__('(No Title)', 'furcifer'); ?>",
            "noClient": "<?php echo esc_html__('Client ID and Client Secret are required to use Imgur API.', 'furcifer'); ?>",
            "upload": "<?php echo esc_html__('Upload Image', 'furcifer'); ?>",
            "uploadSvg": "<?php echo esc_html__('Upload SVG', 'furcifer'); ?>",
            "uploadFail": "<?php echo esc_html__('Upload Failed.', 'furcifer'); ?>",
        };
        /* ]]> */
        </script>
        <?php
    }

    /**
	 * Add setting tab
	 */
    public function furcifer_setting_tab($options) {
        $options->add_field( array(
            'name' => '<span class="dashicons dashicons-admin-plugins"></span>' . esc_html__( 'Furcifer', 'furcifer' ),
            'id'   => 'furcifer_title',
            'type' => 'title'
        ) );
    }

    /**
	 * Add settings
	 */
    public function furcifer_settings($options) {

        $options->add_field( array(
            'name'    => esc_html__( 'Filestack API Key (Required)', 'furcifer' ),
            'description' => esc_html__( 'You must get an API key from Filestack to replace upload button with Filestack File Picker.', 'furcifer' ),
            'id'      => 'filestack_api_key',
            'type'    => 'text',
            'attributes' => array(
                'autocomplete' => 'off'
            ),
            'default' => '',
            'before_row' => '<div class="palleon-tab-content" data-id="furcifer-title">',
        ) );

        $options->add_field( array(
            'name' => esc_html__( 'Filestack Services', 'furcifer' ),
            'description' => esc_html__( 'Choose the services you would like to display to your users so they can upload files from.', 'furcifer' ),
            'id'   => 'filestack_services',
            'type' => 'multicheck_inline',
            'select_all_button' => false,
            'options' => array(
                'local_file_system' => esc_html__( 'Local File System', 'furcifer' ),
                'url' => esc_html__( 'URL', 'furcifer' ),
                'imagesearch' => esc_html__( 'Image Search', 'furcifer' ),
                'unsplash' => esc_html__( 'Unsplash', 'furcifer' ),
                'instagram' => esc_html__( 'Instagram', 'furcifer' ),
                'facebook' => esc_html__( 'Facebook', 'furcifer' ),
                'googledrive' => esc_html__( 'Google Drive', 'furcifer' ),
                'box' => esc_html__( 'Box', 'furcifer' ),
                'googlephotos' => esc_html__( 'Google Photos', 'furcifer' ),
                'onedrive' => esc_html__( 'One Drive', 'furcifer' ),
                'onedriveforbusiness' => esc_html__( 'One Drive For Business', 'furcifer' ),
            ),
            'attributes' => array(
                'autocomplete' => 'off'
            ),
            'default' => 'local_file_system'
        ) );

        $options->add_field( array(
            'name' => esc_html__( 'Max File Size', 'furcifer' ),
            'description' => esc_html__( 'Max. allowed image size in bytes. 1000byte = 1MB', 'furcifer' ),
            'id'   => 'filestack_max_size',
            'type' => 'text',
            'attributes' => array(
                'type' => 'number',
                'pattern' => '\d*',
                'autocomplete' => 'off'
            ),
            'default' => 2000
        ) );

        $options->add_field( array(
            'name'    => esc_html__( 'Imgur Client ID (Required)', 'furcifer' ),
            'description' => esc_html__( 'You must register your app on imgur.com to get the "Client ID". For more information, please read the documentation.', 'furcifer' ),
            'id'      => 'imgur_client_id',
            'type'    => 'text',
            'attributes' => array(
                'autocomplete' => 'off'
            ),
            'default' => ''
        ) );

        $options->add_field( array(
            'name'    => esc_html__( 'Imgur Client Secret (Required)', 'furcifer' ),
            'description' => esc_html__( 'You must register your app on imgur.com to get the "Client Secret". For more information, please read the documentation.', 'furcifer' ),
            'id'      => 'imgur_client_secret',
            'type'    => 'text',
            'attributes' => array(
                'autocomplete' => 'off'
            ),
            'default' => ''
        ) );

        $options->add_field( array(
            'name' => esc_html__( 'Imgur API Version', 'furcifer' ),
            'description' => esc_html__( 'For more information, please read the documentation.', 'furcifer' ),
            'id'   => 'imgur_api_version',
            'type' => 'radio_inline',
            'options' => array(
                'free' => esc_html__( 'Free', 'furcifer' ),
                'commercial'   => esc_html__( 'Commercial (Rapid API)', 'furcifer' )
            ),
            'attributes' => array(
                'autocomplete' => 'off'
            ),
            'default' => 'free'
        ) );

        $options->add_field( array(
            'name'    => esc_html__( 'Imgur Rapid API Key', 'furcifer' ),
            'description' => esc_html__( 'Required for only commercial API.', 'furcifer' ),
            'id'      => 'imgur_rapid_api_key',
            'type'    => 'text',
            'attributes' => array(
                'autocomplete' => 'off'
            ),
            'default' => ''
        ) );

        $options->add_field( array(
            'name' => esc_html__( 'Imgur Grid Pagination', 'furcifer' ),
            'description' => esc_html__( 'Max. number of images to show.', 'furcifer' ),
            'id'   => 'imgur_pagination',
            'type' => 'text',
            'attributes' => array(
                'type' => 'number',
                'pattern' => '\d*',
                'autocomplete' => 'off'
            ),
            'default' => 18
        ) );

        $options->add_field( array(
            'name' => esc_html__( 'Imgur List Pagination', 'furcifer' ),
            'description' => esc_html__( 'Max. number of images to show.', 'furcifer' ),
            'id'   => 'imgur_list_pagination',
            'type' => 'text',
            'attributes' => array(
                'type' => 'number',
                'pattern' => '\d*',
                'autocomplete' => 'off'
            ),
            'default' => 5,
            'after_row' => '</div>'
        ) );
    }

    /**
	 * Add tab titles
	 */
    public function furcifer_tab_title() {
        $filestack = PalleonSettings::get_option('filestack_api_key', '');
        $clientID = PalleonSettings::get_option('imgur_client_id', '');
        $clientSecret = PalleonSettings::get_option('imgur_client_secret', '');
        if (!empty($filestack)) {
            echo '<li id="modal-filestack-link" data-target="#modal-filestack">' . esc_html__('Filestack', 'furcifer') . '</li>';
        }
        if (!empty($clientID) && !empty($clientSecret)) {
            echo '<li id="modal-imgur-link" data-target="#modal-imgur">' . esc_html__('IMGUR', 'furcifer') . '</li>';
        }
    }

    /**
	 * Include tab contents
	 */
    public function furcifer_tab() {
        $user_id = get_current_user_id();
        $filestack = PalleonSettings::get_option('filestack_api_key', '');
        $refreshToken = get_user_meta($user_id, 'furcifer_refresh_token', true);
        $clientID = PalleonSettings::get_option('imgur_client_id', '');
        $clientSecret = PalleonSettings::get_option('imgur_client_secret', '');
        if (!empty($filestack)) {
            echo '<div id="modal-filestack" class="palleon-tab"><div id="filestack-new"></div></div>';
        }
        if (!empty($clientID) && !empty($clientSecret)) {
            if (empty($refreshToken)) {
                echo '<div id="modal-imgur" class="palleon-tab">';
                echo '<button id="imgur-authorization" type="button" class="palleon-btn primary palleon-lg-btn btn-full"><span class="material-icons">lock</span>' . esc_html__('Authorize', 'furcifer') . '</button>';
                echo '<div id="imgur-authorization-info" class="notice notice-warning">' . esc_html__('Authorization required. By clicking the button, you will be directed to imgur.com to allow the app to connect to your account.', 'furcifer') . '</div>';
                echo '</div>';
            } else {
                echo '<div id="modal-imgur" class="palleon-tab">';
                echo '<button id="imgur-login" type="button" class="palleon-btn primary palleon-lg-btn btn-full" data-token="' . esc_attr($refreshToken) . '"><span class="material-icons">login</span>' . esc_html__('Click To Login Imgur', 'furcifer') . '</button>';
                echo '<div id="imgur-login-info" class="notice">' . esc_html__('If you are having trouble signing in, click here to re-authorize the app.', 'furcifer') . '</div>';
                echo '<div class="palleon-tabs imgur-hide">';
                include_once('includes/submenu.php');
                include_once('includes/images.php');
                include_once('includes/albums.php');
                echo '</div>';
                echo '</div>';
            }
        }
    }

    /************ IMGUR ************/

    /**
	 * Imgur authorization check
	 */
    public function furcifer_auth() {
        $user_id = get_current_user_id();
        if (isset($_GET['refresh_token']) && !empty($_GET['refresh_token'])) {
            update_user_meta( $user_id, 'furcifer_refresh_token', esc_html($_GET['refresh_token']));
        }
    }

    /**
	 * Imgur get client details
	 */
    public function furcifer_client() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'furcifer'));
        }
        $clientID = esc_html(PalleonSettings::get_option('imgur_client_id', ''));
        $clientSecret = esc_html(PalleonSettings::get_option('imgur_client_secret', ''));
        $response = '{"message": "' . esc_html__( 'Client ID and Client Secret are required to use Imgur API.', 'furcifer' ) . '"}';
        if (!empty($clientID) && !empty($clientSecret)) {
            $response = '{"id": "' . trim($clientID) . '","secret": "' . trim($clientSecret) . '"}';
        }
        echo $response;
        wp_die();
    }

    /**
	 * Update refresh token
	 */
    public function furcifer_update_token() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'furcifer'));
        }
        if (isset($_POST['token']) && !empty($_POST['token'])) {
            $update = update_user_meta( get_current_user_id(), 'furcifer_refresh_token', esc_html($_POST['token']));
            if ( is_wp_error( $update ) ) {
                echo 'error';
            } else {
                echo 'done';
            }
        }
        wp_die();
    }

    /**
	 * Delete refresh token
	 */
    public function furcifer_delete_token() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'furcifer'));
        }
        $delete = delete_user_meta( get_current_user_id(), 'furcifer_refresh_token');
        if ( is_wp_error( $delete ) ) {
            echo 'error';
        } else {
            echo 'done';
        }
        wp_die();
    }

    /**
	 * Imgur image modal box content
	 */
    public function furcifer_single_image() {
        include_once('includes/single-image.php');
    }

    /**
	 * Add save button to Palleon
	 */
    public function save_field(){
        ?>
        <div id="palleon-save-to-imgur" class="d-none">
            <div class="palleon-block-50">
                <div>
                    <label><?php echo esc_html__('File Name', 'furcifer'); ?></label>
                    <input id="palleon-imgur-save-name" class="palleon-form-field palleon-file-name" type="text" value="" autocomplete="off" data-default="">
                </div>
                <div>
                    <button id="palleon-imgur-save" type="button" class="palleon-btn primary"><span class="material-icons">save</span><?php echo esc_html__('Save To Imgur', 'furcifer'); ?></button>
                </div>
            </div>
            <div class="palleon-block-50">
                <div>
                    <label><?php echo esc_html__('Album', 'furcifer'); ?></label>
                    <select id="palleon-imgur-save-album" class="palleon-select imgur-albums-select" autocomplete="off"></select>
                </div>
                <div>
                    <label><?php echo esc_html__('File Format', 'furcifer'); ?></label>
                    <select id="palleon-imgur-save-img-format" class="palleon-select palleon-save-img-format" autocomplete="off">
                        <option selected value="jpeg">JPEG</option>
                        <option value="png">PNG</option>
                        <option value="webp">WEBP</option>
                    </select>
                </div>
            </div>
        </div>
        <?php     
    }
    /**
	 * Get Filestack API Key
	 */
    public function filestack_api_key() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'furcifer'));
        }
        $apiKey = PalleonSettings::get_option('filestack_api_key', '');
        if (!empty($apiKey)) {
            $apiKey = trim($apiKey);
            echo $apiKey;
        }
        wp_die();
    }
}

/**
 * Returns the main instance of the class
 */
function Furcifer() {  
	return Furcifer::instance();
}
// Global for backwards compatibility
$GLOBALS['Furcifer'] = Furcifer();    