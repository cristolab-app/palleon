<?php $perpage = PalleonSettings::get_option('imgur_list_pagination',5);  ?>
<div id="imgur-albums-tab" class="palleon-tab">
    <div class="imgur-albums-tab-wrap">
        <div class="imgur-albums-tab-left">
            <div class="imgur-albums-select-wrap">
                <select id="imgur-albums-select" class="palleon-select imgur-albums-select" autocomplete="off"></select>
                <button id="imgur-albums-select-btn" type="button" class="palleon-btn btn-full primary"><span class="material-icons">filter_alt</span><?php echo esc_html__('Filter Results', 'furcifer'); ?></button>
            </div>
            <ul id="imgur-albums-images" class="palleon-template-list paginated" data-perpage="<?php echo esc_attr($perpage); ?>">
            </ul>
            <div id="imgur-albums-noimg" class="notice notice-warning d-none"><?php echo esc_html__('Nothing found.', 'furcifer'); ?></div>
        </div>
        <div class="imgur-albums-tab-right">
            <ul class="palleon-accordion"> 
                <li class="opened"> 
                    <a href="#"><span class="material-icons accordion-icon">add_circle</span><?php echo esc_html__('Add to album', 'furcifer'); ?><span class="material-icons arrow">keyboard_arrow_down</span></a> 
                    <div> 
                        <select id="imgur-add-to-album-select" class="palleon-select imgur-albums-select" autocomplete="off"></select>
                        <button id="imgur-add-to-album" type="button" class="palleon-btn btn-full primary"><span class="material-icons">add_circle</span><?php echo esc_html__('Add Images', 'furcifer'); ?></button>
                    </div> 
                </li> 
                <li>
                    <a href="#"><span class="material-icons accordion-icon">collections_bookmark</span><?php echo esc_html__('Create Album', 'furcifer'); ?><span class="material-icons arrow">keyboard_arrow_down</span></a> 
                    <div> 
                        <div class="palleon-control-wrap label-block">
                            <label class="palleon-control-label"><?php echo esc_html__('Title (Required)', 'furcifer'); ?></label>
                            <div class="palleon-control">
                                <input id="imgur-create-album-name" type="text" class="palleon-form-field" placeholder="<?php echo esc_html__('Enter title...', 'furcifer'); ?>" autocomplete="off" />
                            </div>
                        </div>
                        <button id="imgur-create-album" type="button" class="palleon-btn btn-full primary"><span class="material-icons">done</span><?php echo esc_html__('Create Album', 'furcifer'); ?></button>
                    </div>
                </li>
                <li>
                    <a href="#"><span class="material-icons accordion-icon">share</span><?php echo esc_html__('Share Album', 'furcifer'); ?><span class="material-icons arrow">keyboard_arrow_down</span></a> 
                    <div>
                        <select id="imgur-album-share-id" class="palleon-select imgur-albums-select" autocomplete="off"></select>
                        <div class="palleon-control-wrap label-block">
                            <label class="palleon-control-label"><?php echo esc_html__('Title (Required)', 'furcifer'); ?></label>
                            <div class="palleon-control">
                                <input id="imgur-album-share-title" class="palleon-form-field" type="text" value="" autocomplete="off">
                            </div>
                        </div>
                        <div class="palleon-control-wrap label-block">
                            <label class="palleon-control-label"><?php echo esc_html__('Topic Name', 'furcifer'); ?></label>
                            <div class="palleon-control">
                                <input id="imgur-album-share-topic" class="palleon-form-field" type="text" value="" autocomplete="off">
                            </div>
                        </div>
                        <div class="palleon-control-wrap label-block">
                            <label class="palleon-control-label"><?php echo esc_html__('Tags', 'furcifer'); ?></label>
                            <div class="palleon-control">
                                <input id="imgur-album-share-tags" class="palleon-form-field" type="text" value="" autocomplete="off">
                                <div class="palleon-control-desc">
                                    <?php echo esc_html__('You can add multiple tags separated by commas.', 'furcifer'); ?>
                                </div>
                            </div>
                        </div>
                        <button id="imgur-album-share" type="button" class="palleon-btn btn-full primary"><span class="material-icons">share</span><?php echo esc_html__('Share', 'furcifer'); ?></button>
                    </div>
                </li>
                <li>
                    <a href="#"><span class="material-icons accordion-icon">delete</span><?php echo esc_html__('Delete Album', 'furcifer'); ?><span class="material-icons arrow">keyboard_arrow_down</span></a> 
                    <div> 
                        <select id="imgur-delete-album-select" class="palleon-select imgur-albums-select" autocomplete="off"></select>
                        <button id="imgur-delete-album" type="button" class="palleon-btn btn-full danger"><span class="material-icons">delete</span><?php echo esc_html__('Delete Album', 'furcifer'); ?></button>
                    </div> 
                </li>
            </ul>
        </div>
    </div>
</div>