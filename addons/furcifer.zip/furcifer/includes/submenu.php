<ul class="palleon-tabs-menu">
    <li id="imgur-submenu-images" data-target="#imgur-images-tab" class="active"><span class="material-icons">collections</span><?php echo esc_html__('All Images', 'furcifer'); ?></li>
    <li id="imgur-submenu-albums" data-target="#imgur-albums-tab"><span class="material-icons">collections_bookmark</span><?php echo esc_html__('Albums', 'furcifer'); ?></li>
</ul>