<?php $perpage = PalleonSettings::get_option('imgur_pagination',18); ?>
<div id="imgur-images-tab" class="palleon-tab active">
    <div id="imgur-images-menu">
        <div>
            <form enctype="multipart/form-data">
                <div class="palleon-file-field">
                    <input type="file" name="imgur-upload-img" id="imgur-upload-img" class="palleon-hidden-file" accept="image/png, image/jpeg, image/webp" />
                    <label for="imgur-upload-img" class="palleon-btn primary"><span class="material-icons">upload</span><span><?php echo esc_html__('Upload Image', 'furcifer'); ?></span></label>
                </div>
            </form>
            <button id="imgur-images-refresh" type="button" class="palleon-btn primary imgur-images-refresh"><span class="material-icons">refresh</span><?php echo esc_html__('Refresh', 'furcifer'); ?></button>
        </div>
        <div class="palleon-search-box">
            <input type="search" class="palleon-form-field" placeholder="<?php echo esc_html__('Search by title...', 'furcifer'); ?>" autocomplete="off" />
            <button id="imgur-images-search" type="button" class="palleon-btn primary"><span class="material-icons">search</span></button>
        </div>
    </div>
    <div id="imgur-images-grid" class="palleon-grid media-library-grid paginated" data-perpage="<?php echo esc_attr($perpage); ?>"></div>
    <div id="imgur-images-grid-noimg" class="notice notice-warning d-none"><?php echo esc_html__('Nothing found.', 'furcifer'); ?></div>
</div>