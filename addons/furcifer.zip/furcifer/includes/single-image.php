<div id="furcifer-s-img-wrap">
    <div id="furcifer-s-img-content">
        <div id="furcifer-s-img-close"><span class="material-icons">close</span></div>
        <div id="furcifer-s-img-img"></div>
        <div id="furcifer-s-img-inner">
            <div id="furcifer-s-img-link">
                <input type="text" id="furcifer-img-link" class="palleon-form-field" autocomplete="off" value="" readonly />
                <button id="furcifer-img-link-copy" type="button" class="palleon-btn primary" title="<?php echo esc_attr__('Copy URL', 'furcifer'); ?>"><span class="material-icons">content_copy</span></button>
                <a id="furcifer-img-link-view" href="" type="button" class="palleon-btn primary" title="<?php echo esc_attr__('View on Imgur', 'furcifer'); ?>" target="_blank"><span class="material-icons">link</span></a>
            </div>
            <div id="furcifer-s-img-info"></div>
            <div id="furcifer-s-img-form">
                <div>
                    <label><?php echo esc_html__('Title:', 'furcifer'); ?></label>
                    <input type="text" id="furcifer-img-title" class="palleon-form-field" autocomplete="off" value="" />
                </div>
                <div>
                    <label><?php echo esc_html__('Description:', 'furcifer'); ?></label>
                    <textarea id="furcifer-img-desc" class="palleon-form-field" rows="2" autocomplete="off"></textarea>
                </div>
            </div>
            <div id="furcifer-img-btns">
                <button id="furcifer-img-delete" type="button" class="palleon-btn danger"><span class="material-icons">delete</span><?php echo esc_html__('Delete', 'furcifer'); ?></button>
                <button id="furcifer-img-update" type="button" class="palleon-btn primary"><span class="material-icons">save</span><?php echo esc_html__('Update', 'furcifer'); ?></button>
            </div>
            <ul class="palleon-accordion">
                <li>
                    <a href="#"><span class="material-icons accordion-icon">share</span><?php echo esc_html__('Share On Imgur', 'furcifer'); ?><span class="material-icons arrow">keyboard_arrow_down</span></a> 
                    <div>
                        <div class="palleon-control-wrap label-block">
                            <label class="palleon-control-label"><?php echo esc_html__('Title (Required)', 'furcifer'); ?></label>
                            <div class="palleon-control">
                                <input id="imgur-img-share-title" class="palleon-form-field" type="text" value="" autocomplete="off">
                            </div>
                        </div>
                        <div class="palleon-control-wrap label-block">
                            <label class="palleon-control-label"><?php echo esc_html__('Topic', 'furcifer'); ?></label>
                            <div class="palleon-control">
                                <input id="imgur-img-share-topic" class="palleon-form-field" type="text" value="" autocomplete="off">
                            </div>
                        </div>
                        <div class="palleon-control-wrap label-block">
                            <label class="palleon-control-label"><?php echo esc_html__('Tags', 'furcifer'); ?></label>
                            <div class="palleon-control">
                                <input id="imgur-img-share-tags" class="palleon-form-field" type="text" value="" autocomplete="off">
                                <div class="palleon-control-desc">
                                    <?php echo esc_html__('You can add multiple tags separated by commas.', 'furcifer'); ?>
                                </div>
                            </div>
                        </div>
                        <button id="imgur-img-share" type="button" class="palleon-btn btn-full primary"><span class="material-icons">share</span><?php echo esc_html__('Share', 'furcifer'); ?></button>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>