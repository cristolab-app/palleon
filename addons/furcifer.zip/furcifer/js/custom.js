function furcifer(selector, canvas, lazyLoadInstance) {
    "use strict";
    // Variables
    var accessToken = '';
    var clientID = '';
    var clientSecret = '';
    var apiURL = furciferParams.apiUrl;
    var rapidApiKey = furciferParams.rapidApiKey;
    var images = '';
    var albums = '';
    var imgID = '';

    // Rate Limits
    function furcifer_rate_limits(xhr) {
        console.log('X-RateLimit-UserLimit: ' + xhr.getResponseHeader("X-RateLimit-UserLimit"));
        console.log('X-RateLimit-UserRemaining: ' + xhr.getResponseHeader("X-RateLimit-UserRemaining"));
        console.log('X-RateLimit-ClientLimit: ' + xhr.getResponseHeader("X-RateLimit-ClientLimit"));
        console.log('X-RateLimit-ClientRemaining: ' + xhr.getResponseHeader("X-RateLimit-ClientRemaining"));
    }

    // Format bytes
    function furcifer_format_bytes(bytes) {
        var marker = 1024; // Change to 1000 if required
        var decimal = 2; // Change as required
        var megaBytes = marker * marker; // One MB is 1024 KB
        var gigaBytes = marker * marker * marker; // One GB is 1024 MB
      
        // return bytes if less than a KB
        if(bytes < gigaBytes) return(bytes / megaBytes).toFixed(decimal) + " MB";
        // return GB if less than a TB
        else return(bytes / gigaBytes).toFixed(decimal) + " GB";
    }

    // Convert to data url
    function furcifer_dataURL(url, callback) {
        var xhr = new XMLHttpRequest();
        xhr.onload = function() {
          var reader = new FileReader();
          reader.onloadend = function() {
            callback(reader.result);
          };
          reader.readAsDataURL(xhr.response);
        };
        xhr.open('GET', url);
        xhr.responseType = 'blob';
        xhr.send();
    }

    // Set pagination
    function furcifer_pagination(target) {
        var items = target.find('>*');
        var num = items.length;
        var perPage = parseInt(target.data('perpage'));
        if (num > perPage) {
            items.slice(perPage).hide();
            var paginationDiv = '<div id="' + target.attr('id') + '-pagination' + '" class="palleon-pagination"></div>';
            target.after(paginationDiv);
            selector.find('#' + target.attr('id') + '-pagination').pagination({
                items: num,
                itemsOnPage: perPage,
                prevText: '<span class="material-icons">navigate_before</span>',
                nextText: '<span class="material-icons">navigate_next</span>',
                displayedPages: 3,
                onPageClick: function (pageNumber, event) {
                    if (typeof event !== "undefined") {
                        event.preventDefault();
                    }
                    var showFrom = perPage * (pageNumber - 1);
                    var showTo = showFrom + perPage;
                    items.hide().slice(showFrom, showTo).show();
                }
            });
            selector.find('#' + target.attr('id') + '-pagination').pagination('selectPage', 1);
        }
    }

    // Get Client ID and Secret
    function furcifer_client() {
        var data = {
            'action': 'furciferClient',
            'nonce': palleonParams.nonce
        };
        $.ajax({
            url : palleonParams.ajaxurl,
            data : data,
            type : "POST",
            success: function(data, status, xhr){
                if(data) {
                    data = $.parseJSON(data);
                    if (data.message !== undefined) {
                        // toastr.error(data.message, palleonParams.error);
                    } else {
                        clientID = data.id;
                        clientSecret = data.secret;
                    }
                }
            },
            error: function(jqXHR,error, errorThrown) {
                if(jqXHR.status&&jqXHR.status==400){
                    console.log(jqXHR.responseText);
                }else{
                    console.log(palleonParams.wrong);
                }
        },
        }).done(function() {
            if (clientID == '' && clientSecret == '') {
                // toastr.error(furciferParams.noClient, palleonParams.error);
            }
        });
    }

    // Get account albums
    function furcifer_albums(selected) {
        var headers = {
            "Authorization": "Bearer " + accessToken
        };
        if (rapidApiKey != '') {
            headers = {
                "Authorization": accessToken,
                'X-RapidAPI-Key': rapidApiKey,
                'X-RapidAPI-Host': 'imgur-apiv3.p.rapidapi.com'
            };
        }
        var form = new FormData();
        $.ajax({
            url : apiURL + "3/account/me/albums",
            type : "GET",
            timeout: 0,
            cache: false,
            crossDomain: true,
            headers: headers,
            processData: false,
            mimeType: "multipart/form-data",
            contentType: false,
            data: form,
            success: function(data, status, xhr){
                albums = $.parseJSON(data);
                if (albums.data !== undefined && albums.data != null && albums.data != []) {
                    var output = '<option value="">' + furciferParams.selectAlbum + '</option>';
                    $.each(albums.data, function(index, val) {
                        var id = val.id;
                        var title = val.title;
                        var count = val.images_count;
                        if (title === null) {
                            title = furciferParams.notitle;
                        }
                        if (selected == id) {
                            output += '<option value="' + id + '" selected>' + title + ' (' + count + ')</option>';
                        } else {
                            output += '<option value="' + id + '">' + title + ' (' + count + ')</option>';
                        }
                    });
                    selector.find('.imgur-albums-select').each(function() {
                        $(this).html(output);
                        if( $(this).attr('id') != 'imgur-albums-select') {
                            $(this).val('');
                        }
                    });
                } else {
                    selector.find('.imgur-albums-select').each(function() {
                        $(this).html('<option value="" selected>' + furciferParams.selectAlbum + '</option>');
                    });
                }
                furcifer_rate_limits(xhr);
            },
            error: function(jqXHR,error, errorThrown) {
                if (jqXHR.statusText == 'error' && jqXHR.responseText != null && jqXHR.responseText != '') {
                    var response = $.parseJSON(jqXHR.responseText);
                    var errorText = response.data.error;
                    toastr.error(errorText, jqXHR.status + ' ' + palleonParams.error);
                } else{
                    toastr.error(palleonParams.wrong, palleonParams.error);
                }
            },
        });
    }

    // Get Album Images
    function furcifer_album_images(album) {
        if (album != '') {
            var headers = {
                "Authorization": "Bearer " + accessToken
            };
            if (rapidApiKey != '') {
                headers = {
                    "Authorization": accessToken,
                    'X-RapidAPI-Key': rapidApiKey,
                    'X-RapidAPI-Host': 'imgur-apiv3.p.rapidapi.com'
                };
            }
            var form = new FormData();
            $.ajax({
                url : apiURL + "3/account/me/album/" + album,
                type : "GET",
                timeout: 0,
                cache: false,
                crossDomain: true,
                headers: headers,
                processData: false,
                mimeType: "multipart/form-data",
                contentType: false,
                data: form,
                success: function(data, status, xhr){
                    var albumData = $.parseJSON(data);
                    var albumImages = albumData.data.images;
                    if (albumImages !== undefined && albumImages != null && albumImages != []) {
                        selector.find("#imgur-albums-noimg").addClass('d-none');
                        var albumsOutput = '';
                        for (let i = 0; i < albumImages.length; ++i) {
                            var id = albumImages[i].id;
                            var imgType = albumImages[i].type;
                            var title = albumImages[i].title;
                            if (title === null) {
                                title = '';
                            }
                            var thumbnail = albumImages[i].link.replace(id, id + 'b');
                            if (imgType == 'image/jpeg' || imgType == 'image/jpg' || imgType == 'image/png' || imgType == 'image/webp') {
                                albumsOutput += '<li><div><label class="palleon-checkbox"><input class="imgur-selected-img" type="checkbox" value="' + id + '" autocomplete="off"><span class="palleon-checkmark"></span></label><img src="' + thumbnail + '" data-id="' + id + '" class="imgur-select-img" /></div><div><button type="button" class="palleon-btn danger imgur-remove-from-album" data-id="' + id + '" data-album="' + album + '"><span class="material-icons">clear</span>' + furciferParams.remove + '</button><button type="button" class="palleon-btn primary imgur-open-image" data-id="' + id + '"><span class="material-icons">edit</span>' + furciferParams.edit + '</button></div></li>';
                            }
                        }
                        selector.find('#imgur-albums-images-pagination').remove();
                        selector.find('#imgur-albums-images').html(albumsOutput);
                        furcifer_pagination(selector.find('#imgur-albums-images'));

                        lazyLoadInstance.update();
                    } else {
                        selector.find('#imgur-albums-images-pagination').remove();
                        selector.find('#imgur-albums-images').html('');
                        selector.find("#imgur-albums-noimg").removeClass('d-none');
                    }
                    furcifer_rate_limits(xhr);
                },
                error: function(jqXHR,error, errorThrown) {
                    if (jqXHR.statusText == 'error' && jqXHR.responseText != null && jqXHR.responseText != '') {
                        var response = $.parseJSON(jqXHR.responseText);
                        var errorText = response.data.error;
                        toastr.error(errorText, jqXHR.status + ' ' + palleonParams.error);
                    } else{
                        toastr.error(palleonParams.wrong, palleonParams.error);
                    }
                },
            });
        } else {
            furcifer_images();
        }
    }

    // Get account images
    function furcifer_images() {
        var headers = {
            "Authorization": "Bearer " + accessToken
        };
        if (rapidApiKey != '') {
            headers = {
                "Authorization": accessToken,
                'X-RapidAPI-Key': rapidApiKey,
                'X-RapidAPI-Host': 'imgur-apiv3.p.rapidapi.com'
            };
        }
        var form = new FormData();
        $.ajax({
            url : apiURL + "3/account/me/images",
            type : "GET",
            timeout: 0,
            cache: false,
            crossDomain: true,
            headers: headers,
            processData: false,
            mimeType: "multipart/form-data",
            contentType: false,
            data: form,
            success: function(data, status, xhr){
                images = $.parseJSON(data);
                if (images.data !== undefined && images.data != null && images.data != []) {
                    // All Images
                    selector.find("#imgur-images-grid-noimg").addClass('d-none');
                    var imgsOutput = '';
                    var imgCheck = false;
                    $.each(images.data, function(index, val) {
                        var id = val.id;
                        var imgType = val.type;
                        var title = val.title;
                        if (title === null) {
                            title = '';
                        }
                        var link = val.link;
                        var thumbnail = val.link.replace(id, id + 'b');
                        if (imgType == 'image/jpeg' || imgType == 'image/jpg' || imgType == 'image/png' || imgType == 'image/webp') {
                            imgCheck = true;
                            imgsOutput += '<div class="palleon-masonry-item" data-keyword="' + title.toLowerCase().replace(/\s/g,' ') + '"><div class="imgur-edit-icon imgur-open-image" title="' + furciferParams.editImg + '" data-id="' + id + '"><span class="material-icons">edit</span></div><div class="palleon-masonry-item-inner"><div class="palleon-img-wrap"><div class="palleon-img-loader"></div><img id="imgur-img-' + id + '" class="lazy" data-src="' + thumbnail + '" data-full="' + link + '" data-id="' + id + '" data-filename="' + id + '" title="' + title + '" /></div>';
                            if (title != '') {
                                imgsOutput += '<div class="palleon-masonry-item-desc">' + title + '</div>';
                            }
                            imgsOutput += '</div></div>';
                        }
                    });
                    selector.find('#imgur-images-grid-pagination').remove();
                    if (imgCheck) {
                        selector.find('#imgur-images-grid').html(imgsOutput);
                        furcifer_pagination(selector.find('#imgur-images-grid'));
                    } else {
                        selector.find('#imgur-images-grid').html('');
                        selector.find("#imgur-images-grid-noimg").removeClass('d-none');
                    }

                    // Album Images
                    selector.find("#imgur-albums-noimg").addClass('d-none');
                    var albumsOutput = '';
                    $.each(images.data, function(index, val) {
                        var id = val.id;
                        var imgType = val.type;
                        var title = val.title;
                        if (title === null) {
                            title = '';
                        }
                        var thumbnail = val.link.replace(id, id + 'b');
                        if (imgType == 'image/jpeg' || imgType == 'image/jpg' || imgType == 'image/png' || imgType == 'image/webp') {
                            albumsOutput += '<li><div><label class="palleon-checkbox"><input class="imgur-selected-img" type="checkbox" value="' + id + '" autocomplete="off"><span class="palleon-checkmark"></span></label><img src="' + thumbnail + '" data-id="' + id + '" class="imgur-select-img" /></div><div><button type="button" class="palleon-btn primary imgur-open-image" data-id="' + id + '"><span class="material-icons">edit</span>' + furciferParams.edit + '</button></div></li>';
                        }
                    });
                    selector.find('#imgur-albums-images-pagination').remove();
                    if (imgCheck) {
                        selector.find('#imgur-albums-images').html(albumsOutput);
                        furcifer_pagination(selector.find('#imgur-albums-images'));
                    } else {
                        selector.find('#imgur-albums-images').html('');
                        selector.find("#imgur-albums-noimg").removeClass('d-none');
                    }
                    if (imgCheck) {
                        lazyLoadInstance.update();
                    }
                } else {
                    selector.find('#imgur-images-grid').html('');
                    selector.find('#imgur-albums-images').html('');
                    selector.find("#imgur-images-grid-noimg").removeClass('d-none');
                    selector.find("#imgur-albums-noimg").removeClass('d-none');
                }
                furcifer_rate_limits(xhr);
            },
            error: function(jqXHR,error, errorThrown) {
                if (jqXHR.statusText == 'error' && jqXHR.responseText != null && jqXHR.responseText != '') {
                    var response = $.parseJSON(jqXHR.responseText);
                    var errorText = response.data.error;
                    toastr.error(errorText, jqXHR.status + ' ' + palleonParams.error);
                } else{
                    toastr.error(palleonParams.wrong, palleonParams.error);
                }
            },
        });
    }

    // Get Filestack API Key
    function get_filestack_api_key() {
        var data = {
            'action': 'filestackApiKey',
            'nonce': palleonParams.nonce
        };
        $.ajax({
            url : palleonParams.ajaxurl,
            data : data,
            type : "POST",
            success: function(data, status, xhr){
                if(data) {
                    filestack_init(data);
                }
            },
            error: function(jqXHR,error, errorThrown) {
                if(jqXHR.status&&jqXHR.status==400){
                    console.log(jqXHR.responseText);
                }else{
                    console.log(palleonParams.wrong);
                }
            },
        });
    }

    function filestack_init(data) {
        var sources = new Array();
        sources = furciferParams.filestackServices.split(",");
        var maxSize = parseInt(furciferParams.filestackMaxSize);
        const client = filestack.init(data);
        const options = {
            disableTransformer: true,
            displayMode: 'inline',
            container: $('#filestack-new')[0],
            maxFiles: 1,
            accept: [".jpeg",".png",".webp",".jpg"],
            fromSources: sources,
            onUploadDone: response => {
                if (response.filesUploaded != []) {
                    var url = response.filesUploaded[0].url;
                    furcifer_dataURL(url, function(dataUrl) {
                        $(document).trigger( "loadImgURL", [dataUrl, ''] );
                        selector.find('#modal-media-library').hide();
                    });
                } else {
                    toastr.error(furciferParams.uploadFail, palleonParams.error);
                }
            },
            onFileSelected: file => {
                if (file.size > maxSize * maxSize) {
                    throw new Error(furciferParams.tooBig);
                }
            }
        };  
        client.picker(options).open();
    }

    // The access token is returned to the plugin in the fragment as part of the access_token parameter. If the url contains hash, parse the response and returns the parameters to the server.
    if(window.location.hash) {
        $('body').prepend('<div id="imgur-loader" class="palleon-loader-wrap"><div class="palleon-loader-inner"><div class="palleon-loader"></div></div></div>');
        var params = {}, queryString = location.hash.substring(1),
        regex = /([^&=]+)=([^&]*)/g, m;
        while (m == regex.exec(queryString)) {
        params[decodeURIComponent(m[1])] = decodeURIComponent(m[2]);
        }
        var redirect = location.href.replace(location.hash,"");

        var req = new XMLHttpRequest();
        req.open("POST", redirect + '&' + queryString, true);
        req.onreadystatechange = function (e) {
        if (req.readyState == 4) {
            if(req.status == 200){
                window.location = redirect + '&' + queryString;
            } else {
                toastr.error(palleonParams.wrong, palleonParams.error);
            }
        }
        };
        req.send(null);
    } else {
        furcifer_client();
        get_filestack_api_key();

        // Authorization
        selector.find('#modal-imgur').on('click','#imgur-authorization',function(){
            if (clientID != '') {
                var url = 'https://api.imgur.com/oauth2/authorize?client_id=' + clientID + '&response_type=token';
                window.location.href = url;
            } else {
                toastr.error(furciferParams.noClient, palleonParams.error);
            }
        });

        // Re-authorization
        selector.find('#modal-imgur').on('click','#imgur-login-info',function(){
            var btn = $(this);
            var msg = btn.html();
            var data = {
                'action': 'furciferDeleteToken',
                'nonce': palleonParams.nonce
            };
            $.ajax({
                url : palleonParams.ajaxurl,
                data : data,
                type : "POST",
                beforeSend: function () {
                    btn.html(furciferParams.wait);
                },
                success: function(data, status, xhr){
                    if (data == 'done') {
                        location.reload();
                    } else {
                        toastr.error(palleonParams.wrong, palleonParams.error);
                    }
                },
                error: function(jqXHR,error, errorThrown) {
                    if(jqXHR.status){
                        toastr.error(palleonParams.wrong, jqXHR.status + ' ' + palleonParams.error);
                    }else{
                        toastr.error(palleonParams.wrong, palleonParams.error);
                    }
                },
            }).done(function() {
                btn.html(msg);
            });
        });

        // Get the access token and login to Imgur
        selector.find('#modal-imgur').on('click','#imgur-login',function(){
            var btn = $(this);
            var formdata = new FormData();
            var refreshToken = $(this).attr('data-token');
            btn.prop('disabled', true);
            formdata.append("refresh_token", refreshToken);
            formdata.append("client_id", clientID);
            formdata.append("client_secret", clientSecret);
            formdata.append("grant_type", "refresh_token");

            var requestOptions = {
                method: "POST",
                body: formdata,
                redirect: 'follow'
            };

            fetch("https://api.imgur.com/oauth2/token", requestOptions).then(response => response.text()).then(result => {
                var data = $.parseJSON(result);
                accessToken = data.access_token;
                var formdata = {
                    'action': 'furciferUpdateToken',
                    'token': refreshToken,
                    'nonce': palleonParams.nonce
                };
                $.ajax({
                    url : palleonParams.ajaxurl,
                    data : formdata,
                    type : "POST",
                    success: function(data, status, xhr){
                        if (data == 'done') {
                            furcifer_images();
                            furcifer_albums('');
                            selector.find('#imgur-login').remove();
                            selector.find('#imgur-login-info').remove();
                            selector.find('#modal-imgur .palleon-tabs').removeClass('imgur-hide');
                            selector.find('#palleon-save-to-imgur').removeClass('d-none');
                        } else {
                            toastr.error(palleonParams.wrong, palleonParams.error);
                        }
                    },
                    error: function(jqXHR,error, errorThrown) {
                        if(jqXHR.status){
                            toastr.error(palleonParams.wrong, jqXHR.status + ' ' + palleonParams.error);
                        }else{
                            toastr.error(palleonParams.wrong, palleonParams.error);
                        }
                        btn.prop('disabled', false);
                    },
                });
            }).catch(error => console.log('error', error));
        });

        // Load album images
        selector.find('#imgur-albums-select-btn').on('click', function () {
            var val = selector.find('#imgur-albums-select').find(":selected").val();
            furcifer_album_images(val);
        });

        // Create Album
        selector.find('#imgur-create-album').on('click', function () {
            var btn = $(this);
            var title = selector.find('#imgur-create-album-name').val();
            if (title == '') {
                toastr.warning(furciferParams.titleRequired, palleonParams.warning);
                return;
            }
            var headers = {
                "Authorization": "Bearer " + accessToken
            };
            if (rapidApiKey != '') {
                headers = {
                    "Authorization": accessToken,
                    'X-RapidAPI-Key': rapidApiKey,
                    'X-RapidAPI-Host': 'imgur-apiv3.p.rapidapi.com'
                };
            }
            var form = new FormData();
            form.append("title", title);
            var imgCheck = false;
            selector.find('.imgur-selected-img').each(function() {
                if ($(this).is(':checked')) {
                    form.append("ids[]", $(this).val());
                    imgCheck = true;
                }
            });
            if (imgCheck) {  
                selector.find('.imgur-selected-img').each(function() {
                    if ($(this).is(':checked')) {
                        form.append("cover", $(this).val());
                        return false;
                    }
                });
                $.ajax({
                    url : apiURL + "3/album/",
                    type : "POST",
                    timeout: 0,
                    cache: false,
                    crossDomain: true,
                    headers: headers,
                    processData: false,
                    mimeType: "multipart/form-data",
                    contentType: false,
                    data: form,
                    beforeSend: function () {
                        btn.prop('disabled', true);
                    },
                    success: function(data, status, xhr){
                        selector.find('#imgur-create-album-name').val('');
                        furcifer_albums('');
                        toastr.success(furciferParams.albumCreated, palleonParams.success);
                    },
                    error: function(jqXHR,error, errorThrown) {
                        if (jqXHR.statusText == 'error' && jqXHR.responseText != null && jqXHR.responseText != '') {
                            var response = $.parseJSON(jqXHR.responseText);
                            var errorText = response.data.error;
                            toastr.error(errorText, jqXHR.status + ' ' + palleonParams.error);
                        } else{
                            toastr.error(palleonParams.wrong, palleonParams.error);
                        }
                        btn.prop('disabled', false);
                    },
                }).done(function() {
                    selector.find('.imgur-selected-img').each(function() {
                        $(this).prop( "checked", false );
                    });
                    btn.prop('disabled', false);
                });
            } else {
                toastr.warning(furciferParams.imgRequired, palleonParams.warning);
            }
        });

        // Add Images To Album
        selector.find('#imgur-add-to-album').on('click', function () {
            var btn = $(this).parent().find('input');
            var albumID = selector.find('#imgur-add-to-album-select').find(":selected").val();
            var form = new FormData();
            var imgCheck = false;
            selector.find('.imgur-selected-img').each(function() {
                if ($(this).is(':checked')) {
                    form.append("ids[]", $(this).val());
                    imgCheck = true;
                }
            });
            if (albumID == '') {
                toastr.warning(furciferParams.albumRequired, palleonParams.warning);
                return;
            }
            if (imgCheck) {
                var headers = {
                    "Authorization": "Bearer " + accessToken
                };
                if (rapidApiKey != '') {
                    headers = {
                        "Authorization": accessToken,
                        'X-RapidAPI-Key': rapidApiKey,
                        'X-RapidAPI-Host': 'imgur-apiv3.p.rapidapi.com'
                    };
                }
                $.ajax({
                    url : apiURL + "3/album/" + albumID + '/add',
                    type : "POST",
                    timeout: 0,
                    cache: false,
                    crossDomain: true,
                    headers: headers,
                    processData: false,
                    mimeType: "multipart/form-data",
                    contentType: false,
                    data: form,
                    beforeSend: function () {
                        btn.prop('disabled', true);
                    },
                    success: function(data, status, xhr){
                        selector.find('#imgur-add-to-album-select').val('');
                        furcifer_albums('');
                        toastr.success(furciferParams.imagesAdded, palleonParams.success);
                    },
                    error: function(jqXHR,error, errorThrown) {
                        if (jqXHR.statusText == 'error' && jqXHR.responseText != null && jqXHR.responseText != '') {
                            var response = $.parseJSON(jqXHR.responseText);
                            var errorText = response.data.error;
                            toastr.error(errorText, jqXHR.status + ' ' + palleonParams.error);
                        } else{
                            toastr.error(palleonParams.wrong, palleonParams.error);
                        }
                        btn.prop('disabled', false);
                    },
                }).done(function() {
                    selector.find('#imgur-albums-select-btn').trigger('click');
                    btn.prop('disabled', false);
                });
            } else {
                toastr.warning(furciferParams.imgRequired, palleonParams.warning);
            }   
        });

        // Delete Album Form
        selector.find('#imgur-delete-album').on('click', function () {
            var btn = $(this);
            var albumID = selector.find('#imgur-delete-album-select').find(":selected").val();
            if (albumID == '') {
                toastr.warning(furciferParams.albumRequired, palleonParams.warning);
                return;
            }
            var headers = {
                "Authorization": "Bearer " + accessToken
            };
            if (rapidApiKey != '') {
                headers = {
                    "Authorization": accessToken,
                    'X-RapidAPI-Key': rapidApiKey,
                    'X-RapidAPI-Host': 'imgur-apiv3.p.rapidapi.com'
                };
            }
            var form = new FormData();
            $.ajax({
                url : apiURL + "3/account/me/album/" + albumID,
                type : "DELETE",
                timeout: 0,
                cache: false,
                crossDomain: true,
                headers: headers,
                processData: false,
                mimeType: "multipart/form-data",
                contentType: false,
                data: form,
                beforeSend: function () {
                    btn.prop('disabled', true);
                },
                success: function(data, status, xhr){
                    selector.find('#imgur-delete-album-select').val('');
                    furcifer_albums('');
                    toastr.success(furciferParams.albumDeleted, palleonParams.success);
                },
                error: function(jqXHR,error, errorThrown) {
                    if (jqXHR.statusText == 'error' && jqXHR.responseText != null && jqXHR.responseText != '') {
                        var response = $.parseJSON(jqXHR.responseText);
                        var errorText = response.data.error;
                        toastr.error(errorText, jqXHR.status + ' ' + palleonParams.error);
                    } else{
                        toastr.error(palleonParams.wrong, palleonParams.error);
                    }
                    btn.prop('disabled', false);
                },
            }).done(function() {
                selector.find('#imgur-albums-select').val('');
                furcifer_album_images('');
            });
        });

        // Delete Album Image
        selector.find('#modal-imgur').on('click','.imgur-remove-from-album',function(){
            var btn = $(this);
            var li = btn.parent().parent();
            var album = btn.attr('data-album');
            li.remove();
            var headers = {
                "Authorization": "Bearer " + accessToken
            };
            if (rapidApiKey != '') {
                headers = {
                    "Authorization": accessToken,
                    'X-RapidAPI-Key': rapidApiKey,
                    'X-RapidAPI-Host': 'imgur-apiv3.p.rapidapi.com'
                };
            }
            var form = new FormData();
            var imgCheck = false;
            $('#imgur-albums-images').find('.imgur-remove-from-album').each(function() {
                form.append("ids[]", $(this).attr('data-id'));
                    imgCheck = true;
            });
            if (imgCheck) {
                selector.find("#imgur-albums-noimg").addClass('d-none');
            } else {
                selector.find("#imgur-albums-noimg").removeClass('d-none');
            }
            $.ajax({
                url : apiURL + "3/album/" + album,
                type : "POST",
                timeout: 0,
                cache: false,
                crossDomain: true,
                headers: headers,
                processData: false,
                mimeType: "multipart/form-data",
                contentType: false,
                data: form,
                beforeSend: function () {
                    selector.find('#modal-imgur .imgur-remove-from-album').prop('disabled', true);
                },
                success: function(data, status, xhr){
                    selector.find('#imgur-albums-select').val(album);
                    furcifer_albums(album);
                    toastr.success(furciferParams.imageRemoved, palleonParams.success);
                },
                error: function(jqXHR,error, errorThrown) {
                    if (jqXHR.statusText == 'error' && jqXHR.responseText != null && jqXHR.responseText != '') {
                        var response = $.parseJSON(jqXHR.responseText);
                        var errorText = response.data.error;
                        toastr.error(errorText, jqXHR.status + ' ' + palleonParams.error);
                    } else{
                        toastr.error(palleonParams.wrong, palleonParams.error);
                    }
                    selector.find('#modal-imgur .imgur-remove-from-album').prop('disabled', false);
                },
            }).done(function() {
                selector.find('#imgur-albums-images-pagination').remove();
                furcifer_pagination(selector.find('#imgur-albums-images'));
                selector.find('#modal-imgur .imgur-remove-from-album').prop('disabled', false);
            });
        });

        // Share Album
        selector.find('#imgur-album-share').on('click', function () {
            var btn = $(this);
            var title = selector.find('#imgur-album-share-title').val();
            var topic = selector.find('#imgur-album-share-topic').val();
            var tags = selector.find('#imgur-album-share-tags').val();
            var album = selector.find('#imgur-album-share-id').find(":selected").val();
            if (title == '') {
                toastr.warning(furciferParams.titleRequired, palleonParams.error);
                return;
            } else if (album == '') {
                toastr.warning(furciferParams.albumRequired, palleonParams.warning);
                return;
            }
            var headers = {
                "Authorization": "Bearer " + accessToken
            };
            if (rapidApiKey != '') {
                headers = {
                    "Authorization": accessToken,
                    'X-RapidAPI-Key': rapidApiKey,
                    'X-RapidAPI-Host': 'imgur-apiv3.p.rapidapi.com'
                };
            }
            var form = new FormData();
            form.append("title", title);
            if (topic != '') {
                form.append("topic", topic);
            }
            if (tags != '') {
                form.append("tags", tags.trim());
            }
            form.append("terms", "1");
            $.ajax({
                url : apiURL + "3/gallery/album/" + album,
                type : "POST",
                timeout: 0,
                crossDomain: true,
                headers: headers,
                processData: false,
                mimeType: "multipart/form-data",
                contentType: false,
                data: form,
                beforeSend: function () {
                    btn.prop('disabled', true);
                },
                success: function(data, status, xhr){
                    toastr.success(furciferParams.published + ' <a href="https://imgur.com/gallery/' + album + '" target="_blank">' + furciferParams.viewGallery + '</a>', palleonParams.success);
                    furcifer_rate_limits(xhr);
                },
                error: function(jqXHR,error, errorThrown) {
                    if (jqXHR.statusText == 'error' && jqXHR.responseText != null && jqXHR.responseText != '') {
                        var response = $.parseJSON(jqXHR.responseText);
                        var errorText = response.data.error;
                        toastr.error(errorText, jqXHR.status + ' ' + palleonParams.error);
                    } else{
                        toastr.error(palleonParams.wrong, palleonParams.error);
                    }
                    btn.prop('disabled', false);
                },
            }).done(function() {
                btn.prop('disabled', false);
            });
        });

        // Select Image
        selector.find('#modal-imgur').on('click','.imgur-select-img',function(){
            var id = '#imgur-img-' + $(this).attr('data-id');
            $(id).trigger('click');
        });

        // Refresh Images
        selector.find('#modal-imgur').on('click','.imgur-images-refresh',function(){
            furcifer_images();
            furcifer_albums('');
        });

        // Upload Image
        selector.find('#modal-imgur').on('change','#imgur-upload-img',function(){
            var input = $(this).parent();
            if ($(this).val() == '') {
                return;
            }
            var headers = {
                "Authorization": "Bearer " + accessToken
            };
            if (rapidApiKey != '') {
                headers = {
                    "Authorization": accessToken,
                    'X-RapidAPI-Key': rapidApiKey,
                    'X-RapidAPI-Host': 'imgur-apiv3.p.rapidapi.com'
                };
            }
            var reader = new FileReader();
            reader.onload = function() {
                var file_data = reader.result.split(',')[1];
                var form = new FormData();
                form.append('image', file_data);
                form.append('type', 'base64');
                $.ajax({
                    url : apiURL + "3/image",
                    type : "POST",
                    timeout: 0,
                    crossDomain: true,
                    headers: headers,
                    processData: false,
                    mimeType: "multipart/form-data",
                    contentType: false,
                    data: form,
                    beforeSend: function () {
                        input.css('opacity', 0.7);
                        input.css('pointer-events', 'none');
                    },
                    success: function(data, status, xhr){
                        toastr.success(palleonParams.uploaded, palleonParams.success);
                        selector.find('#imgur-images-refresh').trigger('click');
                    },
                    error: function(jqXHR,error, errorThrown) {
                        if(jqXHR.status){
                            toastr.error(palleonParams.wrong, jqXHR.status + ' ' + palleonParams.error);
                        }else{
                            toastr.error(palleonParams.wrong, palleonParams.error);
                        }
                        input.css('opacity', 1);
                        input.css('pointer-events', 'auto');
                    },
                }).done(function() {
                    input.css('opacity', 1);
                    input.css('pointer-events', 'auto');
                });
            };
            reader.readAsDataURL(this.files[0]);  
        });

        // Save Image
        selector.find('#modal-save').on('click','#palleon-imgur-save',function(){
            var btn = $(this);
            var name = selector.find('#palleon-imgur-save-name').val();
            var album = selector.find('#palleon-imgur-save-album').val();
            var format = selector.find('#palleon-imgur-save-img-format').val();
            var imgData = canvas.toDataURL({ format: format, enableRetinaScaling: false});
            imgData = imgData.replace("data:image/" + format + ";base64,", "");   
            var headers = {
                "Authorization": "Bearer " + accessToken
            };
            if (rapidApiKey != '') {
                headers = {
                    "Authorization": accessToken,
                    'X-RapidAPI-Key': rapidApiKey,
                    'X-RapidAPI-Host': 'imgur-apiv3.p.rapidapi.com'
                };
            }
            var form = new FormData();
            form.append('name', name);
            form.append('image', imgData);
            form.append('type', 'base64');
            if (album != '') {
                form.append('album', album);
            }
            $.ajax({
                url : apiURL + "3/image",
                type : "POST",
                timeout: 0,
                crossDomain: true,
                headers: headers,
                processData: false,
                mimeType: "multipart/form-data",
                contentType: false,
                data: form,
                beforeSend: function () {
                    btn.prop('disabled', true);
                },
                success: function(data, status, xhr){
                    toastr.success(palleonParams.imgsaved, palleonParams.success);
                    selector.find('#imgur-images-refresh').trigger('click');
                },
                error: function(jqXHR,error, errorThrown) {
                    if(jqXHR.status){
                        toastr.error(palleonParams.wrong, jqXHR.status + ' ' + palleonParams.error);
                    }else{
                        toastr.error(palleonParams.wrong, palleonParams.error);
                    }
                    btn.prop('disabled', false);
                },
            }).done(function() {
                btn.prop('disabled', false);
            });
        });

        /* Image Search */
        selector.find('#imgur-images-search').on('click', function () {
            var input = $(this).parent().find('input');
            selector.find("#imgur-images-grid-noimg").addClass('d-none');
            if (input.val() == '') {
                return;
            }
            if ($(this).hasClass('cancel')) {
                $(this).removeClass('cancel');
                $(this).find('.material-icons').html('search');
                $(this).removeClass('danger');
                $(this).addClass('primary');
                input.val('');
                selector.find('#imgur-images-grid .palleon-masonry-item').show();
                if (selector.find('#imgur-images-grid-pagination').length) {
                    selector.find('#imgur-images-grid-pagination').pagination('redraw');
                    selector.find('#imgur-images-grid-pagination').pagination('selectPage', 1);
                }
                input.prop('disabled', false);
            } else {
                $(this).addClass('cancel');
                $(this).find('.material-icons').html('close');
                $(this).removeClass('primary');
                $(this).addClass('danger');
                var searchTerm = input.val().toLowerCase().replace(/\s/g,' ');
                if ((searchTerm == '' || searchTerm.length < 1)) {
                    selector.find('#imgur-images-grid .palleon-masonry-item').show();
                    if (selector.find('#imgur-images-grid-pagination').length) {
                        selector.find('#imgur-images-grid-pagination').pagination('redraw');
                        selector.find('#imgur-images-grid-pagination').pagination('selectPage', 1);
                    }
                } else {
                    if (selector.find('#imgur-images-grid-pagination').length) {
                        selector.find('#imgur-images-grid-pagination').pagination('destroy');
                    }
                    selector.find('#imgur-images-grid .palleon-masonry-item').hide().filter('[data-keyword*="'+ searchTerm +'"]').show();
                    if (selector.find('#imgur-images-grid .palleon-masonry-item:visible').length === 0) {
                        selector.find("#imgur-images-grid-noimg").removeClass('d-none');
                    }
                }
                input.prop('disabled', true);
            }
        });

        // Share Image
        selector.find('#imgur-img-share').on('click', function () {
            var btn = $(this);
            var title = selector.find('#imgur-img-share-title').val();
            var topic = selector.find('#imgur-img-share-topic').val();
            var tags = selector.find('#imgur-img-share-tags').val();
            if (title == '') {
                toastr.warning(furciferParams.titleRequired, palleonParams.error);
                return;
            }
            var headers = {
                "Authorization": "Bearer " + accessToken
            };
            if (rapidApiKey != '') {
                headers = {
                    "Authorization": accessToken,
                    'X-RapidAPI-Key': rapidApiKey,
                    'X-RapidAPI-Host': 'imgur-apiv3.p.rapidapi.com'
                };
            }
            var form = new FormData();
            form.append("title", title);
            if (topic != '') {
                form.append("topic", topic);
            }
            if (tags != '') {
                form.append("tags", tags.trim());
            }
            form.append("terms", "1");
            $.ajax({
                url : apiURL + "3/gallery/image/" + imgID,
                type : "POST",
                timeout: 0,
                crossDomain: true,
                headers: headers,
                processData: false,
                mimeType: "multipart/form-data",
                contentType: false,
                data: form,
                beforeSend: function () {
                    btn.prop('disabled', true);
                },
                success: function(data, status, xhr){
                    toastr.success(furciferParams.published + ' <a href="https://imgur.com/gallery/' + imgID + '" target="_blank">' + furciferParams.viewGallery + '</a>', palleonParams.success);
                    furcifer_rate_limits(xhr);
                },
                error: function(jqXHR,error, errorThrown) {
                    if (jqXHR.statusText == 'error' && jqXHR.responseText != null && jqXHR.responseText != '') {
                        var response = $.parseJSON(jqXHR.responseText);
                        var errorText = response.data.error;
                        toastr.error(errorText, jqXHR.status + ' ' + palleonParams.error);
                    } else{
                        toastr.error(palleonParams.wrong, palleonParams.error);
                    }
                    btn.prop('disabled', false);
                },
            }).done(function() {
                btn.prop('disabled', false);
            });
        });

        // Open Image Panel
        selector.find('#modal-imgur').on('click','.imgur-open-image',function(){
            toastr.options.positionClass = 'toast-bottom-left';
            selector.find('#furcifer-s-img-wrap').css('display', 'flex');
            var id = $(this).attr('data-id');
            $.each(images.data, function(index, val) {
                if (val.id == id) {
                    var link = val.link;
                    imgID = val.id;
                    var img = '<div class="palleon-img-wrap"><div class="palleon-img-loader"></div><img class="lazy" data-src="' + link + '" /></div>';
                    var date = new Date(val.datetime * 1000);
                    var info = '<ul><li><span>' + furciferParams.uploadedOn + ':</span><span>' + date.toLocaleDateString(furciferParams.locale.replace("_", "-"), { weekday:"short", year:"numeric", month:"short", day:"numeric"}) + '</span>';
                    info += '</li><li><span>' + furciferParams.size + ':</span><span>' + furcifer_format_bytes(val.size) + '</span>';
                    info += '</li><li><span>' + furciferParams.views + ':</span><span>' + val.views + '</span></li></ul>';
                    selector.find('#furcifer-img-download').attr('data-href', link);
                    selector.find('#furcifer-s-img-img').html(img);
                    if (val.favorite) {
                        selector.find('#furcifer-img-favorite').addClass('favorited');
                    } else {
                        selector.find('#furcifer-img-favorite').removeClass('favorited');
                    }
                    selector.find('#furcifer-img-link').val(val.link);
                    selector.find('#furcifer-img-link-view').attr('href', val.link);
                    selector.find('#furcifer-s-img-info').html(info);
                    if (val.title != null) {
                        selector.find('#furcifer-img-title').val(val.title);
                        selector.find('#imgur-img-share-title').val(val.title);
                    } else {
                        selector.find('#furcifer-img-title').val('');
                        selector.find('#imgur-img-share-title').val('');
                    }
                    if (val.description != null) {
                        selector.find('#furcifer-img-desc').val(val.description);
                    } else {
                        selector.find('#furcifer-img-desc').val('');
                    }
                    lazyLoadInstance.update();
                    return false; 
                }
            });
        });

        // Close Image Panel
        selector.find('#furcifer-s-img-close').on('click', function () {
            toastr.options.positionClass = 'toast-bottom-right';
            selector.find('#furcifer-s-img-wrap').css('display', 'none');
        });

        // Copy Url Button
        selector.find('#furcifer-img-link-copy').on('click', function() {
            var input = $(this);
            var copyText = document.getElementById("furcifer-img-link");
            copyText.select();
            copyText.setSelectionRange(0, 99999);
            navigator.clipboard.writeText(copyText.value);
            input.html('<span class="material-icons">done</span>');
            setTimeout(function(){
                input.html('<span class="material-icons">content_copy</span>');
            }, 2000);  
        });

        // Update image information
        selector.find('#furcifer-img-update').on('click', function() {
            var btn = $(this);
            var title = selector.find('#furcifer-img-title').val();
            var desc = selector.find('#furcifer-img-desc').val();
            var headers = {
                "Authorization": "Bearer " + accessToken
            };
            if (rapidApiKey != '') {
                headers = {
                    "Authorization": accessToken,
                    'X-RapidAPI-Key': rapidApiKey,
                    'X-RapidAPI-Host': 'imgur-apiv3.p.rapidapi.com'
                };
            }
            var form = new FormData();
            form.append("title", title);
            form.append("description", desc);
            $.ajax({
                url : apiURL + "3/image/" + imgID,
                type : "POST",
                timeout: 0,
                crossDomain: true,
                headers: headers,
                processData: false,
                mimeType: "multipart/form-data",
                contentType: false,
                data: form,
                beforeSend: function () {
                    btn.prop('disabled', true);
                },
                success: function(data, status, xhr){
                    selector.find('#imgur-images-refresh').trigger('click');
                    toastr.success(furciferParams.updated, palleonParams.success);
                },
                error: function(jqXHR,error, errorThrown) {
                    if (jqXHR.statusText == 'error' && jqXHR.responseText != null && jqXHR.responseText != '') {
                        var response = $.parseJSON(jqXHR.responseText);
                        var errorText = response.data.error;
                        toastr.error(errorText, jqXHR.status + ' ' + palleonParams.error);
                    } else{
                        toastr.error(palleonParams.wrong, palleonParams.error);
                    }
                    btn.prop('disabled', false);
                },
            }).done(function() {
                btn.prop('disabled', false);
            });
        });

        // Delete Image
        selector.find('#furcifer-img-delete').on('click', function() {
            var answer = window.confirm(palleonParams.answer2);
            if (answer) {
                var btn = $(this);
                var headers = {
                    "Authorization": "Bearer " + accessToken
                };
                if (rapidApiKey != '') {
                    headers = {
                        "Authorization": accessToken,
                        'X-RapidAPI-Key': rapidApiKey,
                        'X-RapidAPI-Host': 'imgur-apiv3.p.rapidapi.com'
                    };
                }
                var form = new FormData();
                $.ajax({
                    url : apiURL + "3/image/" + imgID,
                    type: "DELETE",
                    timeout: 0,
                    crossDomain: true,
                    headers: headers,
                    processData: false,
                    mimeType: "multipart/form-data",
                    contentType: false,
                    data: form,
                    beforeSend: function () {
                        btn.prop('disabled', true);
                    },
                    success: function(data, status, xhr){
                        selector.find('#furcifer-s-img-wrap').css('display', 'none');
                        selector.find('#imgur-images-refresh').trigger('click');
                        toastr.success(furciferParams.imageDeleted, palleonParams.success);
                    },
                    error: function(jqXHR,error, errorThrown) {
                        if (jqXHR.statusText == 'error' && jqXHR.responseText != null && jqXHR.responseText != '') {
                            var response = $.parseJSON(jqXHR.responseText);
                            var errorText = response.data.error;
                            toastr.error(errorText, jqXHR.status + ' ' + palleonParams.error);
                        } else{
                            toastr.error(palleonParams.wrong, palleonParams.error);
                        }
                        btn.prop('disabled', false);
                    },
                }).done(function() {
                    btn.prop('disabled', false);
                });
            }
        });
    }
}