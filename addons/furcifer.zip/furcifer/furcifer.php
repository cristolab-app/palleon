<?php
/**
 * Plugin Name: Furcifer
 * Plugin URI: https://palleon.website/furcifer/
 * Description: Imgur Addon For Palleon WordPress Image Editor
 * Version: 2.0
 * Requires PHP: 7.0
 * Author: Palleon Team
 * Author URI: https://palleon.website/
 * Text Domain: furcifer
 * Domain Path: /languages
 *
 */

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'FURCIFER_PLUGIN_URL' ) ) {
	define( 'FURCIFER_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

if ( ! defined( 'FURCIFER_PLUGIN_PATH' ) ) {
	define( 'FURCIFER_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'FURCIFER_VERSION' ) ) {
	define( 'FURCIFER_VERSION', '2.0');
}

if ( ! defined( 'FURCIFER_PALLEON_VERSION' ) ) {
	define( 'FURCIFER_PALLEON_VERSION', '4.0');
}

/* Admin notices */
function furcifer_requires_palleon(){
    echo '<div class="notice notice-error"><p>' . esc_html__( 'Furcifer requires Palleon to be installed.', 'furcifer' ) . ' <a href="https://palleon.website" target="_blank">' . esc_html__( 'Buy now!', 'furcifer' ) . '</a></p></div>';
}

function furcifer_requires_palleon_version(){
    echo '<div class="notice notice-warning"><p>' . esc_html__( 'Furcifer requires Palleon version', 'furcifer' ) . ' ' . FURCIFER_PALLEON_VERSION . ' ' . esc_html__( 'or greater. You can download the latest version from your Codecanyon account.', 'furcifer' ) . '</p></div>';
}

function furcifer_pro_only(){
    echo '<div class="notice notice-error"><p>' . esc_html__( 'Furcifer requires Pro Plan to be purchased.', 'antimena' ) . ' <a href="https://palleon.website" target="_blank">' . esc_html__( 'Buy now!', 'furcifer' ) . '</a></p></div>';
}

/* Init */
function furcifer_plugins_loaded() {
    if ( !defined( 'PALLEON_PLUGIN_URL' ) || !function_exists( 'palleon_fs' )  ) {
        add_action('admin_notices', 'furcifer_requires_palleon');
        return;
    } 
    if ( !defined( 'PALLEON_VERSION' )  ) {
        add_action('admin_notices', 'furcifer_requires_palleon_version');
        return;
    } else {
        if ( !version_compare( PALLEON_VERSION, FURCIFER_PALLEON_VERSION, '>=' ) ) {
            add_action('admin_notices', 'furcifer_requires_palleon_version');
            return;
        }
    }
    if ( palleon_fs()->is_plan('pro', true) ) {
        // If everything is OK, include required files
        include_once('mainClass.php');
    } else {
        add_action('admin_notices', 'furcifer_pro_only');
        return;
    }
}
add_action('plugins_loaded', 'furcifer_plugins_loaded', 11);