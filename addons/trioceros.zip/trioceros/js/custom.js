function trioceros(selector, canvas, lazyLoadInstance) {
    // Open Image Panel
    selector.find('#trio-panel-btn').on('click', function(){
        toastr.options.positionClass = 'toast-bottom-left';
        selector.find('#trio-panel-wrap').css('display', 'flex');
    });

    // Close Image Panel
    selector.find('#trio-panel-close').on('click', function () {
        toastr.options.positionClass = 'toast-bottom-right';
        selector.find('#trio-panel-wrap').css('display', 'none');
    });

    // Close Image Panel
    selector.on('click','.trio-use-file',function(){
        selector.find('.palleon-modal').hide();
        selector.find('#trio-panel-close').trigger('click');
    });

    // Load activities
    selector.one('click','#trio-panel-btn',function(){
        $('#trio-comment-textarea').summernote({
            height: 120,
            styleTags: ['p','h1','h2','h3','h4','h5','h6'],
            toolbar: [
            ['style', ['style']],
            ['font', ['bold','italic', 'underline', 'strikethrough', 'clear']],
            ['para', ['ul', 'ol']],
            ['insert', ['link', 'picture','hr']],
            ]
        });
        $('#trio-profile-bio-input').summernote({
            height: 120,
            styleTags: ['p','h1','h2','h3','h4','h5','h6'],
            toolbar: [
            ['style', ['style']],
            ['font', ['bold','italic', 'underline', 'strikethrough', 'clear']],
            ['para', ['ul', 'ol']],
            ['insert', ['link','hr']],
            ]
        });
        var form_data = new FormData();
        form_data.append('action', 'trioLoadActivities');
        form_data.append('nonce', palleonParams.nonce);
        $.ajax({
            url: palleonParams.ajaxurl,
            type: 'POST',
            contentType: false,
            processData: false,
            cache: false,
            data: form_data,
            success: function (response) {
                selector.find('#trio-activity-data').html(response);
                lazyLoadInstance.update();
                selector.find('#trio-activity-data').fadeIn();
            },
            error: function(jqXHR,error, errorThrown) {
                if(jqXHR.status&&jqXHR.status==400){
                    toastr.error(jqXHR.responseText, palleonParams.error);
                }else{
                    toastr.error(palleonParams.wrong, palleonParams.error);
                }
                selector.find('#trio-activity-data').show();
            }
        }).done(function() {
            selector.find('#trio-activity-data .trio-lightbox').featherlight({
                closeIcon:"close"
            });
        });
    });

    // Search Activities
    selector.on('click','#trio-activity-search-btn',function(){
        selector.find('#trio-activity-data').css('opacity', 0.5);
        var query = selector.find('#trio-activity-search').val();
        var tag = selector.find('#trio-activity-search-tag').find(':selected').val();
        var order = selector.find('#trio-activity-order').find(':selected').val();
        var form_data = new FormData();
        form_data.append('action', 'trioLoadActivities');
        form_data.append('search', query);
        form_data.append('tag', tag);
        form_data.append('order', order);
        form_data.append('nonce', palleonParams.nonce);
        $.ajax({
            url: palleonParams.ajaxurl,
            type: 'POST',
            contentType: false,
            processData: false,
            cache: false,
            data: form_data,
            success: function (response) {
                selector.find('#trio-activity-data').html(response);
                lazyLoadInstance.update();
            },
            error: function(jqXHR,error, errorThrown) {
                if(jqXHR.status&&jqXHR.status==400){
                    toastr.error(jqXHR.responseText, palleonParams.error);
                }else{
                    toastr.error(palleonParams.wrong, palleonParams.error);
                }
            }
        }).done(function() {
            selector.find('#trio-activity-data').css('opacity', 1);
            selector.find('#trio-activity-data .trio-lightbox').featherlight({
                closeIcon:"close"
            });
        });
    });

    // Load More Activities
    selector.on('click','#trio-load-more',function(){
        var btn = $(this);
        btn.prop('disabled', true);
        selector.find('#trio-activity-data').css('opacity', 0.5);
        var offset = parseInt($(this).attr('data-offset'));
        var query = selector.find('#trio-activity-search').val();
        var tag = selector.find('#trio-activity-search-tag').find(':selected').val();
        var form_data = new FormData();
        form_data.append('action', 'trioLoadMore');
        form_data.append('search', query);
        form_data.append('tag', tag);
        form_data.append('offset', offset);
        form_data.append('nonce', palleonParams.nonce);
        $.ajax({
            url: palleonParams.ajaxurl,
            type: 'POST',
            contentType: false,
            processData: false,
            cache: false,
            data: form_data,
            success: function (response) {
                btn.remove();
                selector.find('#trio-activity-data').append(response);
                lazyLoadInstance.update();
            },
            error: function(jqXHR,error, errorThrown) {
                if(jqXHR.status&&jqXHR.status==400){
                    toastr.error(jqXHR.responseText, palleonParams.error);
                }else{
                    toastr.error(palleonParams.wrong, palleonParams.error);
                }
            }
        }).done(function() {
            selector.find('#trio-activity-data').css('opacity', 1);
            btn.prop('disabled', false);
            selector.find('#trio-activity-data .trio-lightbox').featherlight({
                closeIcon:"close"
            });
        });
    });

    // Delete Activity
    selector.on('click','.trio-delete-activity',function(){
        var answer = window.confirm(triocerosParams.answer);
        if (answer) {
            var parent = $(this).parent().parent();
            var id = parent.attr('data-id');
            var form_data = new FormData();
            form_data.append('action', 'trioDeleteActivity');
            form_data.append('id', id);
            form_data.append('nonce', palleonParams.nonce);
            $.ajax({
                url: palleonParams.ajaxurl,
                type: 'POST',
                contentType: false,
                processData: false,
                cache: false,
                data: form_data,
                success: function (response) {
                    parent.remove();
                    selector.find('#trio-activity-search-btn').trigger('click');
                    selector.find('#trio-user-activities-list-pagination').remove();
                    selector.find('#trio-user-apps-list-pagination').remove();
                    trioSetPagination(selector.find('#trio-user-activities-list'));
                    trioSetPagination(selector.find('#trio-user-apps-list'));
                    toastr.success(triocerosParams.deleted, palleonParams.success);
                },
                error: function(jqXHR,error, errorThrown) {
                    if(jqXHR.status&&jqXHR.status==400){
                        toastr.error(jqXHR.responseText, palleonParams.error);
                    }else{
                        toastr.error(palleonParams.wrong, palleonParams.error);
                    }
                }
            });
        } 
    });

    // Refresh activity feed
    selector.on('click','#trio-user-modal .palleon-modal-close',function(){
        selector.find('#trio-activity-search-btn').trigger('click');
    });

    // Use Image
    selector.on('click','.trio-use-img',function(){
        var url = $(this).attr('data-img');
        $(document).trigger( "loadImgURL", [url, ''] );
        selector.find('.palleon-modal').hide();
        selector.find('#trio-panel-close').trigger('click');
    });

    // Appreciate
    selector.on('click','.trio-appreciation.not-active',function(){
        var btn = $(this);
        btn.prop('disabled', true);
        var parent = btn.parent().parent();
        var id = parent.attr('data-id');
        var form_data = new FormData();
        form_data.append('action', 'trioApp');
        form_data.append('id', id);
        form_data.append('nonce', palleonParams.nonce);
        $.ajax({
            url: palleonParams.ajaxurl,
            type: 'POST',
            contentType: false,
            processData: false,
            cache: false,
            data: form_data,
            success: function (response) {
                btn.removeClass('not-active');
                btn.addClass('active');
                btn.attr('title', triocerosParams.unapp);
                btn.find('.trio-appreciation-count').html(response);
            },
            error: function(jqXHR,error, errorThrown) {
                if(jqXHR.status&&jqXHR.status==400){
                    toastr.error(jqXHR.responseText, palleonParams.error);
                }else{
                    toastr.error(palleonParams.wrong, palleonParams.error);
                }
            }
        }).done(function() {
            btn.prop('disabled', false);
        });
    });

    // Unappreciate
    selector.on('click','.trio-appreciation.active',function(){
        var btn = $(this);
        btn.prop('disabled', true);
        var parent = btn.parent().parent();
        var id = parent.attr('data-id');
        var form_data = new FormData();
        form_data.append('action', 'trioUnapp');
        form_data.append('id', id);
        form_data.append('nonce', palleonParams.nonce);
        $.ajax({
            url: palleonParams.ajaxurl,
            type: 'POST',
            contentType: false,
            processData: false,
            cache: false,
            data: form_data,
            success: function (response) {
                btn.removeClass('active');
                btn.addClass('not-active');
                btn.attr('title', triocerosParams.app);
                btn.find('.trio-appreciation-count').html(response);
            },
            error: function(jqXHR,error, errorThrown) {
                if(jqXHR.status&&jqXHR.status==400){
                    toastr.error(jqXHR.responseText, palleonParams.error);
                }else{
                    toastr.error(palleonParams.wrong, palleonParams.error);
                }
            }
        }).done(function() {
            btn.prop('disabled', false);
        });
    });

    // View Comments
    selector.on('click','.trio-view-comments',function(){
        selector.find('.palleon-modal').hide();
        selector.find('#trio-comments-modal .trio-loader').show();
        selector.find('#trio-comments-modal').show();
        var parent = $(this).parent().parent();
        var id = parent.attr('data-id');
        var form_data = new FormData();
        form_data.append('action', 'trioLoadComments');
        form_data.append('id', id);
        form_data.append('nonce', palleonParams.nonce);
        $.ajax({
            url: palleonParams.ajaxurl,
            type: 'POST',
            contentType: false,
            processData: false,
            cache: false,
            data: form_data,
            success: function (response) {
                selector.find('#trio-reply-form').attr('data-id', id);
                selector.find('#trio-comments').html(response);
                selector.find('#trio-comments-modal .trio-loader').hide();
            },
            error: function(jqXHR,error, errorThrown) {
                if(jqXHR.status&&jqXHR.status==400){
                    toastr.error(jqXHR.responseText, palleonParams.error);
                }else{
                    toastr.error(palleonParams.wrong, palleonParams.error);
                }
            }
        });
    });

    // Add Comment
    selector.on('click','#trio-comment-button',function(){
        var text = selector.find('#trio-reply-form .note-editable').html();
        if (text == '') {
            toastr.error(triocerosParams.error1, palleonParams.error);
            return;
        }
        var btn = $(this);
        btn.prop('disabled', true);
        var id = selector.find('#trio-reply-form').attr('data-id');
        var form_data = new FormData();
        form_data.append('action', 'trioAddComment');
        form_data.append('id', id);
        form_data.append('text', text);
        form_data.append('nonce', palleonParams.nonce);
        $.ajax({
            url: palleonParams.ajaxurl,
            type: 'POST',
            contentType: false,
            processData: false,
            cache: false,
            data: form_data,
            success: function (response) {
                selector.find('#trio-activity-search-btn').trigger('click');
                selector.find('#trio-comments-modal').hide();
                selector.find('#trio-reply-form .note-editable').html('');
                selector.find('#trio-reply-form .note-editable').css('height', 120);
                toastr.success(triocerosParams.commentsent, triocerosParams.thanks);
            },
            error: function(jqXHR,error, errorThrown) {
                if(jqXHR.status&&jqXHR.status==400){
                    toastr.error(jqXHR.responseText, palleonParams.error);
                }else{
                    toastr.error(palleonParams.wrong, palleonParams.error);
                }
            }
        }).done(function() {
            btn.prop('disabled', false);
        });
    });

    // Delete Comment
    selector.on('click','.trio-comment-delete button',function(){
        var btn = $(this);
        var parent = btn.parent().parent();
        btn.prop('disabled', true);
        var id = btn.attr('data-id');
        var form_data = new FormData();
        form_data.append('action', 'trioDeleteComment');
        form_data.append('id', id);
        form_data.append('nonce', palleonParams.nonce);
        $.ajax({
            url: palleonParams.ajaxurl,
            type: 'POST',
            contentType: false,
            processData: false,
            cache: false,
            data: form_data,
            success: function (response) {
                selector.find('#trio-activity-search-btn').trigger('click');
                parent.remove();
            },
            error: function(jqXHR,error, errorThrown) {
                if(jqXHR.status&&jqXHR.status==400){
                    toastr.error(jqXHR.responseText, palleonParams.error);
                }else{
                    toastr.error(palleonParams.wrong, palleonParams.error);
                }
            }
        }).done(function() {
            btn.prop('disabled', false);
        });
    });

    // Form image toggle
    selector.on('change','#trio-img-check',function(){
        if ($(this).is(":checked")) {
            selector.find('.trio-form-img').removeClass('d-none');
        } else {
            selector.find('.trio-form-img').addClass('d-none');
        }
    });

    // Convert to data url
    function trioConvertToDataURL(url, callback) {
        var xhr = new XMLHttpRequest();
        xhr.onload = function() {
          var reader = new FileReader();
          reader.onloadend = function() {
            callback(reader.result);
          };
          reader.readAsDataURL(xhr.response);
        };
        xhr.open('GET', url);
        xhr.responseType = 'blob';
        xhr.send();
    }

    // Submit Activity Form
    selector.on('click','#trio-add-activity',function(){
        if (selector.find('#trio-title-input').val() == '') {
            toastr.error(triocerosParams.titlereq, palleonParams.error);
            return;
        }
        var name = selector.find('#trio-title-input').val();
        if (name.length > parseInt(triocerosParams.titleLength)) {
            toastr.error(triocerosParams.error2, palleonParams.error);
            return;
        }
        var btn = $(this);
        btn.prop('disabled', true);
        var filename = new Date().getTime();
        var tag = selector.find('#trio-tags-select').val();
        tag = JSON.stringify(tag);
        var JSON_defaults = ['objectType','gradientFill','roundedCorders','mode','selectable','lockMovementX','lockMovementY','lockRotation','crossOrigin','layerName','maskType', 'ogWidth', 'ogHeight'];
        var json = canvas.toJSON(JSON_defaults);

        var allow_comments = 'closed';
        if (selector.find('#trio-comments-check').is(':checked')) {
            allow_comments = 'open';
        }
        var attach_image = 'no';
        if (selector.find('#trio-img-check').is(':checked')) {
            attach_image = 'yes';
        }
        var attach_template = 'no';
        if (selector.find('#trio-template-check').is(':checked')) {
            attach_template = 'yes';
        }

        trioConvertToDataURL(json.backgroundImage.src, function(dataUrl) {
            json.backgroundImage.src = dataUrl;
            json = JSON.stringify(json);

            canvas.clone(function(canvas) {
                canvas.setZoom(1);
                canvas.setWidth(parseInt(selector.find('#palleon-resize-width').val()));
                canvas.setHeight(parseInt(selector.find('#palleon-resize-height').val()));

                var imgData = canvas.toDataURL({ format: 'png', quality: '1.0', enableRetinaScaling: false});
                var form_data = new FormData();
                form_data.append('name', name);
                form_data.append('tag', tag);
                form_data.append('filename', filename);
                form_data.append('json', json);
                form_data.append('thumb', imgData);
                form_data.append('action', 'trioSaveActivity');
                form_data.append('nonce', palleonParams.nonce);
                form_data.append('allowcomments', allow_comments);
                form_data.append('attachimage', attach_image);
                form_data.append('attachtemplate', attach_template);
        
                $.ajax({
                    url: palleonParams.ajaxurl,
                    type: 'POST',
                    contentType: false,
                    processData: false,
                    cache: false,
                    data: form_data,
                    success: function () {
                        selector.find('#trio-activity-search-btn').trigger('click');
                        toastr.success(triocerosParams.activitysent, palleonParams.success);
                    },
                    error: function(jqXHR,error, errorThrown) {
                        if(jqXHR.status&&jqXHR.status==400){
                            toastr.error(jqXHR.responseText, palleonParams.error);
                        }else{
                            toastr.error(palleonParams.wrong, palleonParams.error);
                        }
                    }
                }).done(function() {
                    btn.prop('disabled', false);
                });

                canvas.dispose();
            });
        });
    });

    // Email field validation
    var validateEmail = (email) => {
        return email.match(
          /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
        );
    };

    // Save User Settings
    selector.on('click','#trio-save-settings',function(){
        var nickname = selector.find('#trio-profile-nickname-input').val();
        var firstname = selector.find('#trio-profile-firstname-input').val();
        var lastname = selector.find('#trio-profile-lastname-input').val();
        var email = selector.find('#trio-profile-email-input').val();
        if (nickname == '') {
            toastr.error(triocerosParams.nicknamereq, palleonParams.error);
            return;
        } else if (firstname == '') {
            toastr.error(triocerosParams.firstnamereq, palleonParams.error);
            return;
        } else if (lastname == '') {
            toastr.error(triocerosParams.lastnamereq, palleonParams.error);
            return;
        } else if (email == '') {
            toastr.error(triocerosParams.emailreq, palleonParams.error);
            return;
        } else if (!validateEmail(email)) {
            toastr.error(triocerosParams.emailnotvalid, palleonParams.error);
            return;
        }

        var btn = $(this);
        btn.prop('disabled', true);
        var displayname = selector.find('#trio-profile-displayname-input').find(':selected').val();
        var bio = selector.find('#trio-settings .note-editable').html();
        var avatar = '';
        
        var attr = selector.find('#trio-avatar-data > img').attr('src');
        if (selector.find('#trio-avatar-data').length > 0 && attr !== false && typeof attr !== 'undefined') {
            avatar = selector.find('#trio-avatar-data > img').attr('src');
        }

        var form_data = new FormData();
        form_data.append('action', 'trioSaveSettings');
        form_data.append('nickname', nickname);
        form_data.append('firstname', firstname);
        form_data.append('lastname', lastname);
        form_data.append('displayname', displayname);
        form_data.append('bio', bio);
        form_data.append('email', email);
        form_data.append('avatar', avatar);
        form_data.append('nonce', palleonParams.nonce);
        $.ajax({
            url: palleonParams.ajaxurl,
            type: 'POST',
            contentType: false,
            processData: false,
            cache: false,
            data: form_data,
            success: function (response) {
                if (response == 'done') {
                    toastr.success(palleonParams.settingsaved, palleonParams.success);
                } else {
                    toastr.error(response, palleonParams.error);
                }
            },
            error: function(jqXHR,error, errorThrown) {
                if(jqXHR.status&&jqXHR.status==400){
                    toastr.error(jqXHR.responseText, palleonParams.error);
                }else{
                    toastr.error(palleonParams.wrong, palleonParams.error);
                }
                btn.prop('disabled', false);
            }
        }).done(function() {
            btn.prop('disabled', false);
        });
    });

    // Pagination
    function trioSetPagination(target) {
        var items = target.find('>*');
        var num = items.length;
        var perPage = parseInt(target.data('perpage'));
        if (num > perPage) {
            items.slice(perPage).hide();
            var paginationDiv = '<div id="' + target.attr('id') + '-pagination' + '" class="palleon-pagination"></div>';
            target.after(paginationDiv);
            selector.find('#' + target.attr('id') + '-pagination').pagination({
                items: num,
                itemsOnPage: perPage,
                prevText: '<span class="material-icons">navigate_before</span>',
                nextText: '<span class="material-icons">navigate_next</span>',
                displayedPages: 4,
                onPageClick: function (pageNumber, event) {
                    if (typeof event !== "undefined") {
                        event.preventDefault();
                    }
                    var showFrom = perPage * (pageNumber - 1);
                    var showTo = showFrom + perPage;
                    items.hide().slice(showFrom, showTo).show();
                }
            });
            selector.find('#' + target.attr('id') + '-pagination').pagination('selectPage', 1);
        }
    }

    // View User Profile
    selector.on('click','.view-user',function(e){
        e.preventDefault();
        var userID = $(this).attr('data-userid');
        var form_data = new FormData();
        form_data.append('action', 'trioLoadUser');
        form_data.append('userid', userID);
        form_data.append('nonce', palleonParams.nonce);
        selector.find('#trio-user-profile-wrap').html('<div class="palleon-modal-inner"><div class="palleon-modal-bg"><div class="trio-loader"><div class="palleon-loader"></div></div></div></div>');
        selector.find('.palleon-modal').hide();
        selector.find('#trio-user-modal').show();
        $.ajax({
            url: palleonParams.ajaxurl,
            type: 'POST',
            contentType: false,
            processData: false,
            cache: false,
            data: form_data,
            success: function (response) {
                selector.find('#trio-user-profile-wrap').html(response);
                lazyLoadInstance.update();
                trioSetPagination(selector.find('#trio-user-activities-list'));
                trioSetPagination(selector.find('#trio-user-apps-list'));
            },
            error: function(jqXHR,error, errorThrown) {
                if(jqXHR.status&&jqXHR.status==400){
                    toastr.error(jqXHR.responseText, palleonParams.error);
                }else{
                    toastr.error(palleonParams.wrong, palleonParams.error);
                }
            }
        }).done(function() {
            selector.find('#trio-user-profile-wrap .trio-lightbox').featherlight({
                closeIcon:"close"
            });
        });
    });

    // Upload Avatar
    selector.find('#trio-upload-avatar').on('change', function (e) {
        if ($(this).val() == '') {
            return;
        }
        var parent = $(this).parent().parent();
        var img = parent.find('img');
        var reader = new FileReader();
        reader.onload = function (event) {
            var image = new Image();
            image.src = event.target.result;
            image.onload = function() {
                if (this.width > 1024 || this.height > 1024) {
                    toastr.error(triocerosParams.error4, palleonParams.error);
                    return;
                }
                if (this.width != this.height) {
                    toastr.error(triocerosParams.error5, palleonParams.error);
                    return;
                }
                img.after(image);
                img.remove();
            };
        };
        reader.readAsDataURL(e.target.files[0]);
    });

    /* Save Avatar */
    selector.find('#palleon-avatar-save').on('click', function (e) {
        var width = selector.find('#palleon-resize-width').val();
        var height = selector.find('#palleon-resize-height').val();
        if (width > 1024 || height > 1024) {
            toastr.error(triocerosParams.error4, palleonParams.error);
            return;
        }
        if (width != height) {
            toastr.error(triocerosParams.error5, palleonParams.error);
            return;
        }
        var btn = $(this);
        btn.prop('disabled', true);

        canvas.clone(function(tempCanvas) {
            tempCanvas.setZoom(1);
            tempCanvas.setWidth(width);
            tempCanvas.setHeight(height);

            var form_data = new FormData();
            var imgData = tempCanvas.toDataURL({ format: 'png', enableRetinaScaling: false});

            form_data.append('avatar', imgData);
            form_data.append('action', 'saveAvatar');
            form_data.append('nonce', palleonParams.nonce);

            $.ajax({
                url: palleonParams.ajaxurl,
                type: 'POST',
                contentType: false,
                processData: false,
                cache: false,
                data: form_data,
                success: function (data) {
                    if (data == 'done') {
                        selector.find('.trio-avatar-wrap img').attr('src', imgData);
                        toastr.success(palleonParams.imgsaved, palleonParams.success);
                        selector.find('.palleon-modal').hide();
                    } else {
                        toastr.error(palleonParams.wrong, palleonParams.error);
                    }
                },
                error: function(jqXHR,error, errorThrown) {
                    if(jqXHR.status&&jqXHR.status==400){
                        toastr.error(jqXHR.responseText, palleonParams.error);
                    }else{
                        toastr.error(palleonParams.wrong, palleonParams.error);
                    }
                    btn.prop('disabled', false);
                }
            }).done(function() {
                btn.prop('disabled', false);
            });
            tempCanvas.dispose();
        });
    });
}