=== Trioceros - Community Addon ===
Contributors: Palleon Team
Donate link: http://palleon.website/
Requires PHP: 7.0