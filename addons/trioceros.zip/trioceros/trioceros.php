<?php
/**
 * Plugin Name: Trioceros
 * Plugin URI: https://palleon.website/trioceros.php
 * Description: Community Addon For Palleon WordPress Image Editor
 * Version: 2.1.1
 * Requires PHP: 7.0
 * Author: Palleon Team
 * Author URI: https://palleon.website/
 * Text Domain: trioceros
 * Domain Path: /languages
 *
 */

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'TRIOCEROS_PLUGIN_URL' ) ) {
	define( 'TRIOCEROS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

if ( ! defined( 'TRIOCEROS_PLUGIN_PATH' ) ) {
	define( 'TRIOCEROS_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'TRIOCEROS_VERSION' ) ) {
	define( 'TRIOCEROS_VERSION', '2.1.1');
}

if ( ! defined( 'TRIOCEROS_PALLEON_VERSION' ) ) {
	define( 'TRIOCEROS_PALLEON_VERSION', '4.0');
}

/* Admin notices */
function trioceros_requires_palleon(){
    echo '<div class="notice notice-error"><p>' . esc_html__( 'Trioceros requires Palleon to be installed.', 'trioceros' ) . ' <a href="https://palleon.website" target="_blank">' . esc_html__( 'Buy now!', 'trioceros' ) . '</a></p></div>';
}

function trioceros_requires_palleon_version(){
    echo '<div class="notice notice-warning"><p>' . esc_html__( 'Trioceros requires Palleon version', 'trioceros' ) . ' ' . TRIOCEROS_PALLEON_VERSION . ' ' . esc_html__( 'or greater. You can download the latest version from your Codecanyon account.', 'trioceros' ) . '</p></div>';
}

function trioceros_pro_only(){
    echo '<div class="notice notice-error"><p>' . esc_html__( 'Trioceros requires Pro Plan to be purchased.', 'trioceros' ) . ' <a href="https://palleon.website" target="_blank">' . esc_html__( 'Buy now!', 'trioceros' ) . '</a></p></div>';
}

/* Init */
function trioceros_plugins_loaded() {
    if ( !defined( 'PALLEON_PLUGIN_URL' ) || !function_exists( 'palleon_fs' )  ) {
        add_action('admin_notices', 'trioceros_requires_palleon');
        return;
    } 
    if ( !defined( 'PALLEON_VERSION' )  ) {
        add_action('admin_notices', 'trioceros_requires_palleon_version');
        return;
    } else {
        if ( !version_compare( PALLEON_VERSION, TRIOCEROS_PALLEON_VERSION, '>=' ) ) {
            add_action('admin_notices', 'trioceros_requires_palleon_version');
            return;
        }
    }
    if ( palleon_fs()->is_plan('pro', true) ) {
        // If everything is OK, include required files
        include_once('mainClass.php');
        include_once('includes/activities.php');
    } else {
        add_action('admin_notices', 'trioceros_pro_only');
        return;
    }
}
add_action('plugins_loaded', 'trioceros_plugins_loaded', 11);