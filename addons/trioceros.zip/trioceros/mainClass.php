<?php
defined( 'ABSPATH' ) || exit;

class Trioceros extends Palleon {
    /**
	 * The single instance of the class
	 */
	protected static $_instance = null;

    /**
	 * Main Instance
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

    /**
	 * Trioceros Constructor
	 */
    public function __construct() {
        $custom_avatar = PalleonSettings::get_option('trioceros_user_avatar', 'disable');
        if (is_user_logged_in()) {
            add_filter('palleonStylesheets', array($this, 'trio_styles'), 20);
            add_filter('palleonScripts', array($this, 'trio_scripts'), 20);
            add_action('palleon_body_end', array($this, 'trio_localization'), 10);
            add_action('palleon_body_end', array($this, 'trio_panel'), 10);
            add_action('palleon_top_bar', array($this, 'trio_top_bar'));
            add_action('wp_ajax_trioSaveSettings', array($this, 'save_user_settings'));
            add_action('wp_ajax_trioLoadUser', array($this, 'load_user_profile'));
            add_action('wp_ajax_saveAvatar', array($this, 'save_avatar'));
            if ($custom_avatar == 'enable') {
                add_action('palleon_after_save', array($this, 'trio_save_field'), 10);
            }
        }
        add_action('init', array($this, 'trio_init'), 1);
        add_filter('plugin_row_meta', array($this, 'trio_plugin_links'), 10, 4);
        add_action('palleon_add_setting_tab', array($this, 'trio_setting_tab'));
		add_action('palleon_add_settings', array($this, 'trio_settings'));
        if ($custom_avatar == 'enable') {
            add_filter('get_avatar', array($this, 'trio_gravatar_filter'), 10, 5);
        }
    }

    /**
	 * Init
	 */
    public function trio_init() {
        // Load text domain
        load_plugin_textdomain( 'trioceros', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
        // Required for the rich text editor to work properly
        remove_filter('pre_user_description', 'wp_filter_kses');
        add_filter('pre_user_description', 'wp_kses_post', 10);
    }

    /**
	 * Add plugin links to plugins page on the admin dashboard
	 */
    public function trio_plugin_links($links_array, $plugin_file_name, $plugin_data, $status) {
        if ( strpos( $plugin_file_name, 'trioceros.php' ) !== false ) {
            $links_array[] = '<a href="'. esc_url( get_admin_url(null, 'admin.php?page=palleon_options&tab=cmb2-id-trioceros-title') ) .'">' . esc_html__( 'Settings', 'trioceros' ) . '</a>';
            $links_array[] = '<a href="https://palleon.website/trioceros/documentation/" target="_blank">' . esc_html__( 'Documentation', 'trioceros' ) . '</a>';
        }
        return $links_array;
    }

    /**
	 * Palleon styles
	 */
    public function trio_styles($styles) {
        if (!isset($_GET['attachment_id'])) {
        $styles['featherlight-css'] = array(TRIOCEROS_PLUGIN_URL . 'css/featherlight.min.css', TRIOCEROS_VERSION);
        $styles['summernote-css'] = array(TRIOCEROS_PLUGIN_URL . 'css/summernote-lite.css', TRIOCEROS_VERSION);
        $styles['trioceros-css'] = array(TRIOCEROS_PLUGIN_URL . 'css/style.css', TRIOCEROS_VERSION);
        }
        return $styles;
    }
    
	/**
	 * Palleon scripts
	 */
    public function trio_scripts($scripts) {
        if (!isset($_GET['attachment_id'])) {  
        $scripts['featherlight-js'] = array(TRIOCEROS_PLUGIN_URL . 'js/featherlight.min.js', TRIOCEROS_VERSION);
        $scripts['summernote-js'] = array(TRIOCEROS_PLUGIN_URL . 'js/summernote-lite.min.js', TRIOCEROS_VERSION);
        $scripts['trioceros-js'] = array(TRIOCEROS_PLUGIN_URL . 'js/custom.js', TRIOCEROS_VERSION);
        }
        return $scripts;
    }

    /**
	 * Localization
	 */

    public function trio_localization() { 
        $user = wp_get_current_user();
        $allowed_roles = PalleonSettings::get_option('trioceros_author_roles', array());
        $title_length =  (int) PalleonSettings::get_option('trioceros_title_length', 100);
        $author = 'no';
        array_push($allowed_roles, 'administrator'); 
        if ( array_intersect( $allowed_roles, $user->roles )) {
            $author = 'yes';
        }
        ?>
        <script>
        /* <![CDATA[ */
        var triocerosParams = {
            "author": "<?php echo esc_html($author); ?>",
            "titleLength": "<?php echo esc_html($title_length); ?>",
            "author": "<?php echo esc_html($author); ?>",
            "loadMore": "<?php echo esc_html__('Load More', 'trioceros'); ?>",
            "loading": "<?php echo esc_html__('Loading...', 'trioceros'); ?>",
            "answer": "<?php echo esc_html__('Are you sure you want to delete the post permanently?', 'trioceros'); ?>",
            "app": "<?php echo esc_html__('Appreciate', 'trioceros'); ?>",
            "unapp": "<?php echo esc_html__('Unappreciate', 'trioceros'); ?>",
            "thanks": "<?php echo esc_html__('Thank you!', 'trioceros'); ?>",
            "commentsent": "<?php echo esc_html__('Your comment has been sent successfully.', 'trioceros'); ?>",
            "activitysent": "<?php echo esc_html__('Your post has been sent successfully.', 'trioceros'); ?>",
            "titlereq": "<?php echo esc_html__('Title is required.', 'trioceros'); ?>",
            "nicknamereq": "<?php echo esc_html__('Nickname is required.', 'trioceros'); ?>",
            "firstnamereq": "<?php echo esc_html__('First name is required.', 'trioceros'); ?>",
            "lastnamereq": "<?php echo esc_html__('Last name is required.', 'trioceros'); ?>",
            "emailreq": "<?php echo esc_html__('Email is required.', 'trioceros'); ?>",
            "emailnotvalid": "<?php echo esc_html__('The email you entered is not valid.', 'trioceros'); ?>",
            "deleted": "<?php echo esc_html__('The activity has been deleted.', 'trioceros'); ?>",
            "error1": "<?php echo esc_html__('Comment field is required.', 'trioceros'); ?>",
            "error2": "<?php echo esc_html__('Maximum number of characters allowed in the title is', 'trioceros') . ' ' . $title_length . '.'; ?>",
            "error3": "<?php echo esc_html__('You have exceeded the maximum number of characters.', 'trioceros'); ?>",
            "error4": "<?php echo esc_html__('Maximum allowed image size is 1024x1024px.', 'trioceros'); ?>",
            "error5": "<?php echo esc_html__('Avatar must be a square image.', 'trioceros'); ?>",
        };
        /* ]]> */
        </script>
        <?php
    }

    /**
	 * Add Setting Tab
	 */
    public function trio_setting_tab($options) {
        $options->add_field( array(
            'name' => '<span class="dashicons dashicons-admin-plugins"></span>' . esc_html__( 'Trioceros', 'trioceros' ),
            'id'   => 'trioceros_title',
            'type' => 'title'
        ) );
    }

    /**
	 * Add Settings
	 */
    public function trio_settings($options) {
        global $wp_roles;
        $roles = array();
        $all_roles = $wp_roles->roles;
        $editable_roles = apply_filters('editable_roles', $all_roles);
        foreach ($editable_roles as $role_name => $role_info) {
            if ($role_name !== 'administrator') {
                $roles[$role_name] = $role_info['name'];
            }
        }
        $options->add_field( array(
            'name'    => esc_html__( 'Authors', 'trioceros' ),
            'desc'    => esc_html__( 'Select which user roles are allowed to add new activities. Admins are always allowed.', 'trioceros' ),
            'id'      => 'trioceros_author_roles',
            'type'    => 'multicheck_inline',
            'options' => $roles,
            'before_row' => '<div class="palleon-tab-content" data-id="trioceros-title">',
        ) );
        $options->add_field( array(
            'id'      => 'trioceros_activity_status',
            'name'   => esc_html__( 'Default Activity Status', 'trioceros' ),
            'desc'    => esc_html__( 'Choose the default post status for new activities. Pending activities will not appear in Palleon until they are published by admins from PE Activities in the WordPress dashboard. Admin posts are always automatically approved.', 'trioceros' ),
            'type' => 'radio_inline',
            'options' => array(
                'publish' => esc_html__( 'Publish', 'trioceros' ),
                'pending'   => esc_html__( 'Pending', 'trioceros' )
            ),
            'attributes' => array(
                'autocomplete' => 'off'
            ),
            'default' => 'pending'
        ));
        $options->add_field( array(
            'id'      => 'trioceros_user_settings',
            'name'   => esc_html__( 'User Settings', 'trioceros' ),
            'type' => 'radio_inline',
            'options' => array(
                'enable' => esc_html__( 'Enable', 'trioceros' ),
                'disable'   => esc_html__( 'Disable', 'trioceros' )
            ),
            'attributes' => array(
                'autocomplete' => 'off'
            ),
            'default' => 'enable'
        ));
        $options->add_field( array(
            'id'      => 'trioceros_user_avatar',
            'name'   => esc_html__( 'Avatar Image Upload', 'trioceros' ),
            'desc'    => esc_html__( 'Allow users to upload their own avatar images from settings.', 'trioceros' ),
            'type' => 'radio_inline',
            'options' => array(
                'enable' => esc_html__( 'Enable', 'trioceros' ),
                'disable'   => esc_html__( 'Disable', 'trioceros' )
            ),
            'attributes' => array(
                'autocomplete' => 'off'
            ),
            'default' => 'disable'
        ));
        $options->add_field( array(
            'id'      => 'trioceros_comments',
            'name'   => esc_html__( 'Comments', 'trioceros' ),
            'type' => 'radio_inline',
            'options' => array(
                'enable' => esc_html__( 'Enable', 'trioceros' ),
                'disable'   => esc_html__( 'Disable', 'trioceros' )
            ),
            'attributes' => array(
                'autocomplete' => 'off'
            ),
            'default' => 'enable'
        ));
        $options->add_field( array(
            'id'      => 'trioceros_appreciations',
            'name'   => esc_html__( 'Appreciations', 'trioceros' ),
            'type' => 'radio_inline',
            'options' => array(
                'enable' => esc_html__( 'Enable', 'trioceros' ),
                'disable'   => esc_html__( 'Disable', 'trioceros' )
            ),
            'attributes' => array(
                'autocomplete' => 'off'
            ),
            'default' => 'enable'
        ));
        $options->add_field( array(
            'id'      => 'trioceros_title_length',
            'name'   => esc_html__( 'Title Length', 'trioceros' ),
            'desc'    => esc_html__( 'Maximum number of characters allowed in the title.', 'trioceros' ),
            'type' => 'text',
            'attributes' => array(
                'type' => 'number',
                'pattern' => '\d*',
                'autocomplete' => 'off'
            ),
            'default' => 100
        ) );
        $options->add_field( array(
            'id'      => 'trioceros_max_activity',
            'name'   => esc_html__( 'Activities', 'trioceros' ),
            'desc'    => esc_html__( 'Max. number of my activities to show.', 'trioceros' ),
            'type' => 'text',
            'attributes' => array(
                'type' => 'number',
                'pattern' => '\d*',
                'autocomplete' => 'off'
            ),
            'default' => 5,
            'after_row' => '</div>'
        ));
    }

    /**
	 * Add custom panel
	 */
    public function trio_panel() {
        if (!isset($_GET['attachment_id'])) {
        include_once('includes/panel.php');
        }
    }

    /**
	 * Add custom panel
	 */
    public function trio_top_bar() {
        if (!isset($_GET['attachment_id'])) {
        include_once('includes/top-bar.php');
        }
    }

    /**
	 * Save settings
	 */
    public function save_user_settings() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'trioceros'));
        }
        $current_user = wp_get_current_user();

        if (isset($_POST['nickname']) && !empty($_POST['nickname'])) {
            update_user_meta($current_user->ID, 'nickname', sanitize_text_field( $_POST['nickname'] ) );
        } 

        if (isset($_POST['firstname'])) {
            update_user_meta($current_user->ID, 'first_name', sanitize_text_field( $_POST['firstname'] ) );
        }

        if (isset($_POST['lastname'])) {
            update_user_meta($current_user->ID, 'last_name', sanitize_text_field( $_POST['lastname'] ) );
        }

        if (isset($_POST['bio'])) {
            update_user_meta($current_user->ID, 'description', wp_kses_post( $_POST['bio'] ));
        }

        if (isset($_POST['avatar']) && !empty($_POST['avatar'])) {
            update_user_meta($current_user->ID, 'trio_user_avatar_data', sanitize_text_field( $_POST['avatar'] ) );
        }

        if (isset($_POST['displayname'])) {
            $display_name = get_user_meta($current_user->ID, 'nickname', true);
            if ($_POST['displayname'] == 'display_firstname') {
                $display_name = get_user_meta($current_user->ID, 'first_name', true);
            } else if ($_POST['displayname'] == 'display_lastname') {
                $display_name = get_user_meta($current_user->ID, 'last_name', true);
            } else if ($_POST['displayname'] == 'display_firstlast') {
                $display_name = get_user_meta($current_user->ID, 'first_name', true) . ' ' . get_user_meta($current_user->ID, 'last_name', true);
            } else if ($_POST['displayname'] == 'display_lastfirst') {
                $display_name = get_user_meta($current_user->ID, 'last_name', true) . ' ' . get_user_meta($current_user->ID, 'first_name', true);
            }
            wp_update_user(array('ID' => $current_user->ID, 'display_name' => esc_attr( $display_name )));
            update_user_meta($current_user->ID, 'display_name' , esc_attr( $display_name ));
        }

        if (isset($_POST['email']) && !empty($_POST['email'])) {
            if (!is_email($_POST['email'])) {
                echo esc_html__('The email you entered is not valid.', 'trioceros');
                wp_die();
            } else if(email_exists(sanitize_email( $_POST['email'] )) && (sanitize_email( $_POST['email'] ) != $current_user->user_email)) {
                echo esc_html__('This email is already used by another user. Try a different one.', 'trioceros');
                wp_die();
            } else {
                wp_update_user( array ('ID' => $current_user->ID, 'user_email' => sanitize_email( $_POST['email'] )));
            }
        }

        echo 'done';
        wp_die();
    }

    /**
	 * Load user profile
	 */
    public function load_user_profile() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'trioceros'));
        }
        $appreciations = PalleonSettings::get_option('trioceros_appreciations', 'enable');
        $comments = PalleonSettings::get_option('trioceros_comments', 'enable');
        $user_id = get_current_user_id();
        if (isset($_POST['userid']) && !empty($_POST['userid'])) {
            $user_id = (int) $_POST['userid'];
        }
        $user = get_user_by( 'ID', $user_id );
        $date = $user->user_registered;
        $registered_date = esc_html__('Member since', 'trioceros') . ' ' . date(get_option('date_format'), strtotime($date)) . '.';
        $desc = get_user_meta($user_id, 'description', true);
        ?>
        <div class="palleon-modal-inner">
            <div class="palleon-modal-bg">
                <div class="trio-profile-header">
                    <div class="trio-profile-avatar">
                        <?php echo get_avatar( $user_id, 128 ); ?>
                    </div>
                    <div class="trio-profile-name">
                        <h3><?php echo esc_html($user->display_name); ?></h3>
                        <p><?php echo esc_html($registered_date); ?></p>
                    </div>
                </div>
                <div class="palleon-tabs">
                    <ul class="palleon-tabs-menu">
                        <li id="trio-user-profile-menu" class="active" data-target="#trio-user-profile"><span class="material-icons">face</span><?php echo esc_html__('Profile', 'trioceros'); ?></li>
                        <li id="trio-user-activities-menu" data-target="#trio-user-activities"><span class="material-icons">notifications</span><?php echo esc_html__('Activities', 'trioceros'); ?></li>
                        <?php if ($appreciations == 'enable') { ?>
                        <li id="trio-user-apps-menu" data-target="#trio-user-apps"><span class="material-icons">star</span><?php echo esc_html__('Favorites', 'trioceros'); ?></li>
                        <?php } ?>
                    </ul>
                    <div id="trio-user-profile" class="palleon-tab active">
                        <div class="trio-user-stats">
                            <div class="trio-user-stat">
                                <div class="trio-user-stat-icon">
                                    <span class="material-icons">notifications</span>
                                </div>
                                <div class="trio-user-stat-content">
                                    <div class="trio-user-stat-number"><?php echo esc_html(count_user_posts($user_id, 'triocerosactivities', true)); ?></div>
                                    <div class="trio-user-stat-desc"><?php echo esc_html__('Activities', 'trioceros'); ?></div>
                                </div>
                            </div>
                            <?php if ($appreciations == 'enable') { ?>
                            <div class="trio-user-stat">
                                <?php 
                                $user_app_count = get_user_meta( $user_id, 'trio_user_app', true ); 
                                if (empty($user_app_count)) {
                                    $user_app_count = array();
                                }
                                $app_count = count($user_app_count);

                                ?>
                                <div class="trio-user-stat-icon">
                                    <span class="material-icons">thumb_up</span>
                                </div>
                                <div class="trio-user-stat-content">
                                    <div class="trio-user-stat-number"><?php echo esc_html($app_count); ?></div>
                                    <div class="trio-user-stat-desc"><?php echo esc_html__('Appreciations', 'trioceros'); ?></div>
                                </div>
                            </div>
                            <?php } ?>
                            <?php if ($comments == 'enable') { ?>
                            <div class="trio-user-stat">
                                <?php
                                $args = array(
                                    'user_id' => $user_id
                                );
                                $comments = get_comments( $args );
                                ?>
                                <div class="trio-user-stat-icon">
                                    <span class="material-icons">forum</span>
                                </div>
                                <div class="trio-user-stat-content">
                                    <div class="trio-user-stat-number"><?php echo esc_html(count($comments)); ?></div>
                                    <div class="trio-user-stat-desc"><?php echo esc_html__('Comments', 'trioceros'); ?></div>
                                </div>
                            </div>
                            <?php } ?>
                        </div>
                        <?php
                        if (!empty($desc)) {
                            echo wp_kses_post($desc);
                        }
                        ?>
                    </div>
                    <div id="trio-user-activities" class="palleon-tab" data-userid="<?php echo esc_attr($user_id); ?>">
                        <div id="trio-user-activities-list" class="paginated" data-perpage="2">
                        <?php
                        $args = array(
                            'post_status' => 'publish',
                            'post_type' => 'triocerosactivities',
                            'posts_per_page'  => 9999,
                            'order'  => 'DESC',
                            'orderby'  => 'post_date',
                            'author' => $user_id
                        );
                        TriocerosActivities::populate_activities($args, 9999, false);
                        ?>
                        </div>
                    </div>
                    <?php if ($appreciations == 'enable') { ?>
                    <div id="trio-user-apps" class="palleon-tab" data-userid="<?php echo esc_attr($user_id); ?>">
                        <div id="trio-user-apps-list" class="paginated" data-perpage="2">
                        <?php
                        $userapp = get_user_meta( $user_id, 'trio_user_app', true );
                        if (!is_array($userapp)) {
                            $userapp = array();
                        }
                        $args = array(
                            'post_status' => 'publish',
                            'post_type' => 'triocerosactivities',
                            'posts_per_page'  => 9999,
                            'order'  => 'DESC',
                            'orderby'  => 'post_date',
                            'post__in' => $userapp,
                            'author__not_in' => $user_id
                        );
                        TriocerosActivities::populate_activities($args, 9999, false);
                        ?>
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    <?php
        wp_die();
    }

    /* Custom Avatar */
    public function trio_gravatar_filter($avatar, $id_or_email, $size, $default, $alt) {
        $email = is_object( $id_or_email ) ? $id_or_email->comment_author_email : $id_or_email;
        if( is_email( $email ) && ! email_exists( $email ) ) {
            return $avatar;
        }
        $custom_avatar = get_user_meta($id_or_email, 'trio_user_avatar_data', true);
        if ($custom_avatar) {
            $return = '<img class="avatar" src="' . $custom_avatar . '" width="' . $size . '" height="' . $size . '" alt="' . $alt . '" />';
        } else if ($avatar) {
            $return = $avatar;
        } else {
            $return = '<img class="avatar" src="' . $default . '" width="' . $size . '" height="' . $size . '" alt="' . $alt . '" />';
        }
        return $return;
    }

    /**
	 * Save Custom Avatar
	 */
    public function trio_save_field(){
        if(is_user_logged_in()) { ?>
            <div id="palleon-save-as-avatar">
            <button id="palleon-avatar-save" type="button" class="palleon-btn palleon-lg-btn btn-full primary"><span class="material-icons">save</span><?php echo esc_html__('Save As Avatar', 'trioceros'); ?></button>
            </div>
        <?php }
    }

    /**
	 * Save avatar
	 */
    public function save_avatar(){
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'trioceros'));
        }
        $current_user = wp_get_current_user();
        if (isset($_POST['avatar']) && !empty($_POST['avatar'])) {
            update_user_meta($current_user->ID, 'trio_user_avatar_data', sanitize_text_field( $_POST['avatar'] ) );
            echo 'done';
        } else {
            echo 'error';
        }
        wp_die();
    }
}

/**
 * Returns the main instance of the class
 */
function Trioceros() {  
	return Trioceros::instance();
}
// Global for backwards compatibility
$GLOBALS['Trioceros'] = Trioceros();    