<div class="trio-menu-icon">
    <button id="trio-panel-btn" type="button" class="palleon-btn" autocomplete="off"><span class="material-icons">forum</span><span class="palleon-btn-text"><?php echo esc_html__( 'Community', 'trioceros' ); ?></span></button>
</div>