<?php
defined( 'ABSPATH' ) || exit;

class TriocerosActivities {
    /**
	 * The single instance of the class
	 */
	protected static $_instance = null;

    /**
	 * Main Instance
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

    /**
	 * Constructor
	 */
    public function __construct() {
        $appreciations = PalleonSettings::get_option('trioceros_appreciations', 'enable');
        $comments = PalleonSettings::get_option('trioceros_comments', 'enable');
        if (is_user_logged_in()) {
            add_action('wp_ajax_trioSaveActivity', array($this, 'save_activity'));
            add_action('wp_ajax_trioDeleteActivity', array($this, 'delete_activity'));
            add_action('wp_ajax_trioLoadActivities', array($this, 'load_activities'));
            add_action('wp_ajax_trioLoadMore', array($this, 'more_activities'));
            if ($appreciations == 'enable') {
                add_action('wp_ajax_trioApp', array($this, 'appreciate'));
                add_action('wp_ajax_trioUnapp', array($this, 'unappreciate'));
            }
            if ($comments == 'enable') {
                add_action('wp_ajax_trioLoadComments', array($this, 'load_comments'));
                add_action('wp_ajax_trioAddComment', array($this, 'add_comment'));
                add_action('wp_ajax_trioDeleteComment', array($this, 'delete_comment'));
            }
        }
        add_action('init', array($this, 'register_post_type'));
        add_action('init', array($this, 'register_taxonomy'), 0);
        add_filter('cmb2_meta_boxes', array($this, 'add_template_metabox') );
        add_action('before_delete_post', array($this, 'delete_attachment'), 10, 2);
    }

    /**
	 * Register Post Type
	 */
    public function register_post_type() {
        $labels = array(
            'name'              => esc_html__( 'Palleon Activities', 'trioceros' ),
            'singular_name'     => esc_html__( 'Activity', 'trioceros' ),
            'add_new'           => esc_html__( 'Add new activity', 'trioceros' ),
            'add_new_item'      => esc_html__( 'Add new activity', 'trioceros' ),
            'edit_item'         => esc_html__( 'Edit activity', 'trioceros' ),
            'new_item'          => esc_html__( 'New activity', 'trioceros' ),
            'view_item'         => esc_html__( 'View activity', 'trioceros' ),
            'search_items'      => esc_html__( 'Search activities', 'trioceros' ),
            'not_found'         => esc_html__( 'No activity found', 'trioceros' ),
            'not_found_in_trash'=> esc_html__( 'No activity found in trash', 'trioceros' ),
            'parent_item_colon' => esc_html__( 'Parent activity:', 'trioceros' ),
            'menu_name'         => esc_html__( 'PE Activities', 'trioceros' )
        );
    
        $taxonomies = array();
        $supports = array('title', 'thumbnail');

        $comments = PalleonSettings::get_option('trioceros_comments', 'enable');
        if ($comments == 'enable') {
            add_post_type_support( 'triocerosactivities', 'author' );
            $supports = array('title', 'thumbnail', 'comments');
        }
     
        $post_type_args = array(
            'labels'            => $labels,
            'singular_label'    => esc_html__('Activity', 'trioceros'),
            'public'            => false,
            'exclude_from_search' => true,
            'show_ui'           => true,
            'show_in_nav_menus' => false,
            'publicly_queryable'=> true,
            'query_var'         => true,
            'capability_type'   => 'post',
            'capabilities' => array(
                'edit_post'          => 'manage_options',
                'read_post'          => 'manage_options',
                'delete_post'        => 'manage_options',
                'edit_posts'         => 'manage_options',
                'edit_others_posts'  => 'manage_options',
                'delete_posts'       => 'manage_options',
                'publish_posts'      => 'manage_options',
                'read_private_posts' => 'manage_options'
            ),
            'has_archive'       => false,
            'hierarchical'      => false,
            'supports'          => $supports,
            'menu_position'     => 10,
            'menu_icon'         => 'dashicons-admin-comments',
            'taxonomies'        => $taxonomies
        );
        register_post_type('triocerosactivities',$post_type_args);
    }

    /**
	 * Register Taxonomy
	 */
    public function register_taxonomy() {
        register_taxonomy(
            'triocerostags',
            'triocerosactivities',
            array(
                'labels' => array(
                    'name' => esc_html__( 'Tags', 'trioceros' ),
                    'add_new_item' => esc_html__( 'Add new tag', 'trioceros' ),
                    'new_item_name' => esc_html__( 'New tag', 'trioceros' )
                ),
                'show_ui' => true,
                'show_tagcloud' => false,
                'show_admin_column' => true,
                'show_in_nav_menus' => false,
                'hierarchical' => true,
                'query_var' => true
            )
        );
    }

    /**
	 * Add Template
	 */
    public function add_template_metabox( $meta_boxes ) {
        $meta_boxes['trioceros_template'] = array(
            'id' => 'trioceros_template',
            'title' => esc_html__( 'Template', 'trioceros'),
            'object_types' => array('triocerosactivities'),
            'context' => 'normal',
            'priority' => 'default',
            'show_names' => true,
            'fields' => array(
                array(
                    'name'    => esc_html__( 'Template File URL', 'trioceros' ),
                    'description' => esc_html__( 'To get a valid JSON file, use Palleon image editor.', 'trioceros'),
                    'id'      => 'trioceros_custom_template',
                    'type'    => 'file',
                    'options' => array(
                        'url' => true
                    ),
                    'query_args' => array(
                        'type' => 'application/json'
                    )
                )
            ),
        );
    
        return $meta_boxes;
    }

    /**
	 * Save Activity
	 */
    public function save_activity(){
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'trioceros'));
        }

        if (isset($_POST['allowcomments']) && !empty($_POST['allowcomments'])) {
            $allowComments = $_POST['allowcomments'];
        }

        $comments = PalleonSettings::get_option('trioceros_comments', 'enable');
        if ($comments == 'disable') {
            $allowComments = 'closed';
        }

        $status = PalleonSettings::get_option('trioceros_activity_status', 'pending');
        if (current_user_can('administrator')) {
            $status = 'publish';
        }

        // Insert Post
        $post_id = wp_insert_post(array (
            'post_title' => sanitize_text_field($_POST['name']),
            'post_type' => 'triocerosactivities',
            'post_status' => $status,
            'comment_status' => $allowComments
        ));

        // Set tags
        if (isset($_POST['tag']) && $_POST['tag'] !== 0 && !empty($_POST['tag'])) {
            $tags = json_decode( stripslashes( $_POST['tag'] ), true );
            wp_set_post_terms( $post_id, $tags, 'triocerostags');
        }
        unset($_POST['tag']);

        // Upload dir.
        $upload_dir  = wp_upload_dir();
        $upload_path = str_replace( '/', DIRECTORY_SEPARATOR, $upload_dir['path'] ) . DIRECTORY_SEPARATOR;

        // SAVE IMAGE
        if ($_POST['attachimage'] == 'yes') {
            $img = str_replace( 'data:image/png;base64,', '', $_POST['thumb'] );
            $img = str_replace( ' ', '+', $img );
            $img = base64_decode( $img );
            $filename = $_POST['filename'] . '.png';

            $upload_file = file_put_contents( $upload_path . $filename, $img );

            $attachment = array(
                'post_mime_type' => 'image/png',
                'post_title'     => esc_html($_POST['name']),
                'post_content'   => '',
                'post_status'    => 'inherit',
                'post_parent'    => $post_id,
                'guid'           => $upload_dir['url'] . '/' . basename( $filename ),
                'meta_input'   => array(
                    'palleon_hide' => true
                ),
            );

            $attachment_id = wp_insert_attachment( $attachment, $upload_dir['path'] . '/' . $filename );
            wp_update_attachment_metadata(
                $attachment_id,
                wp_generate_attachment_metadata( $attachment_id, $upload_dir['path'] . '/' . $filename )
            );
            set_post_thumbnail( $post_id, $attachment_id );
        }
        unset($_POST['thumb']);

        // SAVE TEMPLATE
        if ($_POST['attachtemplate'] == 'yes') {
            $filename_json = $_POST['filename'] . '.json';
            $json = stripslashes($_POST['json']);
            $upload_json_file = file_put_contents( $upload_path . $filename_json, $json );

            $attachment_json = array(
                'post_mime_type' => 'application/json',
                'post_title'     => esc_html($_POST['name']),
                'post_content'   => '',
                'post_status'    => 'inherit',
                'post_parent'    => $post_id,
                'guid'           => $upload_dir['url'] . '/' . basename( $filename_json ),
                'meta_input'   => array(
                    'palleon_hide' => true
                ),
            );

            $attachment_json_id = wp_insert_attachment( $attachment_json, $upload_dir['path'] . '/' . $filename_json );
            wp_update_attachment_metadata(
                $attachment_json_id,
                wp_generate_attachment_metadata( $attachment_json_id, $upload_dir['path'] . '/' . $filename_json )
            );

            $attachment_json_url = wp_get_attachment_url($attachment_json_id);
            update_post_meta($post_id, 'trioceros_custom_template', esc_url($attachment_json_url));
        }
        unset($_POST['json']);

        wp_die();
    }

    /**
	 * Delete Activity
	 */
    public function delete_activity(){
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'trioceros'));
        }
        wp_delete_post($_POST['id'], true);
    }

    /**
	 * Populate activities
	 */
    public static function populate_activities($args, $max, $btnID){
        $title_length =  (int) PalleonSettings::get_option('trioceros_title_length', 100);
        $comments = PalleonSettings::get_option('trioceros_comments', 'enable');
        $appreciations = PalleonSettings::get_option('trioceros_appreciations', 'enable');
        $userapp = get_user_meta( get_current_user_id(), 'trio_user_app', true );
        if (!is_array($userapp)) {
            $userapp = array();
        }
        $the_query = new WP_Query( $args );
        $total = $the_query->found_posts;
        if ( $the_query->have_posts() ) {
            while ( $the_query->have_posts() ) : $the_query->the_post();
            $id = get_the_ID();
            $title = get_the_title($id);
            $author_id = get_the_author_meta( 'ID' ); 
            if (!empty($title)) {
                $title = strlen($title) > $title_length ? substr($title,0,$title_length) . "..." : $title;
            }
            $templateUrl = get_post_meta( $id, 'trioceros_custom_template', true );
            $thumb = get_the_post_thumbnail_url($id, 'thumbnail');
            $full = get_the_post_thumbnail_url($id, 'full');
            $term_obj_list = get_the_terms( $id, 'triocerostags' );
            $terms_string = join(', ', wp_list_pluck($term_obj_list, 'name'));
            $app = get_post_meta( $id, 'trio_post_app', true );
            if (!$app || empty($app)) {
                $app = 0;
            }
            $app_class = 'not-active';
            $app_title = esc_attr__('Appreciate', 'trioceros');
            if (in_array($id, $userapp)) {
                $app_class = 'active';
                $app_title = esc_attr__('Unappreciate', 'trioceros');
            }
        ?>
        <div class="trio-activity-wrap" data-id="<?php echo esc_attr($id); ?>">
            <div class="trio-activity">
                <?php if ($thumb) { ?>
                <div class="trio-activity-img">
                    <a class="trio-lightbox" href="<?php echo esc_url($full); ?>">
                        <div class="palleon-img-wrap">
                            <div class="palleon-img-loader"></div>
                            <img class="lazy" data-src="<?php echo esc_url($thumb); ?>" />
                        </div>
                        <span class="material-icons">zoom_in</span>
                    </a>
                </div>
                <?php } ?>
                <div class="trio-activity-content">
                    <?php 
                    if (!empty($terms_string)) {
                        echo '<div class="trio-activity-tags">' . esc_html($terms_string) . '</div>';
                    }
                    ?>
                    <h5><?php echo esc_html($title); ?></h5>
                    <div class="trio-activity-user">
                    <?php echo get_avatar($author_id , 40); ?>
                    <a href="#" class="view-user" data-userid="<?php echo esc_attr($author_id); ?>"><?php echo esc_html(get_the_author_meta('display_name',$author_id)); ?></a>
                    <span> - <?php echo human_time_diff( get_the_time('U') , current_time( 'timestamp' ) ) . ' ' . esc_html__( 'ago', 'trioceros' ); ?></span>
                    </div>
                </div>
            </div>
            <div class="trio-activity-btns">
                <?php if (!empty($templateUrl)) { ?>
                <button type="button" class="palleon-btn trio-use-file palleon-select-template" autocomplete="off" data-json="<?php echo esc_url($templateUrl); ?>"><span class="material-icons">add_circle</span><?php echo esc_html__('Use Template', 'trioceros'); ?></button>
                <?php } else if (!empty($full)) { ?>
                <button type="button" class="palleon-btn trio-use-img" autocomplete="off" data-img="<?php echo esc_url($full); ?>"><span class="material-icons">add_circle</span><?php echo esc_html__('Use Image', 'trioceros'); ?></button>
                <?php } ?>
                <?php if ($comments == 'enable' && comments_open($id)) { ?>
                <button type="button" class="palleon-btn trio-view-comments" autocomplete="off"><span class="material-icons">forum</span><?php echo esc_html__('Comments', 'trioceros') . '<span class="trio-comments-count">(' . get_comment_count($id)['approved'] . ')</span>'; ?></button>
                <?php } ?>
                <?php if ($appreciations == 'enable') { ?>
                <button type="button" class="palleon-btn trio-appreciation <?php echo esc_attr($app_class); ?>" title="<?php echo esc_attr($app_title); ?>" autocomplete="off"><span class="material-icons">thumb_up</span><span class="trio-appreciation-count"><?php echo esc_html($app); ?></span></button>
                <?php } ?>
                <?php if ($author_id == get_current_user_id() || current_user_can('administrator') || current_user_can('editor')) { ?>
                <button type="button" class="palleon-btn danger trio-delete-activity" title="<?php echo esc_attr__('Delete', 'trioceros'); ?>" autocomplete="off"><span class="material-icons">delete</span></button>
                <?php } ?>
            </div>
        </div>
        <?php 
        endwhile;
        if ($btnID && $total > $max) {
            echo '<div class="trio-load-more"><button id="' . esc_attr($btnID) . '" type="button" class="palleon-btn primary" autocomplete="off" data-offset="' . esc_attr($max) . '">' . esc_html__('Load More', 'trioceros') . '</button></div>';
        }
        } else {
            echo '<div class="notice notice-warning">' . esc_html__('Nothing found.', 'trioceros') . '</div>';
        }
        wp_reset_postdata();
    }

    /**
	 * Load Activities
	 */
    public function load_activities() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'trioceros'));
        }

        $max =  (int) PalleonSettings::get_option('trioceros_max_activity', 5);
        $order = 'DESC';
        $orderby = 'post_date';

        if (isset($_POST['order']) && !empty($_POST['order']) && $_POST['order'] != 'latest') {
            if ($_POST['order'] == 'oldest') {
                $order = 'ASC';
            } else if ($_POST['order'] == 'relevance') {
                $orderby = 'relevance';
            } else if ($_POST['order'] == 'comment_count') {
                $orderby = 'comment_count';
            } else if ($_POST['order'] == 'app') {
                $orderby = 'meta_value_num';
            }
        }
        
        $args = array(
            'post_status' => 'publish',
            'post_type' => 'triocerosactivities',
            'posts_per_page'  => $max,
            'order'  => $order,
            'orderby'  => $orderby
        );

        if (isset($_POST['order']) && !empty($_POST['order']) && $_POST['order'] == 'app') {
            $args['meta_key'] = 'trio_post_app';
            $args['meta_type'] = 'NUMERIC';
        }

        if (isset($_POST['search']) && !empty($_POST['search'])) {
            $args['s'] = sanitize_text_field($_POST['search']);
        }

        if (isset($_POST['tag']) && !empty($_POST['tag'])) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'triocerostags',
                    'field' => 'term_id',
                    'terms' => (int) $_POST['tag'],
                ),
            );
        }

        self::populate_activities($args, $max, 'trio-load-more');
        
        wp_die();
    }

    /**
	 * Load More Activities
	 */
    public function more_activities() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'trioceros'));
        }
        $max =  (int) PalleonSettings::get_option('trioceros_max_activity', 5);
        $offset = (int) $_POST['offset'];
        $newOffset = $offset + $max;

        $order = 'DESC';
        $orderby = 'post_date';

        if (isset($_POST['order']) && !empty($_POST['order']) && $_POST['order'] != 'latest') {
            if ($_POST['order'] == 'oldest') {
                $order = 'ASC';
            } else if ($_POST['order'] == 'relevance') {
                $orderby = 'relevance';
            } else if ($_POST['order'] == 'comment_count') {
                $orderby = 'comment_count';
            } else if ($_POST['order'] == 'app') {
                $orderby = 'meta_value_num';
            }
        }

        $args = array(
            'post_status' => 'publish',
            'post_type' => 'triocerosactivities',
            'posts_per_page'  => $max,
            'offset'  => $offset,
            'order'  => $order,
            'orderby'  => $orderby,
        );

        if (isset($_POST['order']) && !empty($_POST['order']) && $_POST['order'] == 'app') {
            $args['meta_key'] = 'trio_post_app';
            $args['meta_type'] = 'NUMERIC';
        }

        if (isset($_POST['search']) && !empty($_POST['search'])) {
            $args['s'] = sanitize_text_field($_POST['search']);
        }

        if (isset($_POST['tag']) && !empty($_POST['tag'])) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'triocerostags',
                    'field' => 'term_id',
                    'terms' => (int) $_POST['tag'],
                ),
            );
        }

        self::populate_activities($args, $newOffset, 'trio-load-more');
        wp_die();
    }

     /**
	 * Appreciate
	 */
    public function appreciate() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'trioceros'));
        }
        $user_id = get_current_user_id();
        $id = 0;
        if (isset($_POST['id']) && !empty($_POST['id'])) {
            $id = (int) $_POST['id'];
        }
        $userapp = get_user_meta( $user_id, 'trio_user_app', true );
        if ( ! is_array($userapp) ) {
            $userapp = array();
        }
        array_push($userapp, $id);
        update_metadata('user', $user_id, 'trio_user_app', $userapp);
        $app = get_post_meta( $id, 'trio_post_app', true );
        if (!$app || empty($app)) {
            $app = 0;
        }
        $newapp = $app + 1;
        update_post_meta($id, 'trio_post_app', $newapp);
        echo esc_attr($newapp);
        wp_die();
    }

    /**
	 * Unappreciate
	 */
    public function unappreciate() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'trioceros'));
        }
        $user_id = get_current_user_id();
        $id = 0;
        if (isset($_POST['id']) && !empty($_POST['id'])) {
            $id = (int) $_POST['id'];
        }
        $userapp = get_user_meta( $user_id, 'trio_user_app', true );
        if ( ! is_array($userapp) ) {
            $userapp = array();
        }
        if (($key = array_search($id, $userapp)) !== false) {
            unset($userapp[$key]);
        }
        update_metadata('user', $user_id, 'trio_user_app', $userapp);
        $app = get_post_meta( $id, 'trio_post_app', true );
        if (!$app || empty($app)) {
            $app = 1;
        }
        $newapp = $app - 1;
        update_post_meta($id, 'trio_post_app', $newapp);
        echo esc_attr($newapp);
        wp_die();
    }

    /**
	 * Load Comments
	 */
    public function load_comments() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'trioceros'));
        }
        $args = array(
            'post_id' => (int) $_POST['id'],
            'status'  => 'approve',
        );
        $comments = get_comments( $args );

        if ($comments) {
            foreach ( $comments as $comment ) {
                ?>
                <div class="trio-comment">
                    <div class="trio-avatar">
                        <?php echo get_avatar( $comment->user_id, 100 ); ?>
                        <span><?php echo esc_html( $comment->comment_author); ?></span>
                    </div>
                    <div class="trio-content">
                        <div class="trio-content-comment"><?php echo wp_kses_post($comment->comment_content); ?></div>
                        <div class="trio-content-time"><span class="material-icons">watch_later</span><?php echo esc_html__( 'Posted', 'trioceros' ) . ' ' . human_time_diff( get_comment_date('U', $comment->comment_ID) , current_time( 'timestamp' ) ) . ' ' . esc_html__( 'ago', 'trioceros' ); ?></div>
                    </div>
                    <?php if ($comment->user_id == get_current_user_id() || current_user_can('administrator') || current_user_can('editor')) { ?>
                    <div class="trio-comment-delete">
                        <button type="button" class="palleon-btn danger" autocomplete="off" data-id="<?php echo esc_attr($comment->comment_ID); ?>"><span class="material-icons">delete</span></button>
                    </div>
                    <?php } ?>
                </div>
                <?php }
        } else {
            echo '<div class="notice notice-warning">' . esc_html__('No comments yet.', 'trioceros') . '</div>';
        }
        wp_die();
    }

    /**
	 * Add Comment
	 */
    public function add_comment() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'trioceros'));
        }
        if (isset($_POST['id']) && !empty($_POST['id']) && isset($_POST['text']) && !empty($_POST['text'])) {
            $current_user = wp_get_current_user();
            $text = str_replace("\r\n",'<br \>',trim($_POST['text']));
            $args = array(
                'comment_post_ID' => (int) $_POST['id'],
                'comment_content'  => wp_kses_post($text),
                'user_id'              => $current_user->ID,
                'comment_author'       => $current_user->user_login,
                'comment_author_email' => $current_user->user_email,
                'comment_author_url'   => $current_user->user_url,
            );
            wp_insert_comment( $args );
        }
        wp_die();
    }

    /**
	 * Delete Comment
	 */
    public function delete_comment() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'palleon-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'trioceros'));
        }
        if (isset($_POST['id']) && !empty($_POST['id'])) {
            wp_delete_comment((int) $_POST['id'], true);
        }
        wp_die();
    }

    /**
     * Delete attachments
     */
    public function delete_attachment($post_id) {
        if ( get_post_type( $post_id ) == 'triocerosactivities' ) {
            $attachments = get_attached_media( '', $post_id );
            foreach ($attachments as $attachment) {
                wp_delete_attachment($attachment->ID, true);
            }
        }
    }
}

/**
 * Returns the main instance of the class
 */
function TriocerosActivities() {  
	return TriocerosActivities::instance();
}
// Global for backwards compatibility
$GLOBALS['TriocerosActivities'] = TriocerosActivities();
