<?php
$user = wp_get_current_user();
$appreciations = PalleonSettings::get_option('trioceros_appreciations', 'enable');
$comments = PalleonSettings::get_option('trioceros_comments', 'enable');
$user_settings = PalleonSettings::get_option('trioceros_user_settings', 'enable');
$custom_avatar = PalleonSettings::get_option('trioceros_user_avatar', 'disable');
$allowed_roles = PalleonSettings::get_option('trioceros_author_roles', array());
array_push($allowed_roles, 'administrator');
?>
<div id="trio-panel-wrap">
    <div id="trio-panel-content">
        <div id="trio-panel-close"><span class="material-icons">close</span></div>
            <div id="trio-panel-inner">
                <h1><?php echo esc_html__('Community', 'trioceros'); ?></h1>
                <div class="palleon-tabs">
                    <ul class="palleon-tabs-menu">
                        <li id="trio-activity-menu" class="active" data-target="#trio-activity"><span class="material-icons">notifications</span><?php echo esc_html__('Activities', 'trioceros'); ?></li>
                        <?php if ( array_intersect( $allowed_roles, $user->roles )) { ?>
                        <li id="trio-add-new-menu" data-target="#trio-add-new"><span class="material-icons">add_circle</span><?php echo esc_html__('Add New', 'trioceros'); ?></li>
                        <?php } ?>
                        <?php if ($user_settings == 'enable') { ?>
                        <li id="trio-settings-menu" data-target="#trio-settings"><span class="material-icons">settings</span><?php echo esc_html__('Settings', 'trioceros'); ?></li>
                        <?php } ?>
                    </ul>
                    <div id="trio-activity" class="palleon-tab active">
                        <div class="trio-search-box">
                            <div>
                                <div>
                                    <input id="trio-activity-search" type="search" class="palleon-form-field" placeholder="Search by title..." autocomplete="off">
                                </div>
                                <div>
                                    <select id="trio-activity-search-tag" class="palleon-select" autocomplete="off"> 
                                    <option value="" selected><?php echo esc_html__('All Tags', 'trioceros'); ?></option>
                                    <?php
                                    $terms = get_terms([
                                        'taxonomy' => 'triocerostags',
                                        'orderby' => 'name',
                                        'order' => 'ASC',
                                        'hide_empty' => true,
                                    ]);
                                    foreach ($terms as $term){
                                        echo '<option value="' . $term->term_id . '">' . $term->name . ' (' . $term->count . ')</option>';
                                    }
                                    ?>
                                    </select>
                                    <select id="trio-activity-order" class="palleon-select" autocomplete="off">
                                        <option value="latest" selected><?php echo esc_html__('Sort by latest', 'trioceros'); ?></option>
                                        <option value="oldest"><?php echo esc_html__('Sort by oldest', 'trioceros'); ?></option>
                                        <option value="relevance"><?php echo esc_html__('Sort by relevance', 'trioceros'); ?></option>
                                        <?php if ($appreciations == 'enable') { ?>
                                        <option value="app"><?php echo esc_html__('Sort by appreciations', 'trioceros'); ?></option>
                                        <?php } ?>
                                        <?php if ($comments == 'enable') { ?>
                                        <option value="comment_count"><?php echo esc_html__('Sort by comment count', 'trioceros'); ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <div>
                                <button id="trio-activity-search-btn" type="button" class="palleon-btn primary"><span class="material-icons">search</span></button>
                            </div>
                        </div>
                        <div id="trio-activity-data" class="template-selection"></div>
                    </div>
                    <?php if ( array_intersect( $allowed_roles, $user->roles )) { ?>
                    <div id="trio-add-new" class="palleon-tab">
                        <div class="trio-form">
                            <div class="notice primary">
                            <?php echo esc_html__('The image and template will be added from the active tab canvas.', 'trioceros'); ?>
                            </div>
                            <div class="trio-form-fields">
                                <div class="palleon-control-wrap label-block">
                                    <label class="palleon-control-label"><?php echo esc_html__( 'Title*', 'trioceros' ); ?></label>
                                    <div class="palleon-control">
                                        <input id="trio-title-input" class="palleon-form-field" type="text" autocomplete="off">
                                    </div>
                                </div>
                                <div class="palleon-control-wrap label-block"> 
                                    <label class="palleon-control-label"><?php echo esc_html__( 'Tags', 'trioceros' ); ?></label> 
                                    <div class="palleon-control">
                                    <select id="trio-tags-select" class="palleon-select palleon-select2" autocomplete="off" multiple="multiple">
                                        <?php
                                        $user_terms = get_terms([
                                            'taxonomy' => 'triocerostags',
                                            'orderby' => 'name',
                                            'order' => 'ASC',
                                            'hide_empty' => false,
                                        ]);
                                        foreach( $user_terms as $term ) {
                                            echo '<option value="' . esc_attr($term->term_id) . '">' . esc_html($term->name) . '</option>';
                                        }
                                        ?>
                                    </select>
                                    </div> 
                                </div>
                                <div class="palleon-control-wrap"> 
                                    <label class="palleon-control-label"><?php echo esc_html__( 'Add Image', 'trioceros' ); ?></label> 
                                    <div class="palleon-control palleon-toggle-control"> 
                                        <label class="palleon-toggle"> 
                                            <input id="trio-img-check" class="palleon-toggle-checkbox" type="checkbox" autocomplete="off" checked>
                                            <div class="palleon-toggle-switch"></div> 
                                        </label> 
                                    </div> 
                                </div>
                                <div class="palleon-control-wrap"> 
                                    <label class="palleon-control-label"><?php echo esc_html__( 'Add Template', 'trioceros' ); ?></label> 
                                    <div class="palleon-control palleon-toggle-control"> 
                                        <label class="palleon-toggle"> 
                                            <input id="trio-template-check" class="palleon-toggle-checkbox" type="checkbox" autocomplete="off">
                                            <div class="palleon-toggle-switch"></div> 
                                        </label> 
                                    </div> 
                                </div>
                                <?php if ($comments == 'enable') { ?>
                                <div class="palleon-control-wrap"> 
                                    <label class="palleon-control-label"><?php echo esc_html__( 'Allow Comments', 'trioceros' ); ?></label> 
                                    <div class="palleon-control palleon-toggle-control"> 
                                        <label class="palleon-toggle"> 
                                            <input id="trio-comments-check" class="palleon-toggle-checkbox" type="checkbox" autocomplete="off" checked>
                                            <div class="palleon-toggle-switch"></div> 
                                        </label> 
                                    </div> 
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                        <button id="trio-add-activity" type="button" class="palleon-btn btn-full primary"><span class="material-icons">check</span><?php echo esc_html__('Submit', 'trioceros'); ?></button>
                    </div>
                    <?php } ?>
                    <?php if ($user_settings == 'enable') { ?>
                    <div id="trio-settings" class="palleon-tab">
                        <div class="trio-form">
                            <div class="trio-form-fields">
                                <?php if ($custom_avatar == 'enable') { ?>
                                <div class="palleon-control-wrap">
                                    <label class="palleon-control-label"><?php echo esc_html__( 'Avatar', 'trioceros' ); ?></label>
                                    <div class="palleon-control">
                                        <div id="trio-avatar-data" class="trio-avatar-wrap">
                                            <?php echo get_avatar( $user->ID, 100 ); ?>
                                            <div class="palleon-file-field">
                                                <input type="file" name="trio-upload-avatar" id="trio-upload-avatar" class="palleon-hidden-file" accept="image/png, image/jpeg, image/webp" />
                                                <label for="trio-upload-avatar" class="palleon-btn"><span class="material-icons">upload</span><span><?php echo esc_html__('Upload Image', 'trioceros'); ?></span></label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php } ?>
                                <div class="palleon-control-wrap">
                                    <label class="palleon-control-label"><?php echo esc_html__( 'Nickname', 'trioceros' ); ?></label>
                                    <div class="palleon-control">
                                        <input id="trio-profile-nickname-input" class="palleon-form-field" type="text" autocomplete="off" value="<?php the_author_meta( 'nickname', $user->ID ); ?>">
                                    </div>
                                </div>
                                <div class="palleon-control-wrap">
                                    <label class="palleon-control-label"><?php echo esc_html__( 'Name & Surname', 'trioceros' ); ?></label>
                                    <div class="palleon-control">
                                        <div class="trio-name-surname">
                                            <input id="trio-profile-firstname-input" class="palleon-form-field" type="text" autocomplete="off" value="<?php the_author_meta( 'first_name', $user->ID ); ?>">
                                            <input id="trio-profile-lastname-input" class="palleon-form-field" type="text" autocomplete="off" value="<?php the_author_meta( 'last_name', $user->ID ); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="palleon-control-wrap">
                                    <label class="palleon-control-label"><?php echo esc_html__( 'Public Name', 'trioceros' ); ?></label>
                                    <div class="palleon-control">
                                        <select id="trio-profile-displayname-input" class="palleon-select">
                                            <option value="display_nickname" selected><?php echo esc_html__( 'Nickname', 'trioceros' ); ?></option>
                                            <option value="display_firstname"><?php echo esc_html__( 'First Name', 'trioceros' ); ?></option>
                                            <option value="display_lastname"><?php echo esc_html__( 'Last Name', 'trioceros' ); ?></option>
                                            <option value="display_firstlast"><?php echo esc_html__( 'First Name & Last Name', 'trioceros' ); ?></option>
                                            <option value="display_lastfirst"><?php echo esc_html__( 'Last Name & First Name', 'trioceros' ); ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="palleon-control-wrap label-block">
                                    <label class="palleon-control-label"><?php echo esc_html__( 'Biographical Info', 'trioceros' ); ?></label>
                                    <div class="palleon-control">
                                        <div id="trio-profile-bio-input"><?php the_author_meta( 'description', $user->ID ); ?></div>
                                    </div>
                                </div>
                                <div class="palleon-control-wrap">
                                    <label class="palleon-control-label"><?php echo esc_html__( 'Email', 'trioceros' ); ?></label>
                                    <div class="palleon-control">
                                        <input id="trio-profile-email-input" class="palleon-form-field" type="email" autocomplete="off" value="<?php the_author_meta( 'user_email', $user->ID ); ?>">
                                    </div>
                                </div>
                                <div class="palleon-control-wrap">
                                    <label class="palleon-control-label"><?php echo esc_html__( 'Password', 'trioceros' ); ?></label>
                                    <div class="palleon-control">
                                    <a id="trio-reset-password" type="button" class="palleon-btn" href="<?php echo esc_url(wp_lostpassword_url()); ?>" target="_blank"><?php echo esc_html__('Reset Password', 'trioceros'); ?></a>
                                    </div>
                                </div>
                            </div> 
                        </div>
                        <div class="trio-settings-btns">
                            <div><button id="trio-view-profile" type="button" class="palleon-btn view-user" data-userid="<?php echo esc_attr($user->ID); ?>"><span class="material-icons">visibility</span><?php echo esc_html__('View Profile', 'trioceros'); ?></button></div>
                            <div><button id="trio-save-settings" type="button" class="palleon-btn primary"><span class="material-icons">save</span><?php echo esc_html__('Save Settings', 'trioceros'); ?></button></div>
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="trio-comments-modal" class="palleon-modal">
    <div class="palleon-modal-close" data-target="#trio-comments-modal"><span class="material-icons">close</span></div>
    <div class="palleon-modal-wrap">
        <div class="palleon-modal-inner">
            <div class="palleon-modal-bg">
                <div class="trio-loader"><div class="palleon-loader"></div></div>
                <h2><?php echo esc_html__('Add Comment', 'trioceros'); ?></h2>
                <div id="trio-reply-form" data-id="">
                    <div id="trio-comment-textarea"></div>
                    <button id="trio-comment-button" type="button" class="palleon-btn primary" autocomplete="off"><span class="material-icons">add_circle</span><?php echo esc_html__('Add Comment', 'trioceros'); ?></button>
                </div>
                <h2><?php echo esc_html__('Comments', 'trioceros'); ?></h2>
                <div id="trio-comments"></div>
            </div>
        </div>
    </div>
</div>

<div id="trio-user-modal" class="palleon-modal">
    <div class="palleon-modal-close" data-target="#trio-user-modal"><span class="material-icons">close</span></div>
    <div class="palleon-modal-wrap">
        <div id="trio-user-profile-wrap" class="template-selection"></div>    
    </div>
</div>